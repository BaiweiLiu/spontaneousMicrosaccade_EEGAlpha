function eyeLab_saccAnalysis(cfg)
% the way to extract the sacc inforation
% read_dir: the data from eyeLab_getShift
% time4fix: time window for detecting fixation position (only if use method "start-return") 
% miniDis: minis displacement
% channel: {'X'} {'Y'} {'XY'}
% method: {"towardness" "start-return"}
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
winbef = [50 0];
winaft = [50 100];

v2struct(cfg)

% get file name
load(read_dir)

% creat data vector
if strcmp(method, "start-return")
    
    if strcmp(channel, 'xy')
        dwellTimePure = [];
        dwell_time = NaN(size(eye_data.shiftXY));
        gaze_start = zeros(size(eye_data.shiftXY));
        gaze_return = zeros(size(eye_data.shiftXY));
        
        shift_startPoint = cell(size(eye_data.shiftXY));
        shift_endPoint = cell(size(eye_data.shiftXY));
        
        %caculated gaze center (start position)
        t4fix = dsearchn(eye_data.time',time4fix')';
        gazePosX_cent = squeeze(eye_data.trial(:,1,[t4fix(1):t4fix(2)]));
        gazePosY_cent = squeeze(eye_data.trial(:,2,[t4fix(1):t4fix(2)]));
        
        gazePosX = squeeze(eye_data.trial(:,1,:));
        gazePosY = squeeze(eye_data.trial(:,2,:));
        
        % loop for trial
        for trlID = 1:size(eye_data.shiftXY_vel,1)
            sacc_ok = abs(eye_data.shiftXY(trlID,:)) > miniDis;
            center_PosX = nanmedian(gazePosX_cent(trlID,:));
            center_PosY = nanmedian(gazePosY_cent(trlID,:));
            
            if sum(sacc_ok) > 0
                sacc_ind = find(sacc_ok);
                for sacc_ind_trl = 1:length(sacc_ind)
                    t = eye_data.shift_time(sacc_ind(sacc_ind_trl)) ;
                    t = find(eye_data.time == t);
                    
                    startPosX = nanmean(gazePosX(trlID, [(t-winbef(1)):(t-winbef(2))] ));
                    startPosY = nanmean(gazePosY(trlID, [(t-winbef(1)):(t-winbef(2))]));
                    
                    endPosX = nanmean(gazePosX(trlID, [(t+winaft(1)):(t+winaft(2))]));
                    endPosY = nanmean(gazePosY(trlID, [(t+winaft(1)):(t+winaft(2))]));
                    
                    startDisX = startPosX - center_PosX;
                    startDisY = startPosY - center_PosY;
                    
                    startDis = abs(startDisX + i*startDisY);
                    
                    endDisX = endPosX - center_PosX;
                    endDisY = endPosY - center_PosY;
                    
                    endDis = abs(endDisX + i*endDisY);
                    if startDis < endDis
                        gaze_start(trlID, sacc_ind(sacc_ind_trl))  = eye_data.shiftXY(trlID,sacc_ind(sacc_ind_trl));
                    elseif startDis > endDis
                        gaze_return(trlID, sacc_ind(sacc_ind_trl)) = eye_data.shiftXY(trlID,sacc_ind(sacc_ind_trl));
                    end
                    
                    shift_startPoint{trlID, sacc_ind(sacc_ind_trl)} = [startPosX, startPosY];
                    shift_endPoint{trlID, sacc_ind(sacc_ind_trl)} = [endPosX, endPosY];
                end

                startSacc_ind = find(gaze_start(trlID, :) > 0);
                if length(startSacc_ind) >0
                    for sacc_ind_trl = 1: length(startSacc_ind)
                        late_return = 0;
                        late_return = find(gaze_return(trlID,startSacc_ind(sacc_ind_trl):end));
                        if late_return > 0
                            dwell_time(trlID,startSacc_ind(sacc_ind_trl)) =late_return(1); 
                            dwellTimePure(end+1) = late_return(1); 
                        end
                    end
                end
            end
        end
        eye_data.dwell_timeXY = dwell_time;
        eye_data.shiftXY_start = gaze_start;
        eye_data.shiftXY_return = gaze_return;
        eye_data.dwellTimePureXY = dwellTimePure;
        eye_data.shiftXY_startPoint = shift_startPoint;
        eye_data.shiftXY_endPoint = shift_endPoint;
        save(read_dir, 'eye_data')
    end
    
    if strcmp(channel, 'x')
        dwellTimePure = [];
        dwell_time = NaN(size(eye_data.shiftX));
        gaze_start = zeros(size(eye_data.shiftX));
        gaze_return = zeros(size(eye_data.shiftX));
        
        shift_startPoint = cell(size(eye_data.shiftX));
        shift_endPoint = cell(size(eye_data.shiftX));
        
        %caculated gaze center (start position)
        t4fix = dsearchn(eye_data.time',time4fix')';
        gazePosX_cent = squeeze(eye_data.trial(:,1,[t4fix(1):t4fix(2)]));
        
        gazePosX = squeeze(eye_data.trial(:,1,:));
        
        % loop for trial
        for trlID = 1:size(eye_data.shiftX_vel,1)
            sacc_ok = abs(eye_data.shiftX(trlID,:)) > miniDis;
            center_PosX = nanmedian(gazePosX_cent(trlID,:));
            
            if sum(sacc_ok) > 0
                sacc_ind = find(sacc_ok);
                for sacc_ind_trl = 1:length(sacc_ind)
                    t = eye_data.shift_time(sacc_ind(sacc_ind_trl)) ;
                    t = find(eye_data.time == t);
                    
                    startPosX = nanmean(gazePosX(trlID, [(t-winbef(1)):(t-winbef(2))] ));
                    endPosX = nanmean(gazePosX(trlID, [(t+winaft(1)):(t+winaft(2))]));
                    
                    startDisX = abs(startPosX - center_PosX);
                    
                    endDisX = abs(endPosX - center_PosX);
                    if startDisX <= endDisX
                        gaze_start(trlID, sacc_ind(sacc_ind_trl))  = endPosX - startPosX;
                    end 
                    if startDisX > endDisX
                    
                        gaze_return(trlID, sacc_ind(sacc_ind_trl)) = endPosX - startPosX;
                    end
                    
                    shift_startPoint{trlID, sacc_ind(sacc_ind_trl)} = startPosX;
                    shift_endPoint{trlID, sacc_ind(sacc_ind_trl)} = endPosX;
                end

                startSacc_ind = find(gaze_start(trlID, :) > 0);
                if length(startSacc_ind) >0
                    for sacc_ind_trl = 1: length(startSacc_ind)
                        late_return = 0;
                        late_return = find(gaze_return(trlID,startSacc_ind(sacc_ind_trl):end));
                        if late_return > 0
                            dwell_time(trlID,startSacc_ind(sacc_ind_trl)) =late_return(1); 
                            dwellTimePure(end+1) = late_return(1); 
                        end
                    end
                end
            end
        end
        eye_data.dwell_timeX = dwell_time;
        eye_data.shiftX_start = gaze_start;
        eye_data.shiftX_return = gaze_return;
        eye_data.dwellTimePureX = dwellTimePure;
        eye_data.shiftX_startPoint = shift_startPoint;
        eye_data.shiftX_endPoint = shift_endPoint;
        save(read_dir, 'eye_data')
        
    end

    if strcmp(channel, 'y')
        dwellTimePure = [];
        dwell_time = NaN(size(eye_data.shiftY));
        gaze_start = zeros(size(eye_data.shiftY));
        gaze_return = zeros(size(eye_data.shiftY));
        
        shift_startPoint = cell(size(eye_data.shiftY));
        shift_endPoint = cell(size(eye_data.shiftY));
        
        %caculated gaze center (start position)
        t4fix = dsearchn(eye_data.time',time4fix')';
        gazePosY_cent = squeeze(eye_data.trial(:,2,[t4fix(1):t4fix(2)]));
        
        gazePosY = squeeze(eye_data.trial(:,2,:));
        
        % loop for trial
        for trlID = 1:size(eye_data.shiftY_vel,1)
            sacc_ok = abs(eye_data.shiftY(trlID,:)) > miniDis;
            center_PosY = nanmedian(gazePosY_cent(trlID,:));
            
            if sum(sacc_ok) > 0
                sacc_ind = find(sacc_ok);
                for sacc_ind_trl = 1:length(sacc_ind)
                    t = eye_data.shift_time(sacc_ind(sacc_ind_trl)) ;
                    t = find(eye_data.time == t);
                    
                    startPosY = nanmean(gazePosY(trlID, [(t-winbef(1)):(t-winbef(2))] ));
                    endPosY = nanmean(gazePosY(trlID, [(t+winaft(1)):(t+winaft(2))]));
                    
                    startDisY = abs(startPosY - center_PosY);
                    
                    endDisY = abs(endPosY - center_PosY);
                    if startDisY <= endDisY
                        gaze_start(trlID, sacc_ind(sacc_ind_trl))  = endPosY - startPosY;
                    end 
                    if startDisY > endDisY
                    
                        gaze_return(trlID, sacc_ind(sacc_ind_trl)) = endPosY - startPosY;
                    end
                    
                    shift_startPoint{trlID, sacc_ind(sacc_ind_trl)} = startPosY;
                    shift_endPoint{trlID, sacc_ind(sacc_ind_trl)} = endPosY;
                end

                startSacc_ind = find(gaze_start(trlID, :) > 0);
                if length(startSacc_ind) >0
                    for sacc_ind_trl = 1: length(startSacc_ind)
                        late_return = 0;
                        late_return = find(gaze_return(trlID,startSacc_ind(sacc_ind_trl):end));
                        if late_return > 0
                            dwell_time(trlID,startSacc_ind(sacc_ind_trl)) =late_return(1); 
                            dwellTimePure(end+1) = late_return(1); 
                        end
                    end
                end
            end
        end
        eye_data.dwell_timeY = dwell_time;
        eye_data.shiftY_start = gaze_start;
        eye_data.shiftY_return = gaze_return;
        eye_data.dwellTimePureY = dwellTimePure;
        eye_data.shiftY_startPoint = shift_startPoint;
        eye_data.shiftY_endPoint = shift_endPoint;
        save(read_dir, 'eye_data')
end
   
end