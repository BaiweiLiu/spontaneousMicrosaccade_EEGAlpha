function eyeLab_timeBin(cfg)

% function eyeLab_timeBin(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.time_i           = the range of time you want to bin;
%       cfg.stepBins         = bin it in every x ms.
%       cfg.output_dir        = uknow.
%       cfg.binWindows       = the slide windows
%       cfg.input_file      = string specifiying the directory where the gazeShift files are;
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% default values
sampleRate =1000;

% extract cfg value
v2struct(cfg);

% load gaze shift file
infoDisp(['load gaze shift data for subj ' input_file(end-7:end-4)]);
load(input_file);

% create output file
outfile = creatDir([output_dir]);
outfile_to = creatDir([output_dir filesep 'toward']);
outfile_aw = creatDir([output_dir filesep 'away']);

% get bin time
numTrials = size(gazeShift.gazeL_to,1);
gaze_window = time_i;
t2sort = dsearchn(time', gaze_window');
time_start = t2sort(1) + binWindows*0.5*sampleRate/1000;
time_end = t2sort(2) - binWindows*0.5*sampleRate/1000;
step_Bins_Sample = stepBins * sampleRate/1000;
binTime = [time_start:step_Bins_Sample:time_end];
numBins = length(binTime);

% create data space
trialBin_to_ind = zeros(numBins,numTrials);
trialBin_aw_ind = zeros(numBins,numTrials);
shiftTime_to = NaN(numBins,numTrials);
shiftTime_aw = NaN(numBins,numTrials);

% run bin loop
for binInd = 1:numBins
    
    % get range of each bin
    minTime = binTime(binInd)-(binWindows-1)*0.5*sampleRate/1000;
    maxTime = binTime(binInd) + binWindows*0.5*sampleRate/1000;
    
    %extract trial data
    for trialID = 1 : numTrials 
        
        events = [];
        [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,:));
        [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,:));
        [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,:));
        [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,:));
        events = [indL_to indR_to indL_aw indR_aw];
        msEventsInd = find(events);
        [firstEvent, typeInd] =min(events(msEventsInd));
        eventType = msEventsInd(typeInd);
        
        if ~isempty(eventType)
            if eventType <= 2 % toward
                if firstEvent>=minTime & firstEvent<= maxTime;
                    trialBin_to_ind(binInd,trialID) =1;
                    shiftTime_to(binInd,trialID) = time_i(1) + (firstEvent-t2sort(1))/(sampleRate/1000);
                end


            elseif eventType > 2 % away
                if firstEvent>=minTime & firstEvent<= maxTime;
                    trialBin_aw_ind(binInd,trialID) =1;
                    shiftTime_aw(binInd,trialID) = time_i(1) + (firstEvent-t2sort(1))/(sampleRate/1000);
                end
            end
            
        end
    end
end

% save the info
event.timeBin = [(gaze_window(1)+binWindows/2):stepBins:(gaze_window(2)-binWindows/2)];
event.numBin = numBins;

event.sel = logical(trialBin_to_ind);
event.value = shiftTime_to;
save([outfile_to  filesep input_file(end - 7:end)], 'event');

event.sel= logical(trialBin_aw_ind);
event.value = shiftTime_aw;
save([outfile_aw  filesep input_file(end - 7:end)], 'event');
end