function eyeLab_GAshift(cfg)
badSubj = {'000'};
slide_win = 50; % ms 

v2struct(cfg) % time_i, time, input_dir, output_dir, good_trial_dir
outfile = creatDir(output_dir);

cd(input_dir);
sublist=dir('*.mat');
sublist={sublist.name}; 

HZ_window = time_i; 
t2plot = dsearchn(time', HZ_window');
GA_shift = [];
for subInd = 1:length(sublist)
    
    load(sublist{subInd});
    
    if isfield(gazeShift, 'gazeL') % no toward and away; pure left and right
        numTrials = size(gazeShift.gazeL,1);
        
        if exist('good_trial_dir')
            
            if ~exist('eventFiled')
                load([good_trial_dir filesep sublist{subInd}])
                events_sel = event.sel;
            else
                load([good_trial_dir filesep sublist{subInd}],eventFiled);
                events_sel = logical(eval(eventFiled));
            end
        else
            events_sel = logical(ones(1,numTrials));
        end
        
        events_sel_sum = [];
        if exist('condTrig')
            for condID = 1:length(condTrig)
                trigs_sel = condTrig{condID};
                cond_sel = ismember(gazeShift.trialinfo, trigs_sel);
                if size(events_sel,1) ~= size(cond_sel,1)
                    cond_sel =cond_sel';
                end
                events_sel_sum(condID,:) = events_sel & cond_sel;
            end
        else
            events_sel_sum(1,:) = events_sel;
        end
        
        
        clear events_sel
        
        for condInd = 1 : size(events_sel_sum,1)
            
            events_sel = events_sel_sum(condInd,:);
            numTrials_tl_ok = sum(events_sel);
            
             % extract the shift rate
            events_sel = logical(events_sel);
            shiftRateL = sum(gazeShift.gazeL(events_sel,:),1)/(numTrials_tl_ok);     
            shiftRateR = sum(gazeShift.gazeR(events_sel,:),1)/(numTrials_tl_ok);

            % convert to the shift hz
            hzL = smoothdata(shiftRateL,2,'movmean',slide_win) * 1000;
            hzR = smoothdata(shiftRateR,2,'movmean',slide_win) * 1000;

            % get rate of shift in toi

            rateL = sum(gazeShift.gazeL(events_sel,t2plot(1):t2plot(2)),2)>0;
            rateR = sum(gazeShift.gazeR(events_sel,t2plot(1):t2plot(2)),2)>0;

            Rate_L_toi = sum(rateL)/numTrials;
            Rate_R_toi = sum(rateR)/numTrials;

             % set the GA data
            GA_shift.Rate_L_toi(subInd,condInd) = Rate_L_toi;
            GA_shift.Rate_R_toi(subInd,condInd) = Rate_R_toi;

            GA_shift.hzL{subInd,condInd} = hzL;
            GA_shift.hzR{subInd,condInd} = hzR;
            
            GA_shift.subjMaker{subInd,condInd} = sublist{subInd}(end-7:end-4);
            GA_shift.condMaker{subInd,condInd} = condName{condInd};
        end

        save([outfile filesep outfile_name '.mat'], 'GA_shift');

    else
        
        numTrials = size(gazeShift.gazeL_to,1);
        if exist('good_trial_dir')
            if ~exist('eventFiled')
                load([good_trial_dir filesep sublist{subInd}])
                events_sel = event.sel;
            else
                load([good_trial_dir filesep sublist{subInd}],eventFiled);
                events_sel = logical(eval(eventFiled));
            end
        else
            events_sel = logical(ones(1,numTrials));
        end
        
        numTrials_tl_ok = sum(events_sel);
        
        events_sel_sum = [];
        if exist('condTrig')
            for condID = 1:length(condTrig)
                trigs_sel = condTrig{condID};
                cond_sel = ismember(gazeShift.trialinfo, trigs_sel);
                if size(events_sel,1) >1
                    events_sel = events_sel';
                end
                
                events_sel_sum(condID,:) = events_sel & cond_sel';
            end
        else
            events_sel_sum(1,:) = events_sel;
        end
        clear events_sel
        
        for condInd = 1 : size(events_sel_sum,1)
            events_sel = logical(events_sel_sum(condInd,:));
            numTrials_tl_ok = sum(events_sel);
        % extract the shift rate
    %         shiftRateL_tow = sum(gazeShift.gazeL_to(events_sel,:),1)/(numTrials/2);
    %         shiftRateL_away = sum(gazeShift.gazeL_aw(events_sel,:),1)/(numTrials/2);
    %         shiftRateR_tow = sum(gazeShift.gazeR_to(events_sel,:),1)/(numTrials/2);
    %         shiftRateR_away = sum(gazeShift.gazeR_aw(events_sel,:),1)/(numTrials/2);
            load(sublist{subInd});

            shiftRate_unTrust = sum(gazeShift.gazeUnTrust(events_sel,:),1)/(numTrials);

            shiftRate_to = (sum(gazeShift.gazeL_to(events_sel,:),1) + sum(gazeShift.gazeR_to(events_sel,:),1)) /numTrials_tl_ok;
            shiftRate_aw = (sum(gazeShift.gazeL_aw(events_sel,:),1) + sum(gazeShift.gazeR_aw(events_sel,:),1)) /numTrials_tl_ok;

            % convert to the shift hz
    %         hzL_to = smoothdata(shiftRateL_tow,2,'movmean',100) * 1000;
    %         hzL_aw = smoothdata(shiftRateL_away,2,'movmean',100) * 1000;
    %         hzR_to = smoothdata(shiftRateR_tow,2,'movmean',100) * 1000;
    %         hzR_aw = smoothdata(shiftRateR_away,2,'movmean',100) * 1000;

            hz_to = smoothdata(shiftRate_to,2,'movmean',slide_win) * 1000;
            hz_aw = smoothdata(shiftRate_aw,2,'movmean',slide_win) * 1000;
            hz_unTrust = smoothdata(shiftRate_unTrust,2,'movmean',100) * 1000;

            % get rate of shift in toi

            gazeShift.gazeL_to = gazeShift.gazeL_to(events_sel,t2plot(1):t2plot(2));
            gazeShift.gazeL_aw = gazeShift.gazeL_aw(events_sel,t2plot(1):t2plot(2));
            gazeShift.gazeR_to = gazeShift.gazeR_to(events_sel,t2plot(1):t2plot(2));
            gazeShift.gazeR_aw = gazeShift.gazeR_aw(events_sel,t2plot(1):t2plot(2));
            gazeShift.gazeUnTrust = gazeShift.gazeUnTrust(events_sel,t2plot(1):t2plot(2));

            % get power 

            powerL_to = abs(nanmean(gazeShift.powerL_to(events_sel,:),1));
            powerL_aw = abs(nanmean(gazeShift.powerL_aw(events_sel,:),1));
            powerR_to = abs(nanmean(gazeShift.powerR_to(events_sel,:),1));
            powerR_aw = abs(nanmean(gazeShift.powerR_aw(events_sel,:),1));

            if sum(events_sel) == 0 
                powerL_to = NaN(1,length(time));
                powerL_aw = NaN(1,length(time));
                powerR_to = NaN(1,length(time));
                powerR_aw = NaN(1,length(time));
            end
            % get power at toi 
            power_to = nanmean([powerL_to; powerR_to]);
            power_aw = nanmean([powerL_aw; powerR_aw]);

            power_to_toi = nanmean(power_to(t2plot(1):t2plot(2)));
            power_aw_toi = nanmean(power_aw(t2plot(1):t2plot(2)));



            GA_shift.hz_to{(subInd-1)*size(events_sel_sum,1) + condInd} = hz_to();
            GA_shift.hz_aw{(subInd-1)*size(events_sel_sum,1) + condInd} = hz_aw();

            GA_shift.power_to{(subInd-1)*size(events_sel_sum,1) + condInd} = power_to;
            GA_shift.power_aw{(subInd-1)*size(events_sel_sum,1) + condInd} = power_to;

            GA_shift.power_to_toi{(subInd-1)*size(events_sel_sum,1) + condInd} = power_to_toi;
            GA_shift.power_aw_toi{(subInd-1)*size(events_sel_sum,1) + condInd} = power_aw_toi;
            
            GA_shift.subjMaker{(subInd-1)*size(events_sel_sum,1) + condInd} = sublist{subInd}(end-7:end-4);
            GA_shift.condMaker{(subInd-1)*size(events_sel_sum,1) + condInd} = condName{condInd};
        end
        
        numTrials = size(gazeShift.gazeL_to,1);
        trial_aw = zeros(1,numTrials);
        trial_unTrust = zeros(1,numTrials);
        trial_to = zeros(1,numTrials);
        trial_noMs = ones(1,numTrials);

        for trialID = 1 : numTrials 
            events = [];
            [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,:));
            [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,:));
            [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,:));
            [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,:));
            [~, ind_unTrust]=ismember(1,gazeShift.gazeUnTrust(trialID,:));
            events = [indL_to indR_to indL_aw indR_aw ind_unTrust];
            msEventsInd = find(events);
            [firstEvent, typeInd] =min(events(msEventsInd));
            eventType = msEventsInd(typeInd);

            if ~isempty(eventType)
                if eventType <= 2
                    trial_to(trialID) =1;
                elseif eventType <= 4
                    trial_aw(trialID) =1;
                elseif eventType == 5
                    trial_unTrust(trialID) =1;
                end
                trial_noMs(trialID) = 0;
            end
        end
        GA_shift.Rate_toi_to(subInd) = sum(trial_to)/numTrials;
        GA_shift.Rate_toi_aw(subInd) = sum(trial_aw)/numTrials;
        GA_shift.Rate_toi_noMS(subInd) = sum(trial_noMs)/numTrials;
        GA_shift.Rate_toi_unTrust(subInd) = sum(trial_unTrust)/numTrials;
        save([outfile filesep outfile_name '.mat'], 'GA_shift');
    end
end
end