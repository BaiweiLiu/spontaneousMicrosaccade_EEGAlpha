function eyeLab_ShiftRate_plot(cfg)

% the way to plot the sacc size x rate 
% diff_rate: shift rateof toward vs. away
% diff_hz: hz_diff
% diff_binMin: 
% time: 
% binRange: 

% part of the eyeLab toolbox, by Baiwei Liu, VU, 2022

v2struct(cfg)

%cmap = flipud(brewermap([],'*PRGn'));
cmap = flipud(brewermap([],'*RdGy'));

figure('position', [100 100 600 500], 'color', [1 1 1])

subplot(5,5,1:4)
data2plot_encod = diff_rate;

m1 = lineErr_plot(time,data2plot_encod, cmap(end-50,:), 'ci')

xlim(time_i)
xticklabels({}); 
ax = gca; w = ax.YTick;

ax.YTick = [w(1) w(end)];
%ylim(rateLim)

subplot(5,5,[6:9 11:14 16:19 21:24])
hz2plot = squeeze(mean(diff_hz));
contourf(time,binRange,hz2plot,50,'linecolor','none');
ylabel('shift size')
xlabel('time')

%colorbar
set(gca, 'FontSize', 20,'Fontname','Arial', 'LineWidth', 1.2);
set(gca,'TickDir','out');
colormap(cmap);
caxis(hzLim)
xlim(time_i)

box off
ax2 = axes('Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k','LineWidth', 1.2);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
box on

subplot(5,5,[10 15 20 25])
%t_sel= GA_struct_hz.time > -0.2 & GA_struct_hz.time <1;
data2plot_encod = diff_binMin;

m1 = lineErr_plot(binRange,data2plot_encod, cmap(end-50,:), 'ci');
camroll(90)
set(gca,'xdir','reverse','YAxisLocation','right')%,'ydir','reverse')
xlim([binRange(1) binRange(end)])
xticklabels({}); 

ax = gca; w = ax.YTick;

ax.YTick = [w(1) w(end)];