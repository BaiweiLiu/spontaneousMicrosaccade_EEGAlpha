function [data_out]=eyeLab_scanSacc(cfg)

slide_win = 50; %ms
v2struct(cfg)
cmap = brewermap([],'*RdBu');
y_range = power_range;

%for 
binStart = y_range(1) + binWin/2;
binEnd = y_range(2) - binWin/2;
binRange =[binStart: binstep:binEnd];
numBin = length(binRange);

sublist_shift = get_subFiles(saccFile);
%sublist_goodTl = get_subFiles([write_dir_eye filesep 'trial_ok_noNan']);
hz_diff = []; hz_to = [];hz_aw = [];

for subjInd = 1:length(sublist_shift)
    
    % load shift data
    load(sublist_shift{subjInd});
    time = gazeShift.time;
    
    % select trial 
    if exist('sublist_goodTl')
        load(sublist_goodTl{subjInd});
        okTl = event.sel;
    else
        okTl = ones(1, size(gazeShift.gazeL_to,1));
    end
    numOkTrials = sum(okTl);
    
    %%
    gazeShift.powerL_to(isnan(gazeShift.powerL_to)) = 0;
    gazeShift.powerR_to(isnan(gazeShift.powerR_to)) = 0;
    gazeShift.powerL_aw(isnan(gazeShift.powerL_aw)) = 0;
    gazeShift.powerR_aw(isnan(gazeShift.powerR_aw)) = 0;
    
    power_to = abs(gazeShift.powerL_to) + abs(gazeShift.powerR_to);
    power_aw = abs(gazeShift.powerL_aw) + abs(gazeShift.powerR_aw);
    
    binHz_to = NaN(numBin, size(gazeShift.powerL_to,2));
    binHz_aw = NaN(numBin, size(gazeShift.powerL_to,2));
    for binInd = 1:numBin
        minValue = binRange(binInd) -  binWin/2;
        maxValue = binRange(binInd) +  binWin/2;
        
        rate_to = mean((power_to >= minValue) & (power_to < maxValue));
        rate_aw = mean((power_aw >= minValue) & (power_aw < maxValue));
        
        binHz_to(binInd,:) = smoothdata(rate_to,2,'movmean',slide_win) * 1000;
        binHz_aw(binInd,:)= smoothdata(rate_aw,2,'movmean',slide_win) * 1000;
    end
    
    binHz_diff = binHz_to - binHz_aw;
    
    hz_diff (subjInd,:,:)= binHz_diff;
    hz_to(subjInd,:,:)= binHz_to; 
    hz_aw(subjInd,:,:)= binHz_aw; 
end
%%
figure('position', [100 100 1200 300])
subplot(1,3,1)
% difference figure

hz2plot= squeeze(nanmean(hz_diff,1));
contourf(time,binRange,hz2plot,50,'linecolor','none')
maxValue = max(max(max(hz2plot)), abs(min(min(hz2plot)))); 
caxis([-maxValue maxValue])
colorbar
colormap(cmap);
xlabel('time (s)')
ylabel('shift size')
title('Toward - Away')
hold on
plot([time(1) time(end)], [percent2degree, percent2degree], '--k')
plot([time(1) time(end)], [100, 100], '--k')
plot([0 0], [binRange(1), binRange(end)], '--k')

xlim(xli)

subplot(1,3,2)
hz2plot= squeeze(nanmean(hz_to,1));
contourf(time,binRange,hz2plot,50,'linecolor','none')
maxValue = max([max(max(squeeze(nanmean(hz_to,1)))) max(max(squeeze(nanmean(hz_aw,1))))]);

caxis([-maxValue maxValue])
colorbar
colormap(cmap);
xlabel('time (s)')
ylabel('shift size')
title('Toward')
hold on
plot([time(1) time(end)], [percent2degree, percent2degree], '--k')
plot([time(1) time(end)], [100, 100], '--k')
plot([0 0], [binRange(1), binRange(end)], '--k')
xlim(xli)

subplot(1,3,3)
hz2plot= squeeze(nanmean(hz_aw,1));
contourf(time,binRange,hz2plot,50,'linecolor','none')
caxis([-maxValue maxValue])
colorbar
colormap(cmap);
xlabel('time (s)')
ylabel('shift size')
title('away')
hold on
plot([time(1) time(end)], [percent2degree, percent2degree], '--k')

plot([time(1) time(end)], [100, 100], '--k')
plot([0 0], [binRange(1), binRange(end)], '--k')
xlim(xli)

data_out.hz_diff = hz_diff;
data_out.hz_to = hz_to;
data_out.hz_aw = hz_aw;
data_out.time = time;
data_out.binRange =binRange;

end