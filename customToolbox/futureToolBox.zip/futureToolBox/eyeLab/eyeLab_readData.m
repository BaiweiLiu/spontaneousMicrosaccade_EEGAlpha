function eyeLab_readData()

%% Read the files
cd(goodness_file)
trCleanl_list=dir('*.mat');
trCleanl_list={trCleanl_list.name}; 

cd(epoch_file)
sublist=dir('*.mat');
sublist={sublist.name}; 

load([epoch_file filesep sublist{subjInd}]);

%% only keep channels of interest
cfg = [];
cfg.channel = channel;
data = ft_preprocessing(cfg, data_out);

%% removebad trials
if removeBadTrial
    load([goodness_file filesep trCleanl_list{subjInd}]);
    cfg = [];
    cfg.trials = data_out;
    data = ft_selectdata(cfg, data);
end

%% gaze analysis
cfg = [];
cfg.keeptrials = 'yes';
tl = ft_timelockanalysis(cfg, data);

%% self-adjust code
gaze.time = tl.time;
gaze.labelDim1 = {'probeL','probeR','probeLvsR','toward'};
gaze.labelDim2 = dim2Name;

chX = ismember(tl.label, 'eyeX');
chY = ismember(tl.label, 'eyeY');
gaze.X(subjInd,s1,s2,:) = squeeze(nanmean(tl.trial(sel1&sel2, chX,:)));
gaze.Y(subjInd,s1,s2,:) = squeeze(nanmean(tl.trial(sel1&sel2, chY,:)));
gaze.XSE(subjInd,s1,s2,:) = squeeze(nanstd(tl.trial(sel1&sel2, chX,:))) ./ sqrt(sum(sel1&sel2));
gaze.YSE(subjInd,s1,s2,:) = squeeze(nanstd(tl.trial(sel1&sel2, chY,:))) ./ sqrt(sum(sel1&sel2));

%% relevant contrasts...
gaze.X(subjInd,3,:,:) = gaze.X(subjInd,2,:,:) - gaze.X(subjInd,1,:,:); % probe R vs L
gaze.X(subjInd,4,:,:,:) = gaze.X(subjInd,3,:,:) ./ 2; % L min R divide by 2 gives towardness.

gaze.XSE(subjInd,3,:,:) = mean(gaze.XSE(subjInd,[1,2],:,:),2); % approximation of "pooled SE", just use avg SE of L and R.
gaze.XSE(subjInd, 4,:,:) = gaze.XSE(subjInd,3,:,:) ./ 2;  
end