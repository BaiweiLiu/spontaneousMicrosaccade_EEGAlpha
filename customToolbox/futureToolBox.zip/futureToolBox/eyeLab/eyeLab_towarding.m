function [eye_data] = eyeLab_towarding(cfg)

% function eyeLab_normalize(cfg)
% Description: normalize the data based on localiser
%
%       cfg.trig4right       
%       cfg.trig4top         
%       cfg.trig4left        
%       cfg.trig4bot       
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%
    
% extract para
v2struct(cfg); % cfg = eye_data,cal, write_dir, plotTitle 
load(normEye_dir)
keeptrl = false;
if keeptrl
    cfg = [];
    cfg.keeptrials = 'yes';
    eye_data=ft_timelockanalysis(cfg, eye_data);
end 

eye_data.trial_toward = nan(size(eye_data.trial,1),size(eye_data.trial,3));

if exist('trig4right')
    rightInd = ismember(eye_data.trialinfo(:,1), trig4right);
    eye_data.trial_toward(rightInd,:)  = eye_data.trial(rightInd,1,:);
end
if exist('trig4left')
    leftInd = ismember(eye_data.trialinfo(:,1), trig4left);
    eye_data.trial_toward(leftInd,:)  = - eye_data.trial(leftInd,1,:);
end

if exist('trig4top')
    topInd = ismember(eye_data.trialinfo(:,1), trig4top);
    eye_data.trial_toward(topInd,:)  = eye_data.trial(topInd,2,:);
end

if exist('trig4bot')
    trig4bot = ismember(eye_data.trialinfo(:,1), trig4bot);
    eye_data.trial_toward(trig4bot,:)  = - eye_data.trial(trig4bot,2,:);
end

end