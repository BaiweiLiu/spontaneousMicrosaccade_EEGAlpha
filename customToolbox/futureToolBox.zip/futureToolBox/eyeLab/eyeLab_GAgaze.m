function eyeLab_GAgaze(cfg)

% function eyeLab_GAgaze(cfg)
% Description: grand average the gaze resutls
%
%       cfg.data_file       = dir of to-be-averaged data;
%       cfg.goodness_file   = dir of events we use to select trial.
%       cfg.channel         = to be used channel;
%       cfg.valueTrig       = the trigger used to extract the value;
%       cfg.dataName        = uknow.
%       cfg.dim             = dimension of the data (1 means only raw data)
%       cfg.postEvent       = dir of post event
%       cfg.output_dir      = string specifiying the directory where the gazeShift files are;
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% extract value
v2struct(cfg); 
outfile = creatDir(output_dir);

%% Read the files
if exist('goodness_file')
    for goodInd  = 1: length(goodness_file)
        sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
    end
    
end
sublist_epoch = get_subFiles(data_file);

% cd(subEvents{1})
% eventList=dir('*.mat');
% eventList={eventList.name}; 

gaze = [];
%%
if dim == 1
    for subjInd = 1:length(sublist_epoch)
        
        %% read data
        cfg = [];
        cfg.input_dir = sublist_epoch{subjInd};
        if exist('goodness_file')
            cfg.goodness_file = inCellSelec(sublist_goodTl,subjInd);
        end
        cfg.channel = channel;
        [tl,trialOK] = eyeLab_readEye(cfg);
        
        %% self-adjust code
        GA_gaze.time = tl.time;
        GA_gaze.labelValue = {'probeL','probeR','probeLvsR','toward'};
        

        GA_gaze.labelDim2 = 'raw';
        
        for s1 = 1:size(valueTrig,2)
            sel1 = ismember(tl.trialinfo(:,1),valueTrig{s1});

%                 if exist('postEvent')
%                     
%                     if ~exist('eventFiled')
%                         load([postEvent{s2} filesep eventList{subjInd}])
%                         sel2 = events_sel;
%                     else
%                         load([postEvent{s2} filesep eventList{subjInd}],eventFiled);
%                         sel2 = logical(eval(eventFiled));
%                     end
%                     
% 
%                     sel2 = sel2(trialOK);
%                     
%                     sel2 = sel2';
%                 else
%                     sel2 = ismember(tl.trialinfo(:,1), cond_trigger{2}{s2});
%                 end

            chX = ismember(tl.label, 'eyeX');
            chY = ismember(tl.label, 'eyeY');

            GA_gaze.X(subjInd,s1,1,:) = squeeze(nanmean(tl.trial(sel1, chX,:)));
            GA_gaze.Y(subjInd,s1,1,:) = squeeze(nanmean(tl.trial(sel1, chY,:)));
            GA_gaze.XSE(subjInd,s1,1,:) = squeeze(nanstd(tl.trial(sel1, chX,:))) ./ sqrt(sum(sel1));
            GA_gaze.YSE(subjInd,s1,1,:) = squeeze(nanstd(tl.trial(sel1, chY,:))) ./ sqrt(sum(sel1));
            
        end    
        %% relevant contrasts...
        GA_gaze.X(subjInd,3,:,:) = GA_gaze.X(subjInd,2,:,:) - GA_gaze.X(subjInd,1,:,:); % probe R vs L
        GA_gaze.X(subjInd,4,:,:,:) = GA_gaze.X(subjInd,3,:,:) ./ 2; % L min R divide by 2 gives towardness.

        GA_gaze.XSE(subjInd,3,:,:) = mean(GA_gaze.XSE(subjInd,[1,2],:,:),2); % approximation of "pooled SE", just use avg SE of L and R.
        GA_gaze.XSE(subjInd, 4,:,:) = GA_gaze.XSE(subjInd,3,:,:) ./ 2;  
        
        GA_gaze.subjID{subjInd} = sublist_epoch{subjInd}(end-7:end-4);
    end
    
elseif dim == 2
    
    %% read postEvent
    if exist('postEvent')
        for subjInd = 1:length(sublist_epoch)
            %% read data
            cfg = [];
            cfg.input_dir = sublist_epoch{subjInd};
            if exist('goodness_file')
                cfg.goodness_file = inCellSelec(sublist_goodTl,subjInd);
            end
            cfg.channel = channel;
            [tl,trialOK] = eyeLab_readEye(cfg);
            
            %% self-adjust code
            GA_gaze.time = tl.time;
            GA_gaze.labelValue = {'probeL','probeR','probeLvsR','toward'};
            GA_gaze.labelDim2 = dim2Name;
            
            for s1 = 1:size(valueTrig,2)
                sel1 = ismember(tl.trialinfo(:,1),valueTrig{s1})';
                if size(sel1,2) >1
                    sel1 = sel1';
                end
                for s2 = 1: length(postEvent)

                    sublist_event = get_subFiles(postEvent{s2});
                    load(sublist_event{subjInd});
                    sel2 = event.sel(trialOK);
                    
                    chX = ismember(tl.label, 'eyeX');
                    chY = ismember(tl.label, 'eyeY');
                    
                    GA_gaze.X(subjInd,s1,s2,:) = squeeze(nanmean(tl.trial(sel1&sel2, chX,:)));
                    GA_gaze.Y(subjInd,s1,s2,:) = squeeze(nanmean(tl.trial(sel1&sel2, chY,:)));
                    GA_gaze.XSE(subjInd,s1,s2,:) = squeeze(nanstd(tl.trial(sel1&sel2, chX,:))) ./ sqrt(sum(sel1&sel2));
                    GA_gaze.YSE(subjInd,s1,s2,:) = squeeze(nanstd(tl.trial(sel1&sel2, chY,:))) ./ sqrt(sum(sel1&sel2));
                end  
            end
            %% relevant contrasts...
            GA_gaze.X(subjInd,3,:,:) = GA_gaze.X(subjInd,2,:,:) - GA_gaze.X(subjInd,1,:,:); % probe R vs L
            GA_gaze.X(subjInd,4,:,:,:) = GA_gaze.X(subjInd,3,:,:) ./ 2; % L min R divide by 2 gives towardness.

            GA_gaze.XSE(subjInd,3,:,:) = mean(GA_gaze.XSE(subjInd,[1,2],:,:),2); % approximation of "pooled SE", just use avg SE of L and R.
            GA_gaze.XSE(subjInd, 4,:,:) = GA_gaze.XSE(subjInd,3,:,:) ./ 2;  

            GA_gaze.subjID{subjInd} = sublist_epoch{subjInd}(end-7:end-4);
        end
            
    elseif exist('condTrig')
        123
    end
else
     for subjInd = 1:length(sublist)
        load([epoch_file filesep sublist{subjInd}]);

        %% only keep channels of interest
        cfg = [];
        cfg.channel = channel;
        data = ft_preprocessing(cfg, data_out);

        %% removebad trials    
        load([goodness_file filesep sublist{subjInd}]);
        cfg = [];
        cfg.trials = data_out;
        data = ft_selectdata(cfg, data);

        %% gaze analysis
        cfg = [];
        cfg.keeptrials = 'yes';
        tl = ft_timelockanalysis(cfg, data);

        %% self-adjust code
        gaze.time = tl.time;
        gaze.labelDim1 = {'probeL','probeR','probeLvsR','toward'};
        gaze.labelDim2 = dim2Name;
        gaze.labelDim3 = dim3Name;
        for s1 = 1:size(cond_trigger{1},2)
            for s2 = 1:size(cond_trigger{2},2)
                for s3 = 1:size(cond_trigger{3},2)
                sel1 = ismember(tl.trialinfo(:,1),cond_trigger{1}{s1});
                sel2 = ismember(tl.trialinfo(:,1), cond_trigger{2}{s2});
                sel3 = ismember(tl.trialinfo(:,1), cond_trigger{3}{s3});
                
                chX = ismember(tl.label, 'eyeX');
                chY = ismember(tl.label, 'eyeY');
                gaze.X(subjInd,s1,s2,s3,:) = squeeze(nanmean(tl.trial(sel1&sel2&sel3, chX,:)));
                gaze.Y(subjInd,s1,s2,s3,:) = squeeze(nanmean(tl.trial(sel1&sel2&sel3, chY,:)));
                gaze.XSE(subjInd,s1,s2,s3,:) = squeeze(nanstd(tl.trial(sel1&sel2&sel3, chX,:))) ./ sqrt(sum(sel1&sel2&sel3));
                gaze.YSE(subjInd,s1,s2,s3,:) = squeeze(nanstd(tl.trial(sel1&sel2&sel3, chY,:))) ./ sqrt(sum(sel1&sel2&sel3));
                end
            end
        end    
        %% relevant contrasts...
        gaze.X(subjInd,3,:,:,:) = gaze.X(subjInd,2,:,:,:) - gaze.X(subjInd,1,:,:,:); % probe R vs L
        gaze.X(subjInd,4,:,:,:) = gaze.X(subjInd,3,:,:,:) ./ 2; % L min R divide by 2 gives towardness.

        gaze.XSE(subjInd,3,:,:,:) = mean(gaze.XSE(subjInd,[1,2],:,:,:),2); % approximation of "pooled SE", just use avg SE of L and R.
        gaze.XSE(subjInd,4,:,:,:) = gaze.XSE(subjInd,3,:,:,:) ./ 2;  
     end
end

save([outfile filesep 'GA_' dataName '.mat'], 'GA_gaze');
end