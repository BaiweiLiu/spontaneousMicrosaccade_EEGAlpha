function [data_out] = eyeLab_normalize(cfg)

% function eyeLab_normalize(cfg)
% Description: normalize the data based on localiser
%
%       cfg.epoch_dir        = dir of epoch eye data;
%       cfg.locl_dir         = dir of localiser data.
%       cfg.output_dir        = uknow.
%       cfg.plotTitle       = the slide windows
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%
    
% extract para
v2struct(cfg); % cfg = eye_data,cal, write_dir, plotTitle 
load(epoch_dir)
load(locl_dir)

output_file = creatDir(output_dir);

%% select data...
cfg = [];
cfg.channel = {'eyeX' 'eyeY'};
data = ft_selectdata(cfg, eye_data);

%% tl
cfg = [];
cfg.keeptrials = 'yes';
tl = ft_timelockanalysis(cfg, data);

%%
% norm X
tl.trial2(:,1,:) = ((tl.trial(:,1,:) - cal.centerX) ./ (cal.distX/2)) * 100; % percentage of gaze localiser pos
tl.trial2(:,2,:) = ((tl.trial(:,2,:) - cal.centerY) ./ (cal.distY/2)) * 100; % percentage of gaze localiser pos
tl.trial = squeeze(tl.trial2);

data_out = tl;
eye_data = tl;
save([output_file filesep plotTitle '.mat'],'eye_data');

end