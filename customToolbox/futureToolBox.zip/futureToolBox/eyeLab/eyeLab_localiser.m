function [data_out] = eyeLab_localiser(cfg)

v2struct(cfg); % cfg = eye_data, localiser_triggers, plotTitle, averg_time

load(input_dir)
eye_data  = liser_data;

cfg = [];
out_file1 = [output_dir filesep 'figure'];
out_file2 = [output_dir filesep 'data'];
if ~exist(out_file1,'dir') ; mkdir(out_file1); end  
if ~exist(out_file2,'dir') ; mkdir(out_file2); end  

cfg.channel = {'eyeX','eyeY'};
data = ft_selectdata(cfg, eye_data);

cfg.channel = {'eyeX'};
data_x = ft_selectdata(cfg, eye_data);

cfg.channel = {'eyeY'};
data_y = ft_selectdata(cfg, eye_data);
clear liser_data

cfg = [];
cfg.keeptrials = 'yes';
tl = ft_timelockanalysis(cfg, data);    

%% get condition indices
if length(localiser_triggers) == 9
    left = ismember(tl.trialinfo(:,1), localiser_triggers(1:3)); vert_l = left *1;
    vert_cent = ismember(tl.trialinfo(:,1), localiser_triggers(4:6)); vert_c = vert_cent *2;
    right = ismember(tl.trialinfo(:,1), localiser_triggers(7:9)); vert_r = right *3;
    top = ismember(tl.trialinfo(:,1), localiser_triggers([1,4,7]));hor_t = top *1;
    hori_cent = ismember(tl.trialinfo(:,1), localiser_triggers([2,5,8])); hor_c = hori_cent *2;
    bot = ismember(tl.trialinfo(:,1), localiser_triggers([3,6,9]));hor_b = bot *3;
    center = ismember(tl.trialinfo(:,1), localiser_triggers(5));
elseif length(localiser_triggers) == 7
    left = ismember(tl.trialinfo(:,1), localiser_triggers(1:3)); vert_l = left *1;
    vert_cent = ismember(tl.trialinfo(:,1), localiser_triggers(4)); vert_c = vert_cent *2;
    right = ismember(tl.trialinfo(:,1), localiser_triggers(5:7)); vert_r = right *3;
    top = ismember(tl.trialinfo(:,1), localiser_triggers([1,5]));hor_t = top *1;
    hori_cent = ismember(tl.trialinfo(:,1), localiser_triggers([2,4,6])); hor_c = hori_cent *2;
    bot = ismember(tl.trialinfo(:,1), localiser_triggers([3,7]));hor_b = bot *3;
    center = ismember(tl.trialinfo(:,1), localiser_triggers(4));
end

vert = vert_l + vert_c + vert_r;
vert = cond_num2str(vert, [1:3], {'Left' 'Cent' 'Right'});
hori = hor_t + hor_c + hor_b;
hori = cond_num2str(hori,[1:3], {'Top' 'Cent' 'Bot'});

cond_data = [];
color_c = 0;
for trig_ind = 1:length(localiser_triggers)
    cond_data(trig_ind,:) = ismember(tl.trialinfo(:,1), [localiser_triggers(trig_ind)]);
    color_c = cond_data(trig_ind,:) * trig_ind + color_c;
end
if length(localiser_triggers) == 9
    color_c = cond_num2str(color_c, [1:9], {'left_bot', 'left_middle', 'left_top', 
                             'center_bot', 'center_middle','center_top', 
                            'right_bot', 'right_middle', 'right_top'});
elseif length(localiser_triggers) == 7
    color_c = cond_num2str(color_c, [1:7], {'left_top', 'left_middle', 'left_bot', 'center_middle' ,'right_top', 'right_middle', 'right_bot'});
end
%% normalize
sel = tl.time >= averg_time(1) & tl.time <= averg_time(2);
cal.centerX = squeeze(nanmedian(nanmean(tl.trial(center,1,sel),3)));
cal.centerY = squeeze(nanmedian(nanmean(tl.trial(center,2,sel),3)));
cal.leftX = squeeze(nanmedian(nanmean(tl.trial(left,1,sel),3)));
cal.rightX = squeeze(nanmedian(nanmean(tl.trial(right,1,sel),3)));
cal.distX = cal.rightX-cal.leftX;
cal.topY = squeeze(nanmedian(nanmean(tl.trial(top,2,sel),3)));
cal.bottomY = squeeze(nanmedian(nanmean(tl.trial(bot,2,sel),3)));
cal.distY = cal.bottomY-cal.topY; 

cal.ninePointsX = [cal.leftX cal.leftX cal.leftX cal.centerX cal.centerX cal.centerX cal.rightX cal.rightX cal.rightX];
cal.ninePointsY = [cal.bottomY cal.centerY cal.topY cal.bottomY cal.centerY cal.topY cal.bottomY cal.centerY cal.topY];
% norm X
tl.trial2(:,1,:) = ((tl.trial(:,1,:) - cal.centerX) ./ (cal.distX/2)) * 100; % percentage of gaze localiser pos
tl.trial2(:,2,:) = -((tl.trial(:,2,:) - cal.centerY) ./ (cal.distY/2)) * 100; % flip top-bottom so that top is positive!
%% plot 
ylimits = [0 sc_size(1)];
figure('Position',[100 100 1500 1200]);
g(1,1) = gramm('x',tl.time, 'y',data_x.trial,'color',vert);
g(1,1).geom_line();
g(1,1).set_title(['Gaze change in x axis: ' plotTitle]);
g(1,1).axe_property('YLim',ylimits);
g(1,1).set_order_options('color',1);
g(1,1).set_names('x','Time','y','X axis in Screen');

ylimits = [0 sc_size(2)];
g(1,2) = gramm('x',tl.time, 'y',data_y.trial,'color',hori);
g(1,2).geom_line();
g(1,2).set_title(['Gaze change in y axis: ' plotTitle]);
g(1,2).axe_property('YLim',ylimits);
g(1,2).set_order_options('color',1);
g(1,2).set_names('x','Time','y','Y axis in Screen');

%%
tsel = tl.time >= averg_time(1) & tl.time <= averg_time(2);
ylimits = [0 sc_size(2)];
xlimits = [0 sc_size(1)];
x1 = squeeze(nanmean(tl.trial(:,1,tsel),3));
y1 = squeeze(nanmean(tl.trial(:,2,tsel),3));
g(2,1)=gramm('x',x1','y',y1','color',color_c);
g(2,1).geom_point();
g(2,1).set_title('color');
g(2,1).set_title(['Averaged Gaze Position: ' plotTitle]);
g(2,1).axe_property('YLim',ylimits,'XLim', xlimits);

x1 = squeeze(nanmean(tl.trial2(:,1,tsel),3));
y1 = squeeze(nanmean(tl.trial2(:,2,tsel),3));
g(2,2)=gramm('x',x1','y',y1','color',color_c);
g(2,2).geom_point();
g(2,2).set_title('color');
g(2,2).set_title(['Normalized Averaged Gaze Position: ' plotTitle]);
g(2,2).axe_property('YLim',[-200 200],'YTick',[-100: 40: 100], 'XLim', [-200 200],'XTick',[-100: 40: 100]);

g(2,:).set_names('x','X axis in screen','y','Y axis in Screen');

g.set_point_options('base_size', 10);
g.set_text_options('base_size',15,'label_scaling',1.4);
g.draw();

norm_point =[];
for x_p = [100, 0, -100]
    for y_p = [100, 0, -100]
        norm_point(end+1,:) = [x_p y_p];
    end
end

scatter(cal.ninePointsX, cal.ninePointsY,100,'+','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','k','Parent',g(2,1).facet_axes_handles(1)); 
scatter(norm_point(:,1), norm_point(:,2),100,'+','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','k','Parent',g(2,2).facet_axes_handles(1)); 

line([averg_time(1) averg_time(1)],[0 sc_size(1)],'Color','k','LineStyle','--','LineWidth',1, 'Parent',g(1,1).facet_axes_handles(1));
line([averg_time(2) averg_time(2)],[0 sc_size(1)],'Color','k','LineStyle','--','LineWidth',1, 'Parent',g(1,1).facet_axes_handles(1));
line([averg_time(1) averg_time(1)],[0 sc_size(2)],'Color','k','LineStyle','--','LineWidth',1, 'Parent',g(1,2).facet_axes_handles(1));
line([averg_time(2) averg_time(2)],[0 sc_size(2)],'Color','k','LineStyle','--','LineWidth',1, 'Parent',g(1,2).facet_axes_handles(1));

%% save
imagewd = getframe(gcf);
imwrite(imagewd.cdata, [out_file1 filesep plotTitle '.tiff']);

save([out_file2 filesep plotTitle '.mat'],'cal');
end

