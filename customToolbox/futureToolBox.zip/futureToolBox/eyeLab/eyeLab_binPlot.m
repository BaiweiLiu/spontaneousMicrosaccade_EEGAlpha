function eyeLab_binPlot(cfg)

% function eyeLab_binPlot(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.time2plot       = the range of time you want to bin;
%       cfg.Zscore          = bin it in every x ms.
%       cfg.plotType        = 'indiv' or 'sum' plot?
%       cfg.input_file      = string specifiying the directory where the GA data is;
%       cfg.rejectSubj      = [] Name of subj that need be removed in
%       analysis (only works in sum level)
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% default values
cmap = brewermap([],'*RdBu');

% extract cfg value
v2struct(cfg);

% load GA data
load(input_file)

% selec subjects
subInd_ok = ones(1,length(GA_eye.subjName));
if exist('rejectSubj')
    for subInd = 1: length(GA_eye.subjName);
        if  sum(strcmp(GA_eye.subjName(subInd), rejectSubj))>0
            subInd_ok(subInd) = 0;
        end
    end
end
subInd_ok = logical(subInd_ok);

if strcmp(plotType, 'indiv')
    for subjInd =1:size(GA_eye.gaze,1)
        if subInd_ok(subjInd)
            subplot(5,5,subjInd)
            contourf(GA_eye.time * 1000,GA_eye.timeBin,squeeze(GA_eye.gaze(subjInd,:,:)),50,'linecolor','none')
            cl=get(gca,'clim'); title(GA_eye.subjName{subjInd})
            xlim(time2plot)
            caxis(Zscore)
            colorbar
            colormap((cmap))
            hold on
            line([GA_eye.timeBin(1) GA_eye.timeBin(end)], [GA_eye.timeBin(1) GA_eye.timeBin(end)],'Color','k');
            line([0,0], [GA_eye.timeBin(1) GA_eye.timeBin(end)],'Color','k');
        end
    end
elseif strcmp(plotType, 'sum')
    gaze_sum = squeeze(nanmean(GA_eye.gaze(subInd_ok,:,:)));
    contourf(GA_eye.time * 1000,GA_eye.timeBin,gaze_sum,50,'linecolor','none')
    cl=get(gca,'clim'); title('sum')
    xlim(time2plot)
    caxis([-10 10])
    colorbar
    colormap((cmap))
    hold on
    line([GA_eye.timeBin(1) GA_eye.timeBin(end)], [GA_eye.timeBin(1) GA_eye.timeBin(end)],'Color','k');
    line([0,0], [GA_eye.timeBin(1) GA_eye.timeBin(end)],'Color','k');
end

end