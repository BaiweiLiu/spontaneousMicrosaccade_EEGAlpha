function eyeLab_mSaccDetect(cfg)

% default value
plotFig = false;
smooth_step = 7; % length of smooth window
smooth_raw = false; % smooth raw data ?
smooth_der = true; % smooth velocity data ?
smooth_der2 = true; % smooth velocity2 data ?
winbef = [50 0]; % time window for detecting the postion before saccade ?
winaft = [50 100]; % time window for detecting the postion after saccade ?
minISI = 100; % the mini time for avoiding detecting same shift
ntrl = 5; % for plotting
threshold = 5; % the velocity threshold (*median) for detecting shift 
minDis = 1; % the displacement threshold (*normalized data) for detecting shift 
layout_sti = 'left_right_nonTar'; % layout_sti in memory
% cfg run_smooth, 
v2struct(cfg);

disp(['Processing ' subjID ' ########################################'])

load(read_file)
out_dir = creatDir([output_dir]);

%% keep trial and channel
cfg = [];

if strcmp(layout_sti, 'left_right') | strcmp(layout_sti, 'left_right_nonTar')
    cfg.channel            = 'eyeX';
elseif strcmp(layout_sti, 'left_right_top_bot') 
    cfg.channel            = {'eyeX' 'eyeY'}; 
end

cfg.keeptrials         = 'yes';
eye_data = ft_timelockanalysis(cfg, eye_data);

cfg = [];
cfg.keeptrials         = 'yes';
eye_data = ft_timelockanalysis(cfg, eye_data);

%% set time
time = eye_data.time * 1000;
time_der = time(2:end);
time_der2 = time(3:end);

%% creat data struct
data = [];

if strcmp(layout_sti, 'left_right') | strcmp(layout_sti, 'left_right_nonTar')
    data.gaze_raw = squeeze(eye_data.trial);
elseif strcmp(layout_sti, 'left_right_top_bot') 
    data.gaze_raw = nan(size(eye_data.trial,1),size(eye_data.trial,3));
    left_rightInd = ismember(eye_data.trialinfo(:,1), [trig_left trig_right]);
    data.gaze_raw(left_rightInd,:)  = eye_data.trial(left_rightInd,1,:); 
    
    top_botInd = ismember(eye_data.trialinfo(:,1), [trig_top trig_bot]);
    data.gaze_raw(top_botInd,:)  = eye_data.trial(top_botInd,2,:); 
end

%% smooth raw data
if smooth_raw
    data.gaze_raw_sm = smoothdata(data.gaze_raw,2,'gaussian',smooth_step);
else
    data.gaze_raw_sm = data.gaze_raw;
end

%% get  derivative
% velocity
data.der = diff(data.gaze_raw_sm,1,2);
data.absder = abs(data.der);

if smooth_der
    data.der_sm = smoothdata(data.der,2,'gaussian',smooth_step);
    data.absder_sm = smoothdata(data.absder,2,'gaussian',smooth_step);
else
    data.der_sm = data.der;
    data.absder_sm = data.absder;
end

% second-order derivative (i.e. acceleration)
data.der2 = diff(data.der,1,2);
data.absder2 = abs(data.der2);

if smooth_der2
    data.der2_sm = smoothdata(data.der2,2,'gaussian',smooth_step);
    data.absder2_sm = smoothdata(data.absder2,2,'gaussian',smooth_step);
else
    data.der2_sm = data.der2;
    data.absder2_sm = data.absder2;
end

if exist('fix_twin')
    % get position of fixtion for every trials
    tsort = dsearchn(time', fix_twin')';
    fix_pos = nanmedian(data.gaze_raw(:,tsort(1):tsort(2)),2);
end

%% plot a few trials
if plotFig
    perm = randperm(size(data.gaze_raw,1));
    colorMaker = [repmat({'raw'},1,ntrl) repmat({'smooth'},1,ntrl)];
    figure('Position',[100 100 ntrl*400 500]);
    y = D2array2Cell([ data.gaze_raw_sm(perm(1:5),:)]);
    g(1,1)= gramm('x',time, 'y', y);
    g(1,1).geom_line()
    g(1,1).facet_grid([],[1:5])

    y = D2array2Cell([data.absder_sm(perm(1:5),:)]);
    g(2,1)= gramm('x',time_der, 'y', y);
    g(2,1).geom_line()
    g(2,1).facet_grid([],[1:5])

    g.set_text_options('base_size',15,'label_scaling',1.4);
    g(1,1).set_names('x','Time (0 = onset of probe)','y','Gaze postion','column','trial');
    g(2,1).set_names('x','Time (0 = onset of probe)','y','velocity','column','trial');
    g.draw()

    for i = 1:ntrl
        med1 = nanmedian(data.absder_sm(i,:));
        med2 = nanmedian(data.absder2_sm(i,:));

        mean1 = nanmean(data.absder_sm(i,:));
        mean2 = nanmean(data.absder2_sm(i,:));

         % find shifts and mark them in raw traces        
        trl2pl = perm(i);
        idx = 0; shifts = []; dbef = []; daft = [];
        dat2use = data.absder_sm(trl2pl,:);
        datorig = data.gaze_raw(trl2pl,:);   
        for t = winbef+1:length(time_der)-minISI;           
            if dat2use(t) >= med1 * threshold 
                threshold_num = dat2use(t) / med1;
                idx = idx+1; 
                shifts(idx) = time_der(t); dat2use(t+1:t+minISI) = 0;
                dbef(idx) = nanmean(datorig([t-winbef])); 
                daft(idx) = nanmean(datorig([t+winaft])); 
                med_gaze_raw = nanmedian(data.gaze_raw(trl2pl,:));
                if abs(dbef(idx) - daft(idx)) > minDis

                    line([time_der(t) time_der(t)],[med_gaze_raw-20 med_gaze_raw+20],'Color','k','LineStyle','--','LineWidth', 1, 'Parent',g(1,1).facet_axes_handles(i))
                    line([shifts(idx) - winbef],[dbef(idx) dbef(idx)],'Color','k','LineStyle','-','LineWidth', 3,'Parent',g(1,1).facet_axes_handles(i))
                    line([shifts(idx) + winaft],[daft(idx) daft(idx)],'Color','k','LineStyle','-','LineWidth', 3,'Parent',g(1,1).facet_axes_handles(i))
                else
                    line([time_der(t) time_der(t)],[med_gaze_raw-20 med_gaze_raw+20],'Color','r','LineStyle','--','LineWidth', 1, 'Parent',g(1,1).facet_axes_handles(i))
                end
            end
        end

        line([time(1) time(end)], [med1*threshold med1*threshold],'Color','k','LineStyle','--','Parent',g(2,1).facet_axes_handles(i)) 
    end
end

%%
if strcmp(layout_sti, 'left_right')
    
    gaze_toward_left = zeros(size(data.gaze_raw()));
    gaze_vel_threshold  = zeros(size(data.gaze_raw()));
    gaze_away_left = zeros(size(data.gaze_raw()));
    gaze_toward_right = zeros(size(data.gaze_raw()));
    gaze_away_right = zeros(size(data.gaze_raw()));
    gaze_unTrust = zeros(size(data.gaze_raw()));
    power_toward_left = NaN(size(data.gaze_raw()));
    power_away_left = NaN(size(data.gaze_raw()));
    power_toward_right = NaN(size(data.gaze_raw()));
    power_away_right = NaN(size(data.gaze_raw()));

    for i = 1:size(data.gaze_raw(),1)
        
        med1 = nanmedian(data.absder_sm(i,:));
        med2 = nanmedian(data.absder2_sm(i,:));

         % find shifts and mark them in raw traces        
        idx = 0; shifts = []; dbef = []; daft = [];
        dat2use = data.absder_sm(i,:);
        datorig = data.gaze_raw(i,:);   
        for t = winbef+1:length(time_der)-minISI;           
            if dat2use(t) >= med1 * threshold 
                threshold_num = dat2use(t) / med1; % current threshold 
                idx = idx+1; 
                shifts(idx) = time_der(t); dat2use(t+1:t+minISI) = 0;
                dbef(idx) = nanmean(datorig([t-winbef])); % data before
                daft(idx) = nanmean(datorig([t+winaft])); % data after
                med_gaze_raw = nanmedian(data.gaze_raw(i,:));
                if abs(dbef(idx) - daft(idx)) > minDis
                    gaze_vel_threshold(i, t+1) = max(dat2use(t-50:t+50) ./ med1);
                    sacc_corr = false;
                    if exist('fix_twin') 
                        fix_tl = fix_pos(i);
                        startDis = abs(dbef(idx) - fix_tl);
                        endDis = abs(daft(idx) - fix_tl);
                        if strcmp(saccType, 'start')
                            sacc_corr = startDis < endDis;
                        elseif strcmp(saccType, 'return')
                            sacc_corr = startDis > endDis;
                        end
                    else
                        sacc_corr = true;
                    end
                    
                    if ismember(eye_data.trialinfo(i),trig_left) & sacc_corr
                        if dbef(idx) > daft(idx) 
                            gaze_toward_left(i, t+1) = 1;
                            power_toward_left(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_away_left(i, t+1) = 1;
                            power_away_left(i, t+1) = dbef(idx) - daft(idx);
                        end
                    elseif ismember(eye_data.trialinfo(i),trig_right)  & sacc_corr
                        if dbef(idx) > daft(idx) 
                            gaze_away_right(i, t+1) = 1;
                            power_away_right(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_toward_right(i, t+1) = 1;
                            power_toward_right(i, t+1) = dbef(idx) - daft(idx);
                        end
                    end
                else
                    gaze_unTrust(i, t+1) = 1;   
                end
            end
        end
    end
    gazeShift = [];
    gazeShift.gazeL_to = gaze_toward_left;
    gazeShift.thre_gazeVol = gaze_vel_threshold;
    gazeShift.gazeL_aw = gaze_away_left;
    gazeShift.gazeR_to = gaze_toward_right;
    gazeShift.gazeR_aw = gaze_away_right;
    gazeShift.gazeUnTrust = gaze_unTrust;
    gazeShift.powerL_to = power_toward_left;
    gazeShift.powerL_aw = power_away_left;
    gazeShift.powerR_to = power_toward_right;
    gazeShift.powerR_aw = power_away_right;
    gazeShift.trialinfo = eye_data.trialinfo;
    gazeShift.time = eye_data.time;
    gazeShift.subjID = subjID;
    
elseif strcmp(layout_sti, 'left_right_top_bot')
    
    gaze_vel_threshold  = zeros(size(data.gaze_raw()));
    
    gaze_toward_left = zeros(size(data.gaze_raw()));
    gaze_away_left = zeros(size(data.gaze_raw()));
    gaze_toward_right = zeros(size(data.gaze_raw()));
    gaze_away_right = zeros(size(data.gaze_raw()));
    gaze_toward_top = zeros(size(data.gaze_raw()));
    gaze_away_top = zeros(size(data.gaze_raw()));
    gaze_toward_bot = zeros(size(data.gaze_raw()));
    gaze_away_bot = zeros(size(data.gaze_raw()));
    
    gaze_unTrust = zeros(size(data.gaze_raw()));
    power_toward_left = NaN(size(data.gaze_raw()));
    power_away_left = NaN(size(data.gaze_raw()));
    power_toward_right = NaN(size(data.gaze_raw()));
    power_away_right = NaN(size(data.gaze_raw()));
    power_toward_top = NaN(size(data.gaze_raw()));
    power_away_top = NaN(size(data.gaze_raw()));
    power_toward_bot = NaN(size(data.gaze_raw()));
    power_away_bot = NaN(size(data.gaze_raw()));

    for i = 1:size(data.gaze_raw(),1)
        
        med1 = nanmedian(data.absder_sm(i,:));
        med2 = nanmedian(data.absder2_sm(i,:));

         % find shifts and mark them in raw traces        
        idx = 0; shifts = []; dbef = []; daft = [];
        dat2use = data.absder_sm(i,:);
        datorig = data.gaze_raw(i,:);   
        for t = winbef+1:length(time_der)-minISI;           
            if dat2use(t) >= med1 * threshold 
                threshold_num = dat2use(t) / med1; % current threshold 
                idx = idx+1; 
                shifts(idx) = time_der(t); dat2use(t+1:t+minISI) = 0;
                dbef(idx) = nanmean(datorig([t-winbef])); % data before
                daft(idx) = nanmean(datorig([t+winaft])); % data after
                med_gaze_raw = nanmedian(data.gaze_raw(i,:));
                if abs(dbef(idx) - daft(idx)) > minDis
                    gaze_vel_threshold(i, t+1) = max(dat2use(t-50:t+50) ./ med1);
                    sacc_corr = false;
                    if exist('fix_twin') 
                        fix_tl = fix_pos(i);
                        startDis = abs(dbef(idx) - fix_tl);
                        endDis = abs(daft(idx) - fix_tl);
                        if strcmp(saccType, 'start')
                            sacc_corr = startDis < endDis;
                        elseif strcmp(saccType, 'return')
                            sacc_corr = startDis > endDis;
                        end
                    else
                        sacc_corr = true;
                    end
                    
                    if ismember(eye_data.trialinfo(i),trig_left) & sacc_corr
                        if dbef(idx) > daft(idx) 
                            gaze_toward_left(i, t+1) = 1;
                            power_toward_left(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_away_left(i, t+1) = 1;
                            power_away_left(i, t+1) = dbef(idx) - daft(idx);
                        end
                    elseif ismember(eye_data.trialinfo(i),trig_right)  & sacc_corr
                        if dbef(idx) > daft(idx) 
                            gaze_away_right(i, t+1) = 1;
                            power_away_right(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_toward_right(i, t+1) = 1;
                            power_toward_right(i, t+1) = dbef(idx) - daft(idx);
                        end
                        
                     elseif ismember(eye_data.trialinfo(i),trig_top)  & sacc_corr
                         
                        if dbef(idx) > daft(idx) 
                            gaze_away_top(i, t+1) = 1;
                            power_away_top(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_toward_top(i, t+1) = 1;
                            power_toward_top(i, t+1) = dbef(idx) - daft(idx);
                        end
                        
                      elseif ismember(eye_data.trialinfo(i),trig_bot)  & sacc_corr
                          
                        if dbef(idx) > daft(idx) 
                            gaze_toward_bot(i, t+1) = 1;
                            power_toward_bot(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_away_bot(i, t+1) = 1;
                            power_away_bot(i, t+1) = dbef(idx) - daft(idx);
                        end
                    end
                else
                    gaze_unTrust(i, t+1) = 1;   
                end
            end
        end
    end
    gazeShift = [];
    gazeShift.thre_gazeVol = gaze_vel_threshold;
    
    gazeShift.gazeL_to = gaze_toward_left;
    gazeShift.gazeL_aw = gaze_away_left;
    gazeShift.gazeR_to = gaze_toward_right;
    gazeShift.gazeR_aw = gaze_away_right;
    gazeShift.gazeT_to = gaze_toward_top;
    gazeShift.gazeT_aw = gaze_away_top;
    gazeShift.gazeB_to = gaze_toward_bot;
    gazeShift.gazeB_aw = gaze_away_bot;
    
    gazeShift.gazeUnTrust = gaze_unTrust;
    gazeShift.powerL_to = power_toward_left;
    gazeShift.powerL_aw = power_away_left;
    gazeShift.powerR_to = power_toward_right;
    gazeShift.powerR_aw = power_away_right;
    gazeShift.powerT_to = power_toward_top;
    gazeShift.powerT_aw = power_away_top;
    gazeShift.powerB_to = power_toward_bot;
    gazeShift.powerB_aw = power_away_bot;
    
    gazeShift.trialinfo = eye_data.trialinfo;
    gazeShift.time = eye_data.time;
    gazeShift.subjID = subjID;
    
elseif strcmp(layout_sti, 'left_right_nonTar')
    
    gaze_left = zeros(size(data.gaze_raw()));
    gaze_right = zeros(size(data.gaze_raw()));
    power_left = zeros(size(data.gaze_raw()));
    power_right = zeros(size(data.gaze_raw()));
    gaze_startPos = zeros(size(data.gaze_raw()));
    gaze_endPos = zeros(size(data.gaze_raw()));
    gaze_unTrust = zeros(size(data.gaze_raw()));
    gaze_vel_threshold  = zeros(size(data.gaze_raw()));
    
    for i = 1:size(data.gaze_raw(),1)
        med1 = nanmedian(data.absder_sm(i,:));
        %med2 = nanmedian(data.absder2_sm(i,:));

         % find shifts and mark them in raw traces        
        idx = 0; shifts = []; dbef = []; daft = [];
        
        % pick the trial data shift and raw
        dat2use = data.absder_sm(i,:);
        datorig = data.gaze_raw(i,:);   
        
        % find cluster 
        for t = winbef+1:length(time_der)-minISI;           
            if dat2use(t) >= med1 * threshold 
                threshold_num = dat2use(t) / med1;
                idx = idx+1; 
                shifts(idx) = time_der(t); dat2use(t+1:t+minISI) = 0;
                dbef(idx) = nanmean(datorig([t-winbef])); 
                daft(idx) = nanmean(datorig([t+winaft])); 
                med_gaze_raw = nanmedian(data.gaze_raw(i,:));
                if abs(dbef(idx) - daft(idx)) > minDis
                    gaze_vel_threshold(i, t+1) = threshold_num;
                        if dbef(idx) > daft(idx) 
                            gaze_left(i, t+1) = 1;
                            power_left(i, t+1) = dbef(idx) - daft(idx);
                        elseif dbef(idx) < daft(idx) 
                            gaze_right(i, t+1) = 1;
                            power_right(i, t+1) = dbef(idx) - daft(idx);   
                        end
                    gaze_startPos(i, t+1) = dbef(idx);
                    gaze_endPos(i, t+1) = daft(idx);
                else
                    gaze_unTrust(i, t+1) = 1;
                end
            end
        end
    end
    gazeShift = [];
    gazeShift.gazeL = gaze_left;
    gazeShift.gazeR = gaze_right;
    gazeShift.thre_gazeVol = gaze_vel_threshold;
    gazeShift.powerL = power_left;
    gazeShift.gazeUnTrust = gaze_unTrust;
    gazeShift.powerR = power_right;
    gazeShift.gaze_startPos = gaze_startPos;
    gazeShift.gaze_endPos = gaze_endPos;
    gazeShift.trialinfo = eye_data.trialinfo;
    gazeShift.time = eye_data.time;
    gazeShift.subjID = read_file(end-7:end-4);
end
save([out_dir filesep subjID '.mat'], 'gazeShift');
end
