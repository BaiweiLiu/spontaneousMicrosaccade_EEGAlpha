function [data_output]=eyeLab_detectShift_Engbert(cfg, eye_dataX, eye_dataY,time)

% set default value, if user did not specify
if isfield(cfg,  'threshold');      else cfg.threshold = 6;     end
if isfield(cfg,  'velocityBraketMS');      else cfg.velocityBraketMS = 20 ;     end %ms
if isfield(cfg,  'sampleRate');      else cfg.sampleRate = 1000 ;     end %ms
if isfield(cfg,  'MinimalDurationMS');      else cfg.MinimalDurationMS = 12 ;     end %ms
if isfield(cfg,  'MinimalSeparationMS');      else cfg.MinimalSeparationMS = 12 ;     end %ms

% caculated the DeltaT and BracketInSamples in one side
DeltaT= 1000/cfg.sampleRate;
BracketInSamples= ceil((cfg.velocityBraketMS/DeltaT-1)/2);
CommonFactor= 2*sum(1:BracketInSamples)*DeltaT/1000;

% creat data 
data_eye = [];
data_eye.gaze_rawX = squeeze(eye_dataX(:,:,:));
data_eye.gaze_rawY = squeeze(eye_dataY(:,:,:));

numTrl = size(data_eye.gaze_rawX,1);
timePoints = size(data_eye.gaze_rawX,3);

% creat data velocity 
velX = NaN(2,numTrl,timePoints);
velY = NaN(2,numTrl,timePoints);

for eyeInd = 1:2
    for timeInd = BracketInSamples + 1:timePoints - BracketInSamples

        velX(eyeInd,:,timeInd) = sum(data_eye.gaze_rawX(:,eyeInd,timeInd+[1:BracketInSamples]) - data_eye.gaze_rawX(:,eyeInd,timeInd-[1:BracketInSamples]),3) ./CommonFactor;
        velY(eyeInd,:,timeInd) = sum(data_eye.gaze_rawY(:,eyeInd,timeInd+[1:BracketInSamples]) - data_eye.gaze_rawY(:,eyeInd,timeInd-[1:BracketInSamples]),3) ./CommonFactor;

    end
end
vel2d_eye= hypot(velX, velY);

%% computing velocity thresholds
thresholdX= cfg.threshold.*sqrt( nanmedian(velX.^2, 3) - (nanmedian(velX, 3).^2) );
thresholdY= cfg.threshold.*sqrt( nanmedian(velY.^2, 3) - (nanmedian(velY, 3).^2) );
for eyeInd= 1:2
    velInThreshold(eyeInd,:, :)= hypot(velX(eyeInd,:, :)./thresholdX(eyeInd,:), velY(eyeInd,:, :)./thresholdY(eyeInd,:));
end

%% locating possible events for each eye separately
%  merging saccades into a longer ones if temporal separation is small
EyeSaccades= [];
Saccades= [];
Nothing= 0;
for eyeInd = 1:2
    for trlInd = 1:numTrl
      iHighSpeed= find(velInThreshold(eyeInd,trlInd, :)>1);
      
      if (isempty(iHighSpeed))
        Nothing= 1;

      else

          iS= 1;
          EyeSaccades(eyeInd,trlInd).Start= [];
          EyeSaccades(eyeInd,trlInd).End= [];
          EyeSaccades(eyeInd,trlInd).Merged= [];
          CurrentStart= iHighSpeed(1);
          Duration= 1;

          for iHigh= 2:length(iHighSpeed),
            if (iHighSpeed(iHigh)~=iHighSpeed(iHigh-1)+1) %% discontinuity
              if (DeltaT*(iHighSpeed(iHigh-1)-CurrentStart+1)>= cfg.MinimalDurationMS) 
              %% if sequence is long enough to be counted as saccade
                if (iS==1 || DeltaT*(CurrentStart-EyeSaccades(eyeInd,trlInd).End(iS-1)+1)>= cfg.MinimalSeparationMS) 
                %% first saccade or saccade after a sufficiently long time
                  EyeSaccades(eyeInd,trlInd).Start(iS)= CurrentStart; 
                  EyeSaccades(eyeInd,trlInd).End(iS)= iHighSpeed(iHigh-1); %*DeltaT;
                  EyeSaccades(eyeInd,trlInd).Merged(iS)= 0;
                  iS= iS+1;
                else
                  %% otherwise - appending a previous saccade, so it is longer
                  EyeSaccades(eyeInd,trlInd).End(iS-1)= iHighSpeed(iHigh-1); %*DeltaT;
                  EyeSaccades(eyeInd,trlInd).Merged(iS-1)= 1;
                end;
              end;

              %% starting the next sequence
              CurrentStart= iHighSpeed(iHigh);
            end;
          end;

          %% wraping up the last one (if it is really long)
          iHigh= length(iHighSpeed)+1;
          if (DeltaT*(iHighSpeed(iHigh-1)-CurrentStart+1)>= cfg.MinimalDurationMS) 
          %% if sequence is long enough to be counted as saccade
            if (iS==1 || DeltaT*(CurrentStart-EyeSaccades(eyeInd,trlInd).End(iS-1)+1)>= cfg.MinimalSeparationMS) 
            %% first saccade or saccade after a sufficiently long time
              EyeSaccades(eyeInd,trlInd).Start(iS)= CurrentStart;
              EyeSaccades(eyeInd,trlInd).End(iS)= iHighSpeed(iHigh-1);
              EyeSaccades(eyeInd,trlInd).Merged(iS)= 0;
              iS= iS+1;
            else
              %% otherwise - appending a previous saccade, so it is longer
              EyeSaccades(eyeInd,trlInd).End(iS-1)= iHighSpeed(iHigh-1);
              EyeSaccades(eyeInd,trlInd).Merged(iS-1)= 1;
            end;
          end;
          
      end
    end
end

%% making sure that "left" eye has fewer microsaccades
for trlInd = 1:size(EyeSaccades,2)
    if (length(EyeSaccades(2,trlInd).Start)<length(EyeSaccades(1,trlInd).Start))
        EyeTemp= EyeSaccades(2,trlInd);
        EyeSaccades(2,trlInd)= EyeSaccades(1,trlInd);
        EyeSaccades(1,trlInd)= EyeTemp;
    end
end

%% checking binocular correspondence
for trlInd = 1:size(EyeSaccades,2)
    EyeSaccades(3,trlInd)= EyeSaccades(1,trlInd);
    iBadLeftEyeSaccades= [];
    for iLS= 1:length(EyeSaccades(3,trlInd).Start),
        iOverlap= find(EyeSaccades(2,trlInd).Start<=EyeSaccades(3,trlInd).End(iLS) & EyeSaccades(2,trlInd).End>=EyeSaccades(3,trlInd).Start(iLS));
        if (~isempty(iOverlap))

            EyeSaccades(3,trlInd).Start(iLS)= min([EyeSaccades(3,trlInd).Start(iLS) EyeSaccades(2,trlInd).Start(iOverlap)]);
            EyeSaccades(3,trlInd).End(iLS)= max([EyeSaccades(3,trlInd).End(iLS) EyeSaccades(2,trlInd).End(iOverlap)]);
            EyeSaccades(3,trlInd).Merged(iLS)= max([EyeSaccades(3,trlInd).Merged(iLS) EyeSaccades(2,trlInd).Merged(iOverlap)]);
            
        else
            iBadLeftEyeSaccades= [iBadLeftEyeSaccades iLS];
            
        end
    end
    if (~isempty(iBadLeftEyeSaccades))
        EyeSaccades(3,trlInd).Start(iBadLeftEyeSaccades)= [];
        EyeSaccades(3,trlInd).End(iBadLeftEyeSaccades)= [];
        EyeSaccades(3,trlInd).Merged(iBadLeftEyeSaccades)= [];

        badSacc{trlInd} = iBadLeftEyeSaccades;
    end
end

Saccades = EyeSaccades(3,:);

%% re-checking whether (now binocular) saccades are sufficiently far apart
%  in time
for trlInd = 1:size(EyeSaccades,2)
    iS = 2;
    while (iS<length(Saccades(trlInd).Start))
        if (DeltaT*(Saccades(trlInd).Start(iS)-Saccades(trlInd).End(iS-1)+1)< cfg.MinimalSeparationMS)
          
            %% appending first saccade
            Saccades(trlInd).End(iS-1)= Saccades(trlInd).End(iS);
            Saccades(trlInd).Merged(iS-1)= 1;

            %% erasing the second one
            Saccades(trlInd).Start(iS)= [];
            Saccades(trlInd).End(iS)= [];
            Saccades(trlInd).Merged(iS)= [];

        else
            iS= iS+1;
        end
    end
end


%% creat shift data
shift = zeros(numTrl, timePoints);

for trlInd = 1:size(EyeSaccades,2)
    if (~isempty(Saccades(trlInd).Start))
        for saccInd = 1:length(Saccades(trlInd).Start)
            shift(trlInd,Saccades(trlInd).Start(saccInd)) = 1;

        end
    end
end
data_output = shift;
end