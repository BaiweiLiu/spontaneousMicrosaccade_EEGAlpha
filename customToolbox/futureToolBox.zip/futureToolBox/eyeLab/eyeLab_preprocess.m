function eyeLab_preprocess(cfg)

% function eyeLab_preprocess(cfg)
% Description: read data => interpBlink => epoch data
%
%       cfg.input_dirs          = the direction for the to-be-processed data (can combine different sessions);
%       cfg.output_dir          = uknow.
%       cfg.epoch_trig          = trigs for epoch
%       cfg.epoch_time          = time window for epoch;
%       cfg.localiser_trig      = trigs for localiser
%       cfg.localiser_epoch_time= time window for localiser
%       cfg.subjID              = subjID (string number);
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% default setting
sampleRate = 1000; % sample rate of tracker
singleEye = 'merge'; % track single or both eye
inter2change = 100; % mark the window before and after NaN window
blinkinterp_plotOut = false; % plot results or not 

v2struct(cfg)
subjID = ['pp' subjID];

% Write dir
wdir = creatDir([output_dir filesep 'epoched_data']);
wdir_localiser = creatDir([output_dir filesep 'localiser_data']);

outfilename_epoch = [ wdir filesep subjID '.mat' ];
outfilename_localiser = [ wdir_localiser filesep subjID '.mat' ];

% get eyetracker data also locked to desired events
for sessionInd = 1 :length(input_dirs)
    readName = input_dirs{sessionInd};
    fprintf(['##### Start: Loading subject ' subjID  ' session %i \n'], sessionInd);
    cfg = [];
    cfg.read_folder = readName;
    cfg.sampleRate = sampleRate;
    [eye_data_raw,hdr] = eyeLab_readAsc(cfg);

    % detect and process blink 
    fprintf(['##### Step1: InterpolkateBlink(subject ' subjID ' session %i)... \n'], sessionInd);

    cfg = [];
    cfg.hdr = hdr;
    cfg.edata = eye_data_raw;
    cfg.singleEye = singleEye; 
    cfg.inter2change = inter2change; 
    cfg.plotOut = blinkinterp_plotOut;
    if exist('maxBinkDuration')
        cfg.maxBinkDuration = maxBinkDuration;
        infoDisp(['doing self interp' num2str(maxBinkDuration)], 'line')
    end
    eye_data_nonBlink = eyeLab_blinkinterp(cfg);

    % start to epoch data
    fprintf(['##### Step2: Epoch data (subject ' subjID ' session %i)... \n' ], sessionInd);

    cfg = [];
    cfg.hdr = hdr;
    cfg.epoch_trig = epoch_trig;
    cfg.epoch_time = epoch_time;
    cfg.data = eye_data_nonBlink;
    cfg.singleEye = singleEye; 
    cfg.checkTrig = false;
    [eye_data_sess, event] = eyeLab_epoch(cfg);  

    if exist('localiser_trig')
        cfg.epoch_trig = localiser_trig;
        cfg.epoch_time = localiser_epoch_time;
        [liser_data_sess, ~] = eyeLab_epoch(cfg); 
    end
    
    if sessionInd == 1
        eye_data = eye_data_sess;
        if exist('localiser_trig')
            liser_data = liser_data_sess;
        end
    else
        cfg=[];
        eye_data = ft_appenddata(cfg,eye_data, eye_data_sess)
        if exist('localiser_trig')
            liser_data = ft_appenddata(cfg,liser_data, liser_data_sess)
        end
    end
end

% save data   
disp('##### End: Saving epoched data')
save(outfilename_epoch,'eye_data')
if exist('localiser_trig')
    save(outfilename_localiser,'liser_data')
end

end