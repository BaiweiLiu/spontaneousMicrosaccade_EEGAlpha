function eyeLab_GAbin(cfg)

% function eyeLab_GAbin(cfg)
% Description: read the bin events and bin the data, then creat a data
% for all subject
%
%       cfg.eye_file           = string specifiying the directory where the epoched eye files are;
%       cfg.event_file         = string specifying the directory where the bin_event files are.
%       cfg.output_dir         = uknow.
%       cfg.channel             = to-be-analysised channels
%       cfg.removeBadTrial      = whether remove the bad channel detected
%       before
%       cfg.leftRightTrig  = left_en and right_en triggers 
%       cfg.fileName        = uknow.
%       cfg.minTrials       = the minim num of trials in one bin, if no,
%       cfg.goodness_file   = uknow.
%       then Nan
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% default values
channel = {'eyeX' 'eyeY'};
valueType = 'toward';
removeBadTrial = false;

% extract cfg value
v2struct(cfg);

% create output file
outfile = creatDir(output_dir);

%% Read the files
for goodInd  = 1: length(goodness_file)
    sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
end

%% get list of input files
sublist_eye = get_subFiles(eye_file);
sublist_event = get_subFiles(event_file);

left_trig = leftRightTrig{1};
right_trig = leftRightTrig{2};

% run subLoop
for subInd = 1:length(sublist_eye)
    infoDisp(['load event data for subj ' sublist_event{subInd}(end-7:end-4)]);
    load(sublist_event{subInd});
    
    events_sel = event.sel;
    
    numBin = size(events_sel,1); % get number of bins 
    
    %% read data
    infoDisp(['load eye data for subj ' sublist_eye{subInd}(end-7:end-4)]);
    cfg = [];
    cfg.input_dir = sublist_eye{subInd};
    cfg.goodness_file = inCellSelec(sublist_goodTl,subInd);
    cfg.channel = channel;
    [tl,trialOK] = eyeLab_readEye(cfg);

    chX = ismember(tl.label, 'eyeX');
    chY = ismember(tl.label, 'eyeY');
    
    sel1 = ismember(tl.trialinfo(:,1),left_trig);
    tl.trial(sel1,chX,:)= -tl.trial(sel1,chX,:);
    
    for binInd = 1:numBin
        bin_sel = events_sel(binInd,:);
        bin_sel = bin_sel(trialOK);
        if sum(bin_sel) >= minTrials
            GA_eye.gaze(subInd,binInd,:) = squeeze(nanmean(tl.trial(bin_sel, chX,:)));    
        else
            GA_eye.gaze(subInd,binInd,:) = NaN(1,length(tl.trial(1, 1,:))); 
            infoDisp('Number of trials is too low!','line')
        end
    end
    GA_eye.subjName{subInd} = sublist_eye{subInd}(end-7:end-4);
end

% save the data 
GA_eye.time = tl.time;
GA_eye.bin = numBin;
GA_eye.timeBin = event.timeBin;
GA_eye.dimName = {'subjID', 'binInd', 'time'};
save([outfile filesep 'GA_' fileName '.mat'], 'GA_eye'); 
end