function [data_out] = eyelab_blinkinterp(cfg)

% function eyelab_blinkinterp(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.hdr             = the header get from fieldtrip;
%       cfg.edata           = bin it in every x ms.
%       cfg.singleEye       = uknow.
%       cfg.inter2change    = uknow.
%       cfg.plotOut         = whether plot the results;
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

%% default setting
maxBinkDuration = 500; % the time NaN cluster more than it will be not treated as blink

%% get the value
v2struct(cfg); % cfg = edata, hdr, singleEye, inter2change

%% merge the two eye value, and get the NaN 
if singleEye =='single'  % where any of them are 0? %% only use Y channels
    blinks = abs(squeeze(edata.trial{1}([3],:)))==0;
else
    blinks = abs(squeeze(edata.trial{1}([3],:)))==0 | abs(squeeze(edata.trial{1}([6],:))) == 0; 
end  

%% find NaN clusters
onsets = find(diff(blinks) == 1);
offsets = find(diff(blinks) == -1);

while onsets(1) > offsets(1)
    offsets(1) = [];
end

nonsets = length(onsets);

if length(offsets) > length(onsets)
    offsets = offsets(1:nonsets);
end

noffsets = length(offsets);

if length(onsets) > length(offsets)
    onsets = onsets(1:noffsets);
end

%% store the raw data
if plotOut
    before_correct = NaN(length(onsets),700);
    rawData = abs(squeeze(edata.trial{1}([3],:)));
    numNoBlink =0;
    for blinkInd = 1: length(onsets)
        if (offsets(blinkInd) - onsets(blinkInd)) <= maxBinkDuration
            before_correct(blinkInd,1:(offsets(blinkInd)-onsets(blinkInd)+1+200)) = rawData(onsets(blinkInd)-100:offsets(blinkInd)+100);
        end
    end
end

%% interpot the blink
nsamp2corr = round(inter2change ./ (1000/hdr.Fs)); % caculate the longer time window

reverseStr = [];

%% does not change the too early and too late cluster 
torem = onsets<=nsamp2corr*3 | onsets>= hdr.nSamples-nsamp2corr*3 | offsets<=nsamp2corr*3 | offsets>= hdr.nSamples-nsamp2corr*3;
onsets(torem) = [];offsets(torem) = [];

%% loop for every NaN cluster
for x = 1:length(onsets) % onsets or offsets; whichever has less (if different n)
    
    % display progress
    msg = sprintf(['getting interpolation for blink ' num2str(x) ' out of ', num2str(length(onsets))]);
    fprintf([reverseStr, msg]); if x == length(onsets); fprintf('\n'); end;
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    
    %disp(['getting interpolation for blink ' num2str(x) ' out of ', num2str(length(onsets))])
    for ch = 2:hdr.nChans
        length_blink = length(onsets(x)-nsamp2corr:offsets(x)+nsamp2corr);
        
        if (offsets(x) - onsets(x)) > maxBinkDuration; % if no blink, then nan 
            edata.trial{1}(ch,onsets(x)-nsamp2corr:offsets(x)+nsamp2corr) = nan(1,length_blink);
        else
            interval2corr = onsets(x)-nsamp2corr:offsets(x)+nsamp2corr;
            
            pre_time = onsets(x)-(nsamp2corr*2); % Make the interpolate more smooth
            start_time = onsets(x)-(nsamp2corr*1);
            end_time = offsets(x)+(nsamp2corr*1);
            post_time = offsets(x)+(nsamp2corr*2);
            
            interval2refered = [pre_time start_time end_time post_time];
            
            time_refered = edata.time{1}(interval2refered);
            
            Samp_start = [onsets(x)-(nsamp2corr*2.5):onsets(x)-(nsamp2corr*1.5)];
            Samp_end = [offsets(x)+(nsamp2corr*1.5):offsets(x)+(nsamp2corr*2.5)];
            
            value_refered(1) = nanmean(edata.trial{1}(ch,Samp_start(edata.trial{1}(ch,Samp_start)~=0)));
            value_refered(2) = edata.trial{1}(ch,start_time); if value_refered(2) == 0; value_refered(2) = nan; end;  % %nanmean(edata.trial{1}(ch,sel2(edata.trial{1}(ch,sel2)~=0)));
            value_refered(3) = edata.trial{1}(ch,end_time); if value_refered(3) == 0; value_refered(3) = nan; end;  %nanmean(edata.trial{1}(ch,sel3(edata.trial{1}(ch,sel3)~=0)));
            value_refered(4) = nanmean(edata.trial{1}(ch,Samp_end(edata.trial{1}(ch,Samp_end)~=0)));
           
            % yok2 and 3 ensure that interpolated data starts from actual
            % value, rather than avg value; this avoids sample-to-sample
            % jumps in signal!
            
            if sum(isnan(value_refered) > 0)
                edata.trial{1}(ch,onsets(x)-nsamp2corr:offsets(x)+nsamp2corr) = nan(1,length_blink);
            else           
                xinterp = edata.time{1}(interval2corr); yinterp = edata.trial{1}(ch,interval2corr);
                yinterp = interp1(time_refered,value_refered,xinterp, 'spline');     edata.trial{1}(ch,interval2corr) = yinterp;
                
                end
                
            end
        end
end
%% plot
if plotOut
    
    correctData = abs(squeeze(edata.trial{1}([3],:)));
    after_correct = NaN(length(onsets),700);
    for blinkInd = 1: length(onsets)
        if (offsets(blinkInd) - onsets(blinkInd)) <= maxBinkDuration
            after_correct(blinkInd,1:offsets(blinkInd)-onsets(blinkInd)+1+200) = correctData(onsets(blinkInd)-100:offsets(blinkInd)+100);
        end
    end

    figure('Position',[100 100 800 600]);
    x=linspace(-100,600,700);
    g(1,1)=gramm('x',x,'y',before_correct);
    g(1,1).geom_line();
    g(1,1).set_title('Before Corrention');

    g(1,2)=gramm('x',x,'y',after_correct);
    g(1,2).geom_line();
    g(1,2).set_title('After Corrention');

    g(2,1)=gramm('x',x,'y',before_correct);
    g(2,1).stat_summary();
    g(2,1).set_title('Before Corrention');

    g(2,2)=gramm('x',x,'y',after_correct);
    g(2,2).stat_summary();
    g(2,2).set_title('After Corrention');
    g.axe_property('YLim',[0 1000]);
    g.draw();
end
%%
data_out = edata;
end
