function [eye_data,hdr] = eyeLab_readAsc(cfg)

% This fuction is used to read eyelink data
% It is only read data with fieldtrip format

% This cfg should contain the following study-specific info:
% - cfg.read_folder
% - cfg.sampleRate

% Baiwei (lbwair@icloud.com)
    %% cut out events of interest manually, and get their samples
    v2struct(cfg);
    hdr = ft_read_header(read_folder);
    hdr.Fs= sampleRate; % set the fs by ourself, because our data are not continues
    % read in full dataset at once
    cfg = [];
    cfg.dataset = read_folder;
    cfg.hdr = hdr;
    eye_data = ft_preprocessing(cfg);
    eye_data.hdr.Fs = sampleRate;
    eye_data.fsample = sampleRate;
end