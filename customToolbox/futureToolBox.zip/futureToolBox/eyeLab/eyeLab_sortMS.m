function eyeLab_sortMS(cfg)
v2struct(cfg); % cfg = input_file, output_dir, time, time_i

load(input_file);
numTrials = size(gazeShift.gazeL_to,1);
outfile = output_dir;
outfile_raw = creatDir([outfile filesep 'event_raw']);
outfile_to = creatDir([outfile filesep 'event_to']);
outfile_aw = creatDir([outfile filesep 'event_aw']);
outfile_noMS = creatDir([outfile filesep 'event_noMS']);
outfile_unTrust = creatDir([outfile filesep 'event_unTrust']);

outfile_to_early = creatDir([outfile filesep 'event_to_early']);
outfile_to_late = creatDir([outfile filesep 'event_to_late']);

outfile_aw_early = creatDir([outfile filesep 'event_aw_early']);
outfile_aw_late = creatDir([outfile filesep 'event_aw_late']);

% outfile_to_q1 = creatDir([outfile filesep 'event_to_q1']);
% outfile_to_q2 = creatDir([outfile filesep 'event_to_q2']);
% outfile_to_q3 = creatDir([outfile filesep 'event_to_q3']);
% outfile_to_q4 = creatDir([outfile filesep 'event_to_q4']);
% 
% outfile_to_thr1 = creatDir([outfile filesep 'event_to_thr1']);
% outfile_to_thr2 = creatDir([outfile filesep 'event_to_thr2']);
% outfile_to_thr3 = creatDir([outfile filesep 'event_to_thr3']);

gaze_window = time_i;
t2sort = dsearchn(time', gaze_window');
meanTime = diff(t2sort)/2;
trial_to = zeros(1,numTrials);
trial_to_early = zeros(1,numTrials);
trial_to_late = zeros(1,numTrials);
trial_aw_early = zeros(1,numTrials);
trial_aw_late = zeros(1,numTrials);
trial_unTrust = zeros(1,numTrials);

trial_to_Q1 = zeros(1,numTrials);
trial_to_Q2 = zeros(1,numTrials);
trial_to_Q3 = zeros(1,numTrials);
trial_to_Q4 = zeros(1,numTrials);

trial_to_T1 = zeros(1,numTrials);
trial_to_T2 = zeros(1,numTrials);
trial_to_T3 = zeros(1,numTrials);

timePoints_to_early = nan(1,numTrials);
timePoints_to_late = nan(1,numTrials);
timePoints_aw_early = nan(1,numTrials);
timePoints_aw_late = nan(1,numTrials);

trial_aw = zeros(1,numTrials);
trial_noMs = ones(1,numTrials);

%extract media
ind_to =[];
for trialID = 1 : numTrials 
    [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2sort(1):t2sort(2)]));
    
    if (indL_to+indR_to) > 0
    ind_to(end+1) = indL_to+indR_to;
    end   
end

medianTime = nanmedian(ind_to); 

if exist('midCut')
    infoDisp('doing self cut', 'line')
    cut_point1 = dsearchn(time', midCut');
    cut_point = cut_point1 - t2sort(1);
else
    cut_point = medianTime;
end
%% caculated quantile
Q1=prctile(ind_to,25);
Q2=prctile(ind_to,50);
Q3=prctile(ind_to,75);

T1 = prctile(ind_to,33.3);
T2 = prctile(ind_to,66.6);
%extract info
for trialID = 1 : numTrials 
    events = [];
    [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2sort(1):t2sort(2)]));
    [~, ind_unTrust]=ismember(1,gazeShift.gazeUnTrust(trialID,[t2sort(1):t2sort(2)]));
    events = [indL_to indR_to indL_aw indR_aw ind_unTrust];
    msEventsInd = find(events);
    [firstEvent, typeInd] =min(events(msEventsInd));
    eventType = msEventsInd(typeInd);
    
    if ~isempty(eventType)
        if eventType <= 2
            trial_to(trialID) =1;
            if firstEvent <= cut_point;
                trial_to_early(trialID) =1;
                timePoints_to_early(trialID) = firstEvent + t2sort(1);
            else
                trial_to_late(trialID) =1;
                timePoints_to_late(trialID) = firstEvent + t2sort(1);
            end
            
%             if firstEvent <= Q1;
%                 trial_to_Q1(trialID) =1;
%             elseif firstEvent <= Q2
%                 trial_to_Q2(trialID) =1;
%             elseif firstEvent <= Q3
%                 trial_to_Q3(trialID) =1;
%             else
%                 trial_to_Q4(trialID) =1;
%             end
%             
%             if firstEvent <= T1
%                 trial_to_T1(trialID) =1;
%             elseif firstEvent <= T2
%                 trial_to_T2(trialID) =1;
%             else
%                 trial_to_T3(trialID) =1;
%             end

        elseif eventType <= 4
            trial_aw(trialID) =1;
            if firstEvent <= cut_point;
                trial_aw_early(trialID) =1;
                timePoints_aw_early(trialID) = firstEvent + t2sort(1);
            else
                trial_aw_late(trialID) =1;
                timePoints_aw_late(trialID) = firstEvent + t2sort(1);
            end
        elseif eventType == 5
            trial_unTrust(trialID) =1;
        end
        
        trial_noMs(trialID) = 0;
    end
end

control_noMs = ones(1,numTrials);

if exist('time_control')
    gaze_window = time_control;
    t2control = dsearchn(time', gaze_window');
    for trialID = 1 : numTrials 
        [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2control(1):t2control(2)]));
        [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2control(1):t2control(2)]));
        [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2control(1):t2control(2)]));
        [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2control(1):t2control(2)]));
        events = [indL_to indR_to indL_aw indR_aw];
        
        msEventsInd = find(events);
        [firstEvent, typeInd] =min(events(msEventsInd));
        eventType = msEventsInd(typeInd);
        
        if ~isempty(eventType)
            control_noMs(trialID) = 0;
        end
    end
end

event.sel = logical(ones(1,numTrials)) & logical(control_noMs);
save([outfile_raw  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_to) & logical(control_noMs);
save([outfile_to  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_aw)&logical(control_noMs);
save([outfile_aw  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_noMs)&logical(control_noMs);
save([outfile_noMS  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_unTrust)&logical(control_noMs);
save([outfile_unTrust  filesep input_file(end - 7:end)], 'event');

event.sel = logical(trial_to_early)&logical(control_noMs);
event.timeValue = timePoints_to_early(logical(control_noMs));
save([outfile_to_early  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_to_late)&logical(control_noMs);
event.timeValue = timePoints_to_late(logical(control_noMs));
save([outfile_to_late  filesep input_file(end - 7:end)], 'event');

event.sel = logical(trial_aw_early)&logical(control_noMs);
event.timeValue = timePoints_aw_early(logical(control_noMs));
save([outfile_aw_early  filesep input_file(end - 7:end)], 'event');
event.sel = logical(trial_aw_late)&logical(control_noMs);
event.timeValue = timePoints_aw_late(logical(control_noMs));
save([outfile_aw_late  filesep input_file(end - 7:end)], 'event');

% events_sel = logical(trial_to_Q1)&logical(control_noMs);
% save([outfile_to_q1  filesep input_file(end - 7:end)], 'events_sel');
% events_sel = logical(trial_to_Q2)&logical(control_noMs);
% save([outfile_to_q2  filesep input_file(end - 7:end)], 'events_sel');
% events_sel = logical(trial_to_Q3)&logical(control_noMs);
% save([outfile_to_q3  filesep input_file(end - 7:end)], 'events_sel');
% events_sel = logical(trial_to_Q4)&logical(control_noMs);
% save([outfile_to_q4  filesep input_file(end - 7:end)], 'events_sel');
% 
% events_sel = logical(trial_to_T1)&logical(control_noMs);
% save([outfile_to_thr1  filesep input_file(end - 7:end)], 'events_sel');
% events_sel = logical(trial_to_T2)&logical(control_noMs);
% save([outfile_to_thr2  filesep input_file(end - 7:end)], 'events_sel');
% events_sel = logical(trial_to_T3)&logical(control_noMs);
% save([outfile_to_thr3  filesep input_file(end - 7:end)], 'events_sel');

end
