function [g_out] = eyeLab_plotShift(cfg)

% colors = select_colors(3,[0 360], 50, 75);
% colors_line = select_colors(3,[0 360], 70, 60);
colors = [173,216,161; 237 152 121; 96 182 196]; %% 107 degree 77 lum, 16 degree 69 lum, 188 65 lum
colors_line = [85 161 92; 204 63 50; 48 111 183]; %% 126 degree 54 lum, 5 deg 48 Lum, 212deg, 46 lum
colors = colors/256;
colors_line = colors_line/256;

v2struct(cfg); % cfg = plotType, GA_address, time, plot_title
load(GA_address);

if strcmp(plotType,'sum')
    
    if isfield(GA_shift, 'hzL')
        colorMaker = [repmat({'left-shift'},1,length(GA_shift.hzL)) repmat({'right-shift'},1,length(GA_shift.hzR))];
        y = [GA_shift.hzL GA_shift.hzR];
    else
        colorMaker = [repmat({'toward'},1,length(GA_shift.hz_to)) repmat({'away'},1,length(GA_shift.hz_aw))];
        y = [GA_shift.hz_to GA_shift.hz_aw];
        
        subjMaker = [GA_shift.subjMaker GA_shift.subjMaker];
        condMaker = [GA_shift.condMaker GA_shift.condMaker];
    end
    
    
    if ~exist('subplotInd')
        
        g = gramm('x', time, 'y', y, 'color', colorMaker)% 'subset', strcmp(lineMaker,'left_item'))%,'lightness',lineMaker);
        g.stat_summary();
        g.facet_grid(condMaker,[]);
        g.set_title(plot_title);
        if length(condName)>1
            g.set_order_options('row',condName, 'color', {'toward' 'away'});
        else
            g.set_order_options('color', {'toward' 'away'});
        end
    else
        g(subplotInd(1),subplotInd(2)) = gramm('x', time, 'y', y, 'color', colorMaker)% 'subset', strcmp(lineMaker,'left_item'))%,'lightness',lineMaker);
        g(subplotInd(1),subplotInd(2)).stat_summary();
        g(subplotInd(1),subplotInd(2)).set_title(plot_title);
    end
    
    %g.set_line_options('style',{'-'});
    %g.set_color_options('lightness_range',[30 60]);
    g.set_text_options('base_size',15,'label_scaling',1.4);
    g.set_names('x','Time (0 = onset of probe)','y','Hz','color','Direction');
    g.axe_property('Xlim', xli, 'YLim',[0 2.0],'YTick',[0: 0.5: 2.0]);
    
    if ~exist('subplotInd')
        g.set_title(plot_title);
        g.draw()
        if exist('markerLine')
            for figInd = 1:length(condName)
                for linInd = 1: length(markerLine)
                    line([markerLine(linInd) markerLine(linInd)],[0 2.0],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(figInd,1))
                end
            end
        end
        imagewd = getframe(gcf);
        imwrite(imagewd.cdata, [figure_dir filesep 'time' plot_title '.tiff']);
    else
        g_out = g;
    end
    
%     %% plot rate and power 
%     
%     figure(figInd{1});
%     subplot(subFigInd(1),subFigInd(2),subFigInd(3));
%     y = [];
%     y = [GA_shift.Rate_toi_to' GA_shift.Rate_toi_aw'];
%     x = [1 4];
%     HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.15,'spread',0.8 ...
%         ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
%         ,'lineWidth',5,'dotSize',20);
%     hold off
%     ylabel('Percetage of MS trial ') 
%     % set(gca,'ylim',[0 1000],'TickLength', [0.03,0.2]);
%     % set(gca,'xlim',[0 40]);
%     set(gca, 'FontSize', 20,'Fontname','Arial');
%     box off  
%     set(gca,'XColor','w') 
%     set(gca,'xtick',[]);
%     set(0,'defaultfigurecolor','w') 
%     
%     yl =  ylim;
%     [~,p_value,~,t_value] = ttest(y(:,1), y(:,2));
%     p_value = roundn(p_value,-3);
%     t_val = abs(t_value.tstat);
%     t_val = roundn(t_val,-3);
%     txt = ['p = ' num2str(p_value)];
%     text(3-1.5,yl(1)-(yl(2)-yl(1))/20,txt,'FontSize',18)
%     txt = ['t = ' num2str(t_val)];
%     text(3-1.5,yl(1)-(yl(2)-yl(1))/20*3,txt,'FontSize',18)
%     
%     figure(figInd{2});
%     subplot(subFigInd(1),subFigInd(2),subFigInd(3));
%     y = [];
%     y = [GA_shift.power_to_toi' GA_shift.power_aw_toi'];
%     y(isnan(y))=0;
%     x = [1 4];
%     HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.15,'spread',0.8 ...
%         ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
%         ,'lineWidth',5,'dotSize',20);
%     hold off
%     ylabel('Magnitude of shifts') 
%     % set(gca,'ylim',[0 1000],'TickLength', [0.03,0.2]);
%     % set(gca,'xlim',[0 40]);
%     set(gca, 'FontSize', 20,'Fontname','Arial');
%     box off  
%     set(gca,'XColor','w') 
%     set(gca,'xtick',[]);
%     set(0,'defaultfigurecolor','w') 
%     
%     yl =  ylim;
%     [~,p_value,~,t_value] = ttest(y(:,1), y(:,2));
%     p_value = roundn(p_value,-3);
%     t_val = abs(t_value.tstat);
%     t_val = roundn(t_val,-3);
%     txt = ['p = ' num2str(p_value)];
%     text(3-1.5,yl(1)-(yl(2)-yl(1))/20,txt,'FontSize',18)
%     txt = ['t = ' num2str(t_val)];
%     text(3-1.5,yl(1)-(yl(2)-yl(1))/20*3,txt,'FontSize',18)
%     
%     imagewd = getframe(gcf);
%     imwrite(imagewd.cdata, [figure_dir filesep 'toi' plot_title '.tiff']);

elseif strcmp(plotType,'indiv') % indiv is only for one cond 
    
    if isfield(GA_shift, 'hzL')
        colorMaker = [repmat({'left-shift'},1,length(GA_shift.hzL)) repmat({'right-shift'},1,length(GA_shift.hzR))];
        y = [GA_shift.hzL GA_shift.hzR];
    else
        colorMaker = [repmat({'toward'},1,length(GA_shift.hz_to)) repmat({'away'},1,length(GA_shift.hz_aw))];
        y = [GA_shift.hz_to GA_shift.hz_aw];
        
        subjMaker = [GA_shift.subjMaker GA_shift.subjMaker];
        condMaker = [GA_shift.condMaker GA_shift.condMaker];
    end
    
    for subInd = 1:length(GA_shift.hz_to)
        subplot(5,5, subInd)
        plot(time, GA_shift.hz_to{subInd}, 'r'); hold on
        plot(time, GA_shift.hz_aw{subInd}, 'b')
        title(GA_shift.subjMaker{subInd})
        set(gca, 'FontSize', 20,'Fontname','Arial');
        ylabel('shift rate (Hz)') 
        xlabel('time') 
        xlim(xli)
        
        if exist('markerLine')
            for linInd = 1: length(markerLine)
                line([markerLine(linInd) markerLine(linInd)],[0 2.0],'Color','k','LineStyle','--')
            end
        end
    end
        
end
    

end