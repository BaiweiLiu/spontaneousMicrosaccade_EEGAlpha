function eyeLab_getShift(cfg)
% read_dir: the normalized or real eye data 
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
plotFig = true;

v2struct(cfg)

% load eye data
load(read_dir)

% 
eyeX = squeeze(eye_data.trial(:,strcmp(eye_data.label, 'eyeX'),:));
eyeY = squeeze(eye_data.trial(:,strcmp(eye_data.label, 'eyeY'),:));

cfg = [];
[shiftX,shiftX_vel,shift_time] = PBlab_gazepos2shift_1D(cfg,eyeX,eye_data.time);
[shiftY,shiftY_vel,shift_time] = PBlab_gazepos2shift_1D(cfg,eyeY,eye_data.time);

[shiftXY,shiftXY_vel,shift_time] = PBlab_gazepos2shift_2D(cfg,eyeX,eyeY,eye_data.time);

eye_data.shift_time = shift_time;
eye_data.shiftX = shiftX;
eye_data.shiftX_vel = shiftX_vel;
eye_data.shiftY =shiftY;
eye_data.shiftY_vel = shiftY_vel;
eye_data.shiftXY =shiftXY;
eye_data.shiftXY_vel = shiftXY_vel;

if plotFig
    data2plot = shiftXY;
    sel = (abs(real(data2plot)) >0 & abs(imag(data2plot))>0);
    data2plot = data2plot(sel);
    rose(angle(data2plot));
end
save(read_dir,'eye_data');

end