function [epoched_data, event] = eyeLab_epoch(cfg)

% This fuction is used to epoch eyelink data
% It is only read data with fieldtrip format
% Baiwei (lbwair@icloud.com)
% This cfg should contain the following study-specific info:
% - cfg.hdr
% - cfg.epoch_time
% - cfg.epoch_trigger
% - cfg.data 
% - cfg.singleEye
% - cfg.checkTrig
    
%% cut out events of interest manually, and get their samples
    v2struct(cfg);
    prestim = epoch_time(1); poststim = epoch_time(2);
    % find events by looking for "trig"
    event = [];
    idx = 0; 
    for t = 1:length((hdr.orig.msg))
        x = findstr(hdr.orig.msg{t}, 'trig');
        if x
            idx = idx+1;
            event.label(idx) =  {[hdr.orig.msg{t}(x:end)]};
            event.timestamp(idx) = str2num([hdr.orig.msg{t}(4:x-1)]);

            % find closest possible sample to make sure to always have one...
            [a,b] = min(abs(hdr.orig.dat(1,:) - event.timestamp(idx)));
            event.sample(idx) = b;       
        end
    end

    % convert values of interests to strings of interest
    for v = 1: length(epoch_trig)
        eye_trig(v) = {['trig', num2str(epoch_trig(v))]};
    end

    % find where in data these strings occur and get trl
    trloi = match_str(event.label, eye_trig);
    soi = event.sample(trloi)';
    trl_eye = [soi+prestim*hdr.Fs, soi+(poststim-0.001)*hdr.Fs, ones(length(soi),1)*prestim*hdr.Fs];
    
    event_count = tabulate(event.label(trloi));
    event_count = event_count(:,[1 2]);
    if checkTrig
        disp(event_count)
        disp('Make sure the triggers and their number of ocurrence in the experiment make sense! If so, type in dbcont and press enter...')
        
    end

    % now cut out the trials
    cfg = [];
    cfg.trl = trl_eye;
    epoched_data = ft_redefinetrial(cfg, data);

    % add the condition codes (trigger values) to the trialinfo
    trigval = [];
    for trl = 1:length(trloi)
        trigval(trl) = str2num(event.label{trloi(trl)}(5:end));
    end
    epoched_data.trialinfo(:,1) = trigval';
    
    % get to three channels - averaging the two eyes for Xgaze, Ygaze, and pupil
    if strcmp(singleEye, 'single')
        epoched_data.label(end+1:end+3) = {'eyeX','eyeY','eyePupil'};
        for t = 1:length(epoched_data.trial)
            epoched_data.trial{t}(epoched_data.trial{t} == 0) = NaN;
            tmp(:,:) = epoched_data.trial{t}([2,3,4],:);
            epoched_data.trial{t}(end+1:end+3,:) = tmp;
        end 
    elseif strcmp(singleEye, 'keepTwo')
        epoched_data.label(end+1:end+6) = {'eye1X','eye1Y','eye1Pupil','eye2X','eye2Y','eye2Pupil'};
        for t = 1:length(epoched_data.trial)
            epoched_data.trial{t}(epoched_data.trial{t} == 0) = NaN;
            tmp(:,:) = epoched_data.trial{t}([2,3,4,5,6,7],:);
            epoched_data.trial{t}(end+1:end+6,:) = tmp;
        end
    elseif  strcmp(singleEye, 'merge')
        epoched_data.label(end+1:end+3) = {'eyeX','eyeY','eyePupil'};
        for t = 1:length(epoched_data.trial)
            epoched_data.trial{t}(epoched_data.trial{t} == 0) = NaN;
            tmp(1,:,:) = epoched_data.trial{t}([2,3,4],:);
            tmp(2,:,:) = epoched_data.trial{t}([5,6,7],:);
            epoched_data.trial{t}(end+1:end+3,:) = nanmean(tmp);
        end
    end
    
    % only keep these three
    if strcmp(singleEye, 'single') | strcmp(singleEye, 'merge')
        cfg = [];
        cfg.channel = {'eyeX','eyeY','eyePupil'};
        epoched_data = ft_preprocessing(cfg, epoched_data);
    elseif strcmp(singleEye, 'keepTwo')
        cfg = [];
        cfg.channel = {'eye1X','eye1Y','eye1Pupil','eye2X','eye2Y','eye2Pupil'};
        epoched_data = ft_preprocessing(cfg, epoched_data);
    end
end