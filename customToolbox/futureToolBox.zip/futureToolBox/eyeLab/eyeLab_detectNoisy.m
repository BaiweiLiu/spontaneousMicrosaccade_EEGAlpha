function eyeLab_detectNoisy(cfg)

% function eyeLab_detectNoisy(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.eye_data            = input eye data (raw or normalized);
%       cfg.noisyLine           = the therohold to detect noisy. (one value one channel)
%       cfg.channel             = use the data from which channel to detect noisy (could be more than one);
%       cfg.plotTitle           = uknow
%       cfg.output_dir          = uknow
%       cfg.time_i              = time window that used to detect MS (or noise)
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% extract value
v2struct(cfg); 
goodness = [];
trialOk = 0;

% get interesting time
t2sort = dsearchn(eye_data.time', time_i')';
t_sel =  t2sort(1):t2sort(2);

% make out files
outfile_figure = creatDir([output_dir filesep 'clean_results']); 
outfile_data = creatDir([output_dir filesep 'trial_ok_index']);

% loop for different channels 
for i = 1: length(channel)
    
    channelInd = ismember(eye_data.label, channel{i}); % find channel
    max_pos = noisyLine(i); % get max value for this channel
    trlgoodness = [];
    

    for trl = 1:length(eye_data.trialinfo) % loop for trials 
    if sum(eye_data.trial(trl,channelInd,t_sel) > max_pos | eye_data.trial(trl,channelInd,t_sel) < -max_pos) > 1; trlgoodness(trl) = 0; else trlgoodness(trl) = 1; end;
    end
    
    trialOk = trialOk + trlgoodness; % get the value for all channels
    
    if i == 1;  goodness = trlgoodness; else goodness = [goodness trlgoodness];end
    
    channelStr = repmat({channel{i}}, 1,length(eye_data.trialinfo)); % create trial marker for plot 
    
    if i == 1;  channel_cond = channelStr; else channel_cond = [channel_cond channelStr];end
    if i == 1;  y = D2array2Cell(squeeze(eye_data.trial(:,channelInd,:))) ; else y = [y D2array2Cell(squeeze(eye_data.trial(:,channelInd,:)))];end
end

goodness_maker = cond_num2str(goodness,[0,1], {'Bad' 'Good'});
x = eye_data.time; 

figure('Position',[100 100 length(channel)*600 500]);
g(1,1) = gramm('x',x, 'y',y,'color',goodness_maker);
g(1,1).geom_line();
g(1,1).facet_grid([],channel_cond);
g(1,1).set_title(plotTitle);
g(1,1).set_order_options('color',1);
g(1,1).set_text_options('base_size',15,'label_scaling',1.4);
g(1,1).set_names('x','Time','y','Change degree','column','Channel');

g.draw()
imagewd = getframe(gcf);
imwrite(imagewd.cdata, [outfile_figure filesep plotTitle '.tiff']);

event.sel = ismember(trialOk, length(channel));

save([outfile_data filesep plotTitle '.mat'],'event');
    
end