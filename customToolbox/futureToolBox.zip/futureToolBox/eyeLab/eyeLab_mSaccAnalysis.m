function eyeLab_mSaccAnalysis(cfg)
% read_dir: the data from eyeLab_mSaccDetect
% norm_dir: the normlized data 
% time4fix: time window for detecting fixation position
% output_dir
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021

v2struct(cfg)

% get file name
sublist = get_subFiles(read_dir);
sublist_gaze = get_subFiles(norm_dir);

% creat out file 
outfile = creatDir(output_dir);

% loop subjects 
for subjInd = 1:length(sublist)
    infoDisp(['processing subject ' num2str(subjInd) '/' num2str(length(sublist))],'loop', subjInd, length(sublist))
    
    % load data
    load(sublist{subjInd})
    load(sublist_gaze{subjInd})
    
    % creat data vector
    dwellTimePure = [];
    dwell_time = NaN(size(gazeShift.thre_gazeVol));
    gaze_start = zeros(size(gazeShift.thre_gazeVol));
    gaze_return = zeros(size(gazeShift.thre_gazeVol));
    
    %caculated gaze center (start position)
    t4sacc = dsearchn(eye_data.time',time4fix')';
    gazePos = squeeze(eye_data.trial(:,1,[t4sacc(1):t4sacc(2)]));
    
    % loop for trial
    for trlID = 1:size(gazeShift.thre_gazeVol,1)
        if sum(gazeShift.thre_gazeVol(trlID,:)) > 0
            sacc_ind = find(gazeShift.thre_gazeVol(trlID,:) >0);
            for sacc_ind_trl = 1:length(sacc_ind)
                center_Pos = nanmedian(gazePos(trlID,:));
                startDis = abs(gazeShift.gaze_startPos(trlID,sacc_ind(sacc_ind_trl)) - center_Pos);
                endDis = abs(gazeShift.gaze_endPos(trlID,sacc_ind(sacc_ind_trl)) - center_Pos);
                gaze_start(trlID, sacc_ind(sacc_ind_trl))  = startDis < endDis;
                gaze_return(trlID, sacc_ind(sacc_ind_trl)) = startDis > endDis;
                
            end
            
            startSacc_ind = find(gaze_start(trlID, :) > 0);
            if length(startSacc_ind) >0
                for sacc_ind_trl = 1: length(startSacc_ind)
                    late_return = 0;
                    late_return = find(gaze_return(trlID,startSacc_ind(sacc_ind_trl):end));
                    if late_return > 0
                        dwell_time(trlID,startSacc_ind(sacc_ind_trl)) =late_return(1); 
                        dwellTimePure(end+1) = late_return(1); 
                    end
                end
            end
        end
    end
    gazeShift.dwell_time = dwell_time;
    gazeShift.gaze_start = gaze_start;
    gazeShift.gaze_return = gaze_return;
    gazeShift.dwellTimePure = dwellTimePure;
    save([outfile filesep  gazeShift.subjID '.mat'], 'gazeShift')
end
end