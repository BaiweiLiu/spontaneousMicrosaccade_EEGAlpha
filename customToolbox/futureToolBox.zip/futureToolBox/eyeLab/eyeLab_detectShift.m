function [data_output]=eyeLab_detectShift(cfg, eye_data)

% input 
% eye_data: matrix trial x time

% output 
% eye_shift: matrix trial x time

% set default value
smooth_step = 7; % length of smooth window
smooth_raw = false; % smooth raw data ?
smooth_der = true; % smooth velocity data ?
winbef = [50 0]; % time window for detecting the postion before saccade ?
winaft = [50 100]; % time window for detecting the postion after saccade ?
minISI = 100; % the mini time for avoiding detecting same shift
threshold = 3; % the velocity threshold (*median) for detecting shift 
%minDis = 1; % the displacement threshold (*normalized data) for detecting shift 

% cfg run_smooth, 
v2struct(cfg);

% creat data 
data = [];
data.gaze_raw = squeeze(eye_data);

%% smooth raw data
if smooth_raw
    data.gaze_raw_sm = smoothdata(data.gaze_raw,2,'gaussian',smooth_step);
else
    data.gaze_raw_sm = data.gaze_raw;
end

%% get  derivative
% velocity
data.der = diff(data.gaze_raw_sm,1,2);
data.absder = abs(data.der);

if smooth_der
    data.der_sm = smoothdata(data.der,2,'gaussian',smooth_step);
    data.absder_sm = smoothdata(data.absder,2,'gaussian',smooth_step);
else
    data.der_sm = data.der;
    data.absder_sm = data.absder;
end

%%
gaze_shift = zeros(size(data.gaze_raw()));
for i = 1:size(data.gaze_raw(),1)
        
    med1 = nanmedian(data.absder_sm(i,:));
    
     % find shifts and mark them in raw traces        
    idx = 0;  dbef = []; daft = [];
    dat2use = data.absder_sm(i,:);
    datorig = data.gaze_raw(i,:);   
    %keyboard
    for t = winbef+1:size(dat2use,2)-minISI;           
        
        if dat2use(t) >= med1 * threshold  
            idx = idx+1; 
            dat2use(t+1:t+minISI) = 0;
            dbef(idx) = nanmean(datorig([t-winbef])); % data before
            daft(idx) = nanmean(datorig([t+winaft])); % data after
            med_gaze_raw = nanmedian(data.gaze_raw(i,:));
            
            gaze_shift(i, t+1) = daft(idx) - dbef(idx);
            
        end
    end
end
data_output = gaze_shift;
