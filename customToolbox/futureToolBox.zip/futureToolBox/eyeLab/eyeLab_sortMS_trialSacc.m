function eyeLab_sortMS_trialSacc(cfg)
v2struct(cfg); % cfg = input_file, output_dir, time, time_i, trial_step
load(input_file);
numTrials = size(gazeShift.gazeL_to,1);

trial_start = 1 :trial_step : numTrials-trial_step;
trial_end = trial_start + trial_step;


outfile = output_dir;
outfile_raw = creatDir([outfile filesep 'trlSacc']);

% outfile_to_q1 = creatDir([outfile filesep 'event_to_q1']);
% outfile_to_q2 = creatDir([outfile filesep 'event_to_q2']);
% outfile_to_q3 = creatDir([outfile filesep 'event_to_q3']);
% outfile_to_q4 = creatDir([outfile filesep 'event_to_q4']);
% 
% outfile_to_thr1 = creatDir([outfile filesep 'event_to_thr1']);
% outfile_to_thr2 = creatDir([outfile filesep 'event_to_thr2']);
% outfile_to_thr3 = creatDir([outfile filesep 'event_to_thr3']);

gaze_window = time_i;
t2sort = dsearchn(time', gaze_window');
meanTime = diff(t2sort)/2;
GA_struct = [];
GA_struct.trial_to = zeros(1,length(trial_start));
GA_struct.trial_unTrust = zeros(1,length(trial_start));
GA_struct.trial_aw = zeros(1,length(trial_start));
GA_struct.trial_noMs = zeros(1,length(trial_start));
GA_struct.time = ones(1,length(trial_start));

%extract media
ind_to =[];
for trialID = 1 : numTrials 
    [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2sort(1):t2sort(2)]));
    [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2sort(1):t2sort(2)]));
    
    if (indL_to+indR_to) > 0
    ind_to(end+1) = indL_to+indR_to;
    end   
end

medianTime = nanmedian(ind_to); 

if exist('midCut')
    infoDisp('doing self cut', 'line')
    cut_point1 = dsearchn(time', midCut');
    cut_point = cut_point1 - t2sort(1);
else
    cut_point = medianTime;
end
%% caculated quantile
Q1=prctile(ind_to,25);
Q2=prctile(ind_to,50);
Q3=prctile(ind_to,75);

T1 = prctile(ind_to,33.3);
T2 = prctile(ind_to,66.6);

%extract info
for trialW_ind = 1 : length(trial_start)
    trl_start = trial_start(trialW_ind);
    trl_end = trial_end(trialW_ind);
    trial_toW = [];
    trial_awW = [];
    trial_unTrustW = [];
    trial_sacc = [];
    
    for trialID = trl_start : trl_end 
        events = [];
        [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2sort(1):t2sort(2)]));
        [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2sort(1):t2sort(2)]));
        [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2sort(1):t2sort(2)]));
        [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2sort(1):t2sort(2)]));
        [~, ind_unTrust]=ismember(1,gazeShift.gazeUnTrust(trialID,[t2sort(1):t2sort(2)]));
        events = [indL_to indR_to indL_aw indR_aw ind_unTrust];
        msEventsInd = find(events);
        [firstEvent, typeInd] =min(events(msEventsInd));
        eventType = msEventsInd(typeInd);

        if ~isempty(eventType)
            if eventType <= 2
                trial_toW(trialID) =1;

    %             if firstEvent <= Q1;
    %                 trial_to_Q1(trialID) =1;
    %             elseif firstEvent <= Q2
    %                 trial_to_Q2(trialID) =1;
    %             elseif firstEvent <= Q3
    %                 trial_to_Q3(trialID) =1;
    %             else
    %                 trial_to_Q4(trialID) =1;
    %             end
    %             
    %             if firstEvent <= T1
    %                 trial_to_T1(trialID) =1;
    %             elseif firstEvent <= T2
    %                 trial_to_T2(trialID) =1;
    %             else
    %                 trial_to_T3(trialID) =1;
    %             end

            elseif eventType <= 4
                trial_awW(trialID) =1;
            elseif eventType == 5
                trial_unTrustW(trialID) =1;
            end

            trial_sacc(trialID) = 1;
        end
    end
    GA_struct.trial_to(trialW_ind) = sum(trial_toW);
    GA_struct.trial_aw(trialW_ind) = sum(trial_awW);
    GA_struct.trial_unTrust(trialW_ind) = sum(trial_unTrustW);
    GA_struct.trial_noMs(trialW_ind) = length(trl_start : trl_end ) - sum(trial_sacc);
    GA_struct.time(trialW_ind) = (trl_start + trl_end) /2;
end

save([outfile_raw  filesep input_file(end - 7:end)], 'GA_struct');


end
