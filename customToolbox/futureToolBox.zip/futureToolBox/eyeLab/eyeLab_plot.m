function [g_out] = eyeLab_plot(cfg)

v2struct(cfg); % cfg = indiv, GA_address, value, dime
load(GA_address);
GA = GA_gaze;

value_index = ismember(GA.labelValue, value);
if dim ==1
    if strcmp(plotType,'indiv')
        len_fig = ceil(sqrt(size(GA.X,1))); rawNum =1; colnNum = 0;
        for subjInd = 1:size(GA.X,1)
            data = squeeze(GA.X(subjInd, value_index,:,:));
            data = {data'};
            %data = D2array2Cell(data);
            if subjInd > len_fig*rawNum
                rawNum = rawNum +1;
                colnNum = 0;
            end
            colnNum = colnNum +1;
            %keyboard
            g(rawNum,colnNum)=gramm('x',GA.time, 'y',data);%, 'color',GA.labelDim2);
            g(rawNum,colnNum).geom_line();
            g(rawNum,colnNum).set_title(GA.subjID{subjInd}) ;
        end

        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of probe)','y','Towardness (%)','column','task');
        g.axe_property('Xlim', [-0.25 1.25],'YLim',[-2 10],'YTick',[-10: 5: 10]);
        %g.set_order_options('color', GA.labelDim2);
        figure('Position',[100 100 len_fig*600 len_fig*500]);
        g.draw();
        
        rawNum =1; colnNum = 0;
        for subjInd = 1:size(GA.X,1)
            if subjInd > len_fig*rawNum
                rawNum = rawNum +1;
                colnNum = 0;
            end
            colnNum = colnNum +1;
            line([0 0],[-2 10],'Color','k','LineStyle','--','Parent',g(rawNum,colnNum).facet_axes_handles(1));
            line([-0.25 1.25],[0 0],'Color','k','LineStyle','--','Parent',g(rawNum,colnNum).facet_axes_handles(1));
        end
    end

    data_sum = []; condMaker ={};
    if strcmp(plotType,'sum')
        for subjInd = 1:size(GA.X,1)
            data = squeeze(GA.X(subjInd, value_index,:,:));
            data_sum = [data_sum {data'}];
            %condMaker= [condMaker GA.labelDim2];
        end
%         data_sum = data_sum./2;
%         data_sum = D2array2Cell(data_sum);
        if ~exist('subplotInd')
            
            g(1,1)=gramm('x',GA.time, 'y',data_sum);%, 'color',GA.labelDim2);
            g(1,1).stat_summary();
            g(1,1).set_title(plot_title)
        else
            g(subplotInd(1),subplotInd(2))=gramm('x',GA.time, 'y',data_sum, 'color',condMaker);
            g(subplotInd(1),subplotInd(2)).stat_summary();
            g(subplotInd(1),subplotInd(2)).set_title(plot_title)
        end
        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of probe)','y','Towardness (%)','column','task');
        g.axe_property('Xlim', [-0.25 1.25], 'YLim',[-2 10],'YTick',[-2: 5: 10]);
        %g.set_order_options('color', GA.labelDim2);
        if ~exist('subplotInd')
            figure('Position',[100 100 400 300]);
            g.draw();
            line([0 0],[-2 10],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
            line([-0.25 1.25],[0 0],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
            if exist('timeLine')
                for lineInd = 1:length(timeLine)
                    line([timeLine(lineInd) timeLine(lineInd)],[-2 10],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
                end
            end

        else
            g_out = g;
        end
    end
    
elseif dim == 2 
    
    if strcmp(plotType,'indiv')
        len_fig = ceil(sqrt(size(GA.X,1))); rawNum =1; colnNum = 0;
        for subjInd = 1:size(GA.X,1)
            data = squeeze(GA.X(subjInd, value_index,:,:));
            data = D2array2Cell(data);
            if subjInd > len_fig*rawNum
                rawNum = rawNum +1;
                colnNum = 0;
            end
            colnNum = colnNum +1;
            %keyboard
            g(rawNum,colnNum)=gramm('x',GA.time, 'y',data, 'color',GA.labelDim2);
            g(rawNum,colnNum).geom_line();
            g(rawNum,colnNum).set_title(GA.subjID{subjInd}) ;
        end

        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of probe)','y','Towardness (%)','column','task');
        g.axe_property('Xlim', [-0.25 1.25],'YLim',[-2 15],'YTick',[-10: 5: 10]);
        g.set_order_options('color', GA.labelDim2);
        figure('Position',[100 100 len_fig*600 len_fig*500]);
        g.draw();
        
        rawNum =1; colnNum = 0;
        for subjInd = 1:size(GA.X,1)
            if subjInd > len_fig*rawNum
                rawNum = rawNum +1;
                colnNum = 0;
            end
            colnNum = colnNum +1;
            line([0 0],[-2 10],'Color','k','LineStyle','--','Parent',g(rawNum,colnNum).facet_axes_handles(1));
            line([-0.25 1.25],[0 0],'Color','k','LineStyle','--','Parent',g(rawNum,colnNum).facet_axes_handles(1));
        end
    end

    data_sum = []; condMaker ={};
    if strcmp(plotType,'sum')
        for subjInd = 1:size(GA.X,1)
            data = squeeze(GA.X(subjInd, value_index,:,:));
            data_sum = [data_sum; data];
            condMaker= [condMaker GA.labelDim2];
        end
%         data_sum = data_sum./2;
         data_sum = D2array2Cell(data_sum);
        if ~exist('subplotInd')
            
            g(1,1)=gramm('x',GA.time, 'y',data_sum, 'color',condMaker);
            g(1,1).stat_summary();
            g(1,1).set_title(plot_title)
        else
            g(subplotInd(1),subplotInd(2))=gramm('x',GA.time, 'y',data_sum, 'color',condMaker);
            g(subplotInd(1),subplotInd(2)).stat_summary();
            g(subplotInd(1),subplotInd(2)).set_title(plot_title)
        end
        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of probe)','y','Towardness (%)','column','task');
        g.axe_property('Xlim', [-0.25 1.25], 'YLim',[-15 30],'YTick',[-15: 5: 30]);
        g.set_order_options('color', GA.labelDim2);
        if ~exist('subplotInd')
            figure('Position',[100 100 400 300]);
            g.draw();
            line([0 0],[-15 30],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
            line([-0.25 1.25],[0 0],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
            if exist('timeLine')
                for lineInd = 1:length(timeLine)
                    line([timeLine(lineInd) timeLine(lineInd)],[-15 30],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
                end
            end

        else
            g_out = g;
        end
    end
    
else
    if strcmp(plotType,'indiv')
        for subjInd = 1:size(GA.X,1)
            data_sum =[];
            colorMaker = {};
            colomnMaker = {};
            for cond1 = 1:size(GA.labelDim2,2)
                for cond2 = 1:size(GA.labelDim3,2)                  
                     data = squeeze(GA.X(subjInd, value_index,cond1,cond2,:));
                     %keyboard
                     data_sum = [data_sum; data'];
                     colorMaker = [colorMaker GA.labelDim2{cond1}];
                     colomnMaker = [colomnMaker GA.labelDim3{cond2}];
                end
            end
            %keyboard    
            data_sum = D2array2Cell(data_sum);
            g(1,subjInd)=gramm('x',GA.time, 'y',data_sum, 'color',colorMaker);
            g(1,subjInd).geom_line();
            g(1,subjInd).facet_grid(colomnMaker, []) ;
            g(1,subjInd).set_title(['pp' num2str(subjInd)]);
        end
        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of encoding)','y','Towardness (%)','column','task');
        g.axe_property('YLim',[-25 25],'YTick',[-20: 5: 20]);
        g.set_order_options('row',GA.labelDim3, 'color', GA.labelDim2)
        figure('Position',[100 100 size(GA.X,1)*600 size(GA.labelDim3,2)*500]);
        g.draw();
    end
    
    if strcmp(plotType,'sum')
            data_sum =[];
            colorMaker = {};
            colomnMaker = {};
        for subjInd = 1:size(GA.X,1)
            for cond1 = 1:size(GA.labelDim2,2)
                for cond2 = 1:size(GA.labelDim3,2)                  
                     data = squeeze(GA.X(subjInd, value_index,cond1,cond2,:));
                     %keyboard
                     data_sum = [data_sum; data'];
                     colorMaker = [colorMaker GA.labelDim2{cond1}];
                     colomnMaker = [colomnMaker GA.labelDim3{cond2}];
                end
            end
        end
        data_sum = D2array2Cell(data_sum);
        g(1,1)=gramm('x',GA.time, 'y',data_sum, 'color',colorMaker);
        g(1,1).stat_summary();
        g(1,1).facet_grid([], colomnMaker) ;
        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = onset of encoding)','y','Towardness (%)','column','task');
        g.axe_property('YLim',[-25 25],'YTick',[-20: 5: 20]);
        g.set_order_options('column',GA.labelDim3, 'color', GA.labelDim2);
        figure('Position',[100 100 size(GA.labelDim3,2)*300 250]);
        g.draw();
    end
end
end