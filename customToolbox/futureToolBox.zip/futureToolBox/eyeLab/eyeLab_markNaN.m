function eyeLab_markNaN(cfg)

% function eyeLab_timeBin(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.time_i           = the range of time that should not have bin;
%       cfg.output_dir        = uknow.
%       cfg.input_dir      = string specifiying the directory where the gazeShift files are;
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

% extract cfg value
v2struct(cfg);

% load eye data
infoDisp(['load gaze data for subj ' input_dir(end-7:end-4)]);
load(input_dir);

% out file 
out_file = creatDir([ output_dir filesep 'trial_ok_noNan' ]);

%% select data...
cfg = [];
cfg.channel = {'eyeX' 'eyeY'};
data = ft_selectdata(cfg, eye_data);

%% time lock analysis
cfg = [];
cfg.keeptrials = 'yes';
tl = ft_timelockanalysis(cfg, data);

%% find interest timeWindow
t2sort = dsearchn(tl.time',time_i')';

%% 
numTrial = size(tl.trial,1);
trialOk = zeros(1,numTrial);
for trlInd = 1:numTrial
    infoDisp(['detect NaN value ' num2str(trlInd) ' out of ', num2str(numTrial)],'loop',trlInd,numTrial)
    
    if trlInd == numTrial; fprintf('\n'); end;
    
    xnan = isnan(tl.trial(trlInd,1,t2sort(1):1:t2sort(2)));
    ynan = isnan(tl.trial(trlInd,2,t2sort(1):1:t2sort(2)));
    
    if sum([sum(xnan) sum(ynan)]) == 0
        trialOk(trlInd) = 1;
    end
end
event.sel = logical(trialOk);
save([out_file filesep input_dir(end-7:end-4) '.mat'], 'event')
end