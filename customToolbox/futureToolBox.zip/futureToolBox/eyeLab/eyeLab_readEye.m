function [data_out, trial_ok] = eyeLab_readEye(cfg)

% function eyeLab_GAgaze(cfg)
% Description: grand average the gaze resutls
%       cfg.input_dir       = the dir of epoched eye_data
%       cfg.goodness_file   = dir of events we use to select trial.
%       cfg.channel         = to be used channel;
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

%% extract value
v2struct(cfg); 

%%
load(input_dir);
numTrial = size(eye_data.trial,1);
%% only keep channels of interest
cfg = [];
cfg.channel = channel;
data = ft_preprocessing(cfg, eye_data);
%% removebad trials
if exist('goodness_file')
    tl_ok = 0;
    for fileInd  = 1: length(goodness_file)
        load(goodness_file{fileInd})
        tl_ok = event.sel + tl_ok;
    end
    trial_ok = ismember(tl_ok, length(goodness_file));
else
    trial_ok = logical(ones(1,numTrial)');
end   

infoDisp(['get ' num2str(sum(trial_ok)) '/' num2str(numTrial) ' to process'], 'line')

cfg = [];
cfg.trials = trial_ok;
data = ft_selectdata(cfg, data);
%% time lock analysis
cfg = [];
cfg.keeptrials = 'yes';
data_out = ft_timelockanalysis(cfg, data);
end