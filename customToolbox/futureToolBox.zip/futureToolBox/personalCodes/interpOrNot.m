%% Analysis script for EEG data 

%% It's always good to start with a clean sheet
clc, clear, close all, warning('off','all')

%% set project name
projectname = 'Re analysis Freek data';

%% Set directions
parent_folder = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/';

cfg= [];
cfg.package_folder = '/Users/baiweil/Documents/MATLAB_pacakges/';
cfg.scripts_path = [parent_folder  'Scripts'];
cfg.eyeLab_path = [parent_folder 'eyeLab'];
cfg.eegFuture_path = [parent_folder 'eegFuture'];
cd(cfg.eyeLab_path);
eyeLab_setup(cfg);

read_dir1 = [parent_folder  'data/eye_raw/exp1_sess1_eye'];
read_dir2 = [parent_folder  'data/eye_raw/exp1_sess2_eye'];

write_dir_interp = creatDir([parent_folder 'eegResults_interp']);
write_dir_nonInterp = creatDir([parent_folder 'eegResults_nonInterp']);
 
%% triggers
trigs.left_en = [21 22];
trigs.right_en= [23 24];
trigs.left_hand = [21 23];
trigs.right_hand = [22 24];
trigs.epoch = [21:24];
%% set parameter
projectname = 'reanalysisFreekData';
epoch_trig = [21:24];
epoch_time = [-0.5 1.5]; % the first is prestim, the second is poststim
localiser_trig = [201:209];
localiser_epoch_time = [-0.5 1.5];

%% step 1: epoch trial and localizer data without interp
sublist1 = get_subFiles(read_dir1,'*.asc');
sublist2 = get_subFiles(read_dir2,'*.asc');
cfg = {};
parfor subjInd = 1:length(sublist1)
    cfg =[];
    cfg.file_name = {[sublist1{subjInd}] [sublist2{subjInd}]};
    cfg.outPut_folder = write_dir_nonInterp;
    cfg.epoch_trig = epoch_trig;
    cfg.epoch_time = epoch_time;
    cfg.localiser_trig = localiser_trig;
    cfg.localiser_epoch_time = localiser_epoch_time;
    cfg.subjID = ['pp' sublist1{subjInd}(end-8:end-7)];
    cfg.maxBinkDuration = 0;
    eyeLab_preprocess(cfg)
end

%% step 2: epoch trial and localizer data with interp
sublist1 = [];
sublist1 = get_subFiles(read_dir1,'*.asc');
sublist2 = get_subFiles(read_dir2,'*.asc');
cfg = {};
parfor subjInd = 1:length(sublist1)
    cfg =[];
    cfg.file_name = {[sublist1{subjInd}] [sublist2{subjInd}]};
    cfg.outPut_folder = write_dir_interp;
    cfg.epoch_trig = epoch_trig;
    cfg.epoch_time = epoch_time;
    cfg.localiser_trig = localiser_trig;
    cfg.localiser_epoch_time = localiser_epoch_time;
    cfg.subjID = ['pp' sublist1{subjInd}(end-8:end-7)];
    eyeLab_preprocess(cfg)
end

%% step 3: mark the trial with Nan in time window

readDir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_nonInterp/epoched_data'; 
sublist = get_subFiles(readDir);
for subjInd = 1:length(sublist)
    cfg =[];
    cfg.input_file = sublist{subjInd};
    cfg.output_dir = write_dir_nonInterp;
    cfg.time_i = [0.2 0.6];
    eyeLab_markNaN(cfg)
end

readDir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_interp/epoched_data'; 
sublist = get_subFiles(readDir);
for subjInd = 1:length(sublist)
    cfg =[];
    cfg.input_file = sublist{subjInd};
    cfg.output_dir = write_dir_interp;
    cfg.time_i = [0.2 0.6];
    eyeLab_markNaN(cfg)
end

%% step 4: do normal analysis 

%% plot eye position 
% Group level eye position 
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_noMS';
postEvent = get_subFiles(postEvent_dir,'event*');

cfg = [];
cfg.epoch_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data'];
cfg.goodness_file = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_nonInterp/trial_ok_noNan';
cfg.channel = {'eyeX' 'eyeY'};
cfg.cond_trigger = {{trigs.left_en, trigs.right_en}}; 
cfg.postEvent = postEvent;
cfg.dim3 = false;
cfg.dim2Name = {'noMS-200-600' 'noMS-200-600'}; % the order of lable should be same as the lable in postEvent folder 
cfg.dataName = 'twoCond_nonInterp_NanTest';
cfg.write_dir = write_dir;
cfg.removeBadTrial = true;
GA_data_NanRem = eyeLab_groupAnalysis(cfg);

%%
cfg = [];
cfg.plotType = 'indiv';
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResultsgroupResults/twoCond_nonInterp_noNanTest_GA.mat';
cfg.value = 'toward';
cfg.dim3 = false;
cfg.figure_dir = creatDir([write_dir filesep 'figures' filesep 'pos']);
eyeLab_plot(cfg);

cfg.plotType = 'sum';
%cfg.subplotInd = [thresholdInd,minDis4Ms];
if exist('g_gaze')
    cfg.g = g_gaze;
end
%cfg.plot_title = ['thre' num2str(threshold) '_' 'minDis' num2str(minDis4Ms)];
cfg.plot_title = ['control']
g_gaze = eyeLab_plot(cfg);

%%
file_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_nonInterp/trial_ok_noNan';
subList = get_subFiles(file_dir);

for i = 1:length(subList)
    load(subList{i})
    a(i) = sum(event_sel);
end 

file_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_interp/trial_ok_noNan';
subList = get_subFiles(file_dir);

for i = 1:length(subList)
    load(subList{i})
    b(i) = sum(event_sel);
end 
%%
figure()
y = squeeze(mean(GA_data.X(:,4,1,:)));
st = squeeze(mean(GA_data.XSE(:,4,1,:)));
boundedline(GA_data.time,y',st','alpha','-r')

y = squeeze(mean(GA_data_NanRem.X(:,4,1,:)));
st = squeeze(mean(GA_data_NanRem.XSE(:,4,1,:)));
boundedline(GA_data.time,y',st','alpha','-b')

legend({'withNan' 'withoutNan'})
xlim([-0.2 1.0])
ylim([0 8.0])

%% 
subList = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep');
out = creatDir('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep_event');
for i = 1:length(subList)
    load(subList{i})
    event_sel = trl2keep';
    save(['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep_event/' subList{i}(end-7:end) ] , 'event_sel')
end

%% 
subList = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_noMS/event_noMS');
trial_clean = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_nonInterp/trial_ok_noNan');

out = creatDir('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_noMS/event_noMS_noNaN');
for i = 1:length(subList)
    load(subList{i})
    load(trial_clean{i})
    events_sel = events_sel&event_sel;
    save(['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_noMS/event_noMS_noNaN/' subList{i}(end-7:end) ] , 'events_sel')
end
%% group analysis post Event (aw vs. to vs. noMS)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_noMS/';
cond_NaN = [postEvent_dir 'event_noMS'];
cond_noNaN = [postEvent_dir 'event_noMS_noNaN'];
trialOKDir1 = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep_event';
trialOKDir2 = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults_nonInterp/trial_ok_noNan';

postEvent = {cond_NaN cond_noNaN};

cfg = [];
cfg.input_file = write_dir_tf_Lap_raw;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = trialOKDir1;
%cfg.post_trial_ok_dir = trialOKDir2;
cfg.dim2Name = {'withNan' 'withoutNan'};
cfg.write_dir = [write_dir];
cfg.fileName = 'raw_Lap_NanVsNoNan';
GA_data = eegFutureTF_GApostEvent(cfg);


%% sum plot (aw vs. to vs. noMS)
cfg = [];
cfg.cond2plot = {'withNan' 'withoutNan'}% 'raw'}%, 'noMS'};
cfg.i_freq = freqs.alphafreq;
%cfg.controlCond = 1;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_raw_Lap_NanVsNoNan.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';

cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);