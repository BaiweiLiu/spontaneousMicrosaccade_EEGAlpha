function data = str2listInTable(data, columnName)
    for linedInd = 1:height(data)    
        
        eval(['str_info = data.' columnName '(linedInd);'])
        num_info = str2num(str_info{1});
        if linedInd == 1
            list = [num_info];
        else
            list = [list; num_info];
        end
    end
    size(list);
    height(data);
    eval(['data.' columnName ' = [];'])
    eval(['data.' columnName ' = list;'])
end
