function [data_out] = cond_num2str(input,numCond, strCond)
Cond_Cell = cell(size(input));
for indC = 1: length(input)
    for indT = 1:length(numCond)
        if input(indC) == numCond(indT)
            Cond_Cell{indC} = strCond{indT};
        end
    end
end
data_out = Cond_Cell;
end
