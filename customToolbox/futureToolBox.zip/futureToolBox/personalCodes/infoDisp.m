function infoDisp(info, varargin)
% Baiwei Liu, vu, 2021
if isempty(varargin)
    disp(['#################################################'])
    disp(info);
    disp(['#################################################'])
elseif strcmp(varargin(1), 'line')
    disp(['###### ' info ' ######']);
    
elseif strcmp(varargin(1), 'loop') 
    msg = [' ' info ' ######'];
    
    if varargin{2} == 1
        disp('##### loop information:   ')
        reverseStr =[];
        fprintf([reverseStr, msg]);
    elseif varargin{2}< varargin{3}
        reverseStr = repmat(sprintf('\b'), 1, length(msg));
        fprintf([reverseStr, msg]);
    elseif varargin{2}== varargin{3}
        reverseStr = repmat(sprintf('\b'), 1, length(msg));
        fprintf([reverseStr, msg]);
        fprintf('\n');
    end
    end
end
