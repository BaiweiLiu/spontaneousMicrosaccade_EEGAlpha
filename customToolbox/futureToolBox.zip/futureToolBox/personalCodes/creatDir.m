function [data_out] = creatDir(file_dir)
if ~exist(file_dir,'dir'); mkdir(file_dir); end
data_out = file_dir;
end