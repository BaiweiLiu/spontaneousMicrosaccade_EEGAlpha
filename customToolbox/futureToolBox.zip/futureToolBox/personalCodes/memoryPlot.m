%% behavioral pilot 

%% It's always good to start with a clean sheet
clear, close all, warning('off','all')

%% Set directions
parent_folder = '/Users/baiweil/Library/Mobile Documents/com~apple~CloudDocs/Projects/PrepareWM4Action/Prepare_multiple_task/Storing&interference/Exp1_Eyetracker';
scripts_folder = [parent_folder filesep 'analysisScripts'];
package_folder = '/Users/baiweil/Documents/MATLAB';
addpath(package_folder,'-begin');addpath(scripts_folder,'-begin');

read_dir = [parent_folder filesep 'data/raw_data_memory']; 
write_dir = [parent_folder filesep 'data/write_data']; 

if ~exist(write_dir,'dir')
    mkdir(write_dir)
end

%% parameter
condition = {'pure', 'mix', 'neutral'};
matchCond = {'match', 'nonMatch'};

cd(read_dir)
sublist=dir('*.csv');
sublist={sublist.name};

%% Extract and clear the subjects data

%% Trial based process
for subjInd = 1:length(sublist)  
    rawTable = readtable(sublist{subjInd},'Delimiter', '\t'); %Load the csv file
    data_test = rawTable(strcmp(rawTable.prac,'formal'),:);
    data_formal = str2listInTable(data_test, 'oris_search');
    memory_bias = {};
    locs_search = {};
    target_turn ={};
    conds_match ={};
    errors = [];
    between_diff = [];
    encodoing_diff = data_formal.test_ori - data_formal.ori_nonTarget;
    for linedInd = 1:height(data_formal)    
%         if data_formal.between_diff(linedInd) > 0
%             bias = 'right';
%         else
%             bias = 'left';
%         end

%         memory_bias{linedInd} = bias;
        
        raw_error = data_formal.ori_current(linedInd) - data_formal.test_ori(linedInd);
        
        if raw_error > 90
            real_error = raw_error- 180;
        elseif raw_error < - 90
            real_error = raw_error + 180;
        else
            real_error = raw_error;
        end
         
        errors(linedInd) = real_error;
        
        if encodoing_diff(linedInd) > 90
            real_diff = encodoing_diff(linedInd)- 180;
        elseif encodoing_diff(linedInd) < - 90
            real_diff = encodoing_diff(linedInd) + 180;
        else
            real_diff = encodoing_diff(linedInd);
        end
            
        between_diff(linedInd) = real_diff;
    end

%     data_formal.memory_bias =memory_bias';
    data_formal.between_diff = between_diff';
    
    data_formal.real_error = errors';
    data_formal.abs_error = abs(errors');
    
    data_formal.RT = data_formal.time_startRep - data_formal.current_time;
    data_formal.time_endRep = [];
    sum_T{subjInd} = data_formal;
    responseRate(subjInd) = height(data_formal) / height(data_test);
end
%% sum Data and convert data to struct
Data = sum_T;
for dataID = 1:length(Data)
    if dataID == 1
        sumAfter_table = Data{dataID};
    end
    sumAfter_table = [sumAfter_table; Data{dataID}];
end
Cleared_Data = table2struct(sumAfter_table,'ToScalar',true);
%% setting for plot 
colors = [173,216,161; 237 152 121; 96 182 196];
colors_line = [85 161 92; 204 63 50; 48 111 183];
colors = colors/256;
colors_line = colors_line/256;
%% plot for RT and ACC
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars',{'RT','abs_error'} );

y = [];
figure('Position',[100 100 900 300])
subplot(1,2,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    if condId ==1
        y = data.mean_RT;
        y_abs = data.mean_abs_error;
    else
        y = [y data.mean_RT];
        y_abs = [y_abs data.mean_abs_error];
    end
end

x = [10 20 30];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
ylabel('RT (ms)') 
% set(gca,'ylim',[0 1000],'TickLength', [0.03,0.2]);
% set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
% ABS error

subplot(1,2,2);
x = [10 20 30];
    HDots = dotdensity(x, y_abs, 'meanLine', 'on','delta',0.5,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', 'o');
hold off
ylabel('Abs Error') 
set(gca,'ylim',[0 50],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%%
figure('Position',[100 100 1500 400])
clear g
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','RT');

g(1,1)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_RT);
g(1,1).axe_property('YLim',[500 1500],'YTick', [500:200:2000]);
g(1,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','abs_error');
g(1,2)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_abs_error);
g(1,2).axe_property('YLim',[0 30],'YTick', [0:5:30]);
g(1,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

% push pull
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond', 'between_diff'}, 'mean', 'DataVars',{'real_error'} );
grouped_data = sortrows(grouped_data,'between_diff')
g(1,3)=gramm('x',grouped_data.between_diff,'y',grouped_data.mean_real_error, 'color',grouped_data.blockCond);
g(1,3).stat_summary('bin_in',10);
g(1,3).axe_property('YLim',[-20 20]);
g(1,3).axe_property('XLim',[-90 90]);
%g(1,1).stat_smooth('lambda','auto')
% g(1,1).facet_grid([],grouped_data.subj);
g(1,3).set_names('column','Probe Task','x','Orientation Difference','y','Response Bias', 'color','# Encoding condition');

% line([0 0],[-50 50],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1));
% line([-150 150],[0 0],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1));
g.set_order_options('x',{'pure', 'mix','neutral'})
g(1,1).set_names('column','pp','x','Encoding condition','y','Reaction time (ms)');
g(1,2).set_names('column','pp','x','Encoding condition','y','Abs_errors');
g(1,1:2).set_layout_options('legend',false);
g(1,3).set_layout_options('legend_position',[0.9 0.8 0.15 0.25]);
g.set_text_options('base_size',15,'label_scaling',1.4)
g.draw()
%% push pull
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond', 'between_diff'}, 'mean', 'DataVars',{'real_error'} );
grouped_data = sortrows(grouped_data,'between_diff')
clear g
g(1,1)=gramm('x',grouped_data.between_diff,'y',grouped_data.mean_real_error, 'color',grouped_data.blockCond);
g(1,1).stat_summary('bin_in',10);
g(1,1).axe_property('YLim',[-20 20]);
g(1,1).axe_property('XLim',[-90 90]);
%g(1,1).stat_smooth('lambda','auto')
% g(1,1).facet_grid([],grouped_data.subj);
g(1,1).set_names('column','Probe Task','x','Orientation Difference','y','Response Bias', 'color','# Encoding condition');
figure('Position',[100 100 500 300]);
g.draw();
line([0 0],[-50 50],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1));
line([-150 150],[0 0],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1));

%% cost 
figure('Position',[100 100 1000 400])
clear g
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','RT');

U = unstack(grouped_data,{'mean_RT' 'GroupCount'},'blockCond');
U.mean_RT_mix = U.mean_RT_mix - U.mean_RT_neutral;
U.mean_RT_pure = U.mean_RT_pure - U.mean_RT_neutral;
U.mean_RT_neutral = [];
U.Properties.VariableNames{'mean_RT_mix'} = 'mix';
U.Properties.VariableNames{'mean_RT_pure'} = 'pure';
U = stack(U, {'mix', 'pure'});
U.Properties.VariableNames{'mix_pure'} = 'benifit';
U.Properties.VariableNames{'mix_pure_Indicator'} = 'blockCond';

g(1,1)=gramm('x',U.blockCond,'y',U.benifit);
g(1,1).axe_property('YLim',[-200 200],'YTick', [-200:100:200]);
g(1,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','abs_error');

U = unstack(grouped_data,{'mean_abs_error' 'GroupCount'},'blockCond');
U.mean_abs_error_mix = U.mean_abs_error_mix - U.mean_abs_error_neutral;
U.mean_abs_error_pure = U.mean_abs_error_pure - U.mean_abs_error_neutral;
U.mean_abs_error_neutral = [];
U.Properties.VariableNames{'mean_abs_error_mix'} = 'mix';
U.Properties.VariableNames{'mean_abs_error_pure'} = 'pure';
U = stack(U, {'mix', 'pure'});
U.Properties.VariableNames{'mix_pure'} = 'benifit';
U.Properties.VariableNames{'mix_pure_Indicator'} = 'blockCond';

g(1,2)=gramm('x',U.blockCond,'y',U.benifit);
g(1,2).axe_property('YLim',[-3 3],'YTick', [-3:1:3]);
g(1,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
g(1,1).set_names('column','pp','x','Encoding condition','y','Reaction time (ms)');
g(1,2).set_names('column','pp','x','Encoding condition','y','Abs_errors');
g.set_text_options('base_size',15,'label_scaling',1.4)
g.draw()