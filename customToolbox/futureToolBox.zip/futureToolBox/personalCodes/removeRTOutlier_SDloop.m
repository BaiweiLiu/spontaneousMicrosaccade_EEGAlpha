function [clean_index, data_cleared] = removeRTOutlier_SDloop(data, loopTime, outlierThresholdRT)

data_cleared = data;
raw_index = 1:length(data);
index_cleared = raw_index;

for loopInd = 1:loopTime
    SD  = std(data_cleared);
    max = outlierThresholdRT *SD + mean(data_cleared);
    min = -outlierThresholdRT *SD + mean(data_cleared);
    
    resp_time_index = (data_cleared < max) & (data_cleared > min);
    
    data_cleared = data_cleared(resp_time_index);
    index_cleared = index_cleared(resp_time_index);
end

clean_index = ismember(raw_index,index_cleared)';
end