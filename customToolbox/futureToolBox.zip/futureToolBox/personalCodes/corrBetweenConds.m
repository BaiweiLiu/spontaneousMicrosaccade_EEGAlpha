%% Analysis script for correlation 
%% It's always good to start with a clean sheet
clc, clear, close all, warning('off','all')

%% set project name
projectname = 'Re analysis Freek data';

%% Set directions
parent_folder = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/';

cfg= [];
cfg.package_folder = '/Users/baiweil/Documents/MATLAB_pacakges/';
cfg.scripts_path = [parent_folder  'Scripts'];
cfg.eyeLab_path = [parent_folder 'eyeLab'];
cfg.eegFuture_path = [parent_folder 'eegFuture'];
cd(cfg.eyeLab_path);
eyeLab_setup(cfg);

read_dir1 = [parent_folder  'data' filesep 'EEG_raw/session1'];
read_dir2 = [parent_folder  'data' filesep 'EEG_raw/session2'];

write_dir = creatDir([parent_folder 'eegResults']);
write_dir_tf = creatDir([write_dir filesep 'data_tf']);
write_dir_tf_noLap = creatDir([write_dir filesep 'data_tf_noLap']);
write_dir_MVPA = creatDir([write_dir filesep 'results_MVPA']);
write_dir_epoch = creatDir([write_dir filesep 'data_epoch']);

%% gat eye shift

%% channel and freqs selection
[channels,freqs] = eegFuture_selection();

%% triggers
trigs.left_en = [21 22];
trigs.right_en= [23 24];
trigs.left_hand = [21 23];
trigs.right_hand = [22 24];
trigs.epoch = [21:24];

%% get gaze posi 

% Group level eye position 

write_dir = [parent_folder filesep 'eyeGazeResults']; 

postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_raw';
postEvent = get_subFiles(postEvent_dir,'event*');
cfg = [];
cfg.epoch_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data'];
cfg.goodness_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/trialClean/trial_ok_index'];
cfg.channel = {'eyeX' 'eyeY'};
cfg.cond_trigger = {{trigs.left_en, trigs.right_en}}; 
cfg.postEvent = postEvent;
cfg.dim3 = false;
cfg.dim2Name = {'raw'}; % the order of lable should be same as the lable in postEvent folder 
cfg.dataName = 'raw';
cfg.write_dir = write_dir;
cfg.removeBadTrial = false;
GA_data = eyeLab_groupAnalysis(cfg);

%%
gazeData = squeeze(GA_data.X(:,4,:,:));
timeWin = dsearchn(GA_data.time',[0:0.001:1.0]')';
gazeData = gazeData(:,timeWin);
figure
plot(mean(gazeData))

%% get shift data
%% extract shift data
cfg=[];
cfg.time_i = [200, 600];
cfg.time = [-500:1:1200];
cfg.input_dir = [write_dir filesep 'saccDetect'];
cfg.output_dir = [write_dir filesep 'shiftGA_raw'];
cfg.outfile_name = ['rawShift'];
cfg.good_trial_dir = [write_dir filesep 'postEvent_raw' filesep 'event_raw'];
eyeLab_GAshift(cfg)

%%
cfg = [];
cfg.time = [-500:1:1200];
cfg.plotType = 'sum';
%             cfg.figInd = f;
%             if exist('g_shift')
%                 cfg.g = g_shift;
%             end
cfg.figure_dir = creatDir([write_dir filesep 'figures' filesep 'shift']);
cfg.plot_title = ['rawShift'];
cfg.GA_address = [write_dir filesep 'shiftGA_raw' filesep 'rawShift' '.mat'];
%cfg.subplotInd = [thresholdInd,minDis4Ms];
g_shift = eyeLab_plotShift(cfg)

%%
load([write_dir filesep 'shiftGA_raw' filesep 'rawShift' '.mat']);
shiftData = cell2Aarray(GA_shift.hz_to);
shiftData_away = cell2Aarray(GA_shift.hz_aw);
shiftData = shiftData - shiftData_away;
timeWin = dsearchn([-500:1:1200]',[0:1:1000]')';
shiftData = shiftData(:,timeWin);
figure
plot(mean(shiftData))


%% get N2PC
write_dir = creatDir([parent_folder 'eegResults']);
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_raw/';
cond_raw = [postEvent_dir 'event_raw'];


postEvent = {cond_raw};

cfg = [];

cfg.apply_ica = true;
cfg.apply_VR = true;    
cfg.apply_laplacian = true;
cfg.ica_onlyEEG = false;

cfg.data_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/cleanData_lapICAremove';
cfg.dataHere =true;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'rawN2PC'};
cfg.write_dir = [write_dir];
cfg.fileName = 'raw_Lap_N2pc';
cfg.baselinewindow = [-0.25 0];
eegFuture_GApostevent(cfg)

%%
cfg =[];
cfg.dim3 = false;
cfg.cond2plot = {'rawN2PC'};
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_ERP/GA_raw_Lap_N2pc.mat';
cfg.t_mask = true;
cfg.time2plot = [-0.4 1.2];
%cfg.controlCond = 1;
cfg.limitZ = [-0.0001 0.0002];
cfg.subFig = true;
cfg.plotType = 'sum';
cfg.singleCond = false;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
eegFutureEEG_plot(cfg);

%%
load('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_ERP/GA_raw_Lap_N2pc.mat')
N2pcData = squeeze(GA_struct.ERP(:,1,:));
timeWin = dsearchn(GA_struct.time',[0:0.001:1.0]')';
N2pcData = N2pcData(:,timeWin);
figure
plot(mean(N2pcData))

%% get Alpha
write_dir = creatDir([parent_folder 'eegResults']);
sublist = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/cleanData_lapICAremove','*.mat');
write_dir_tf_Lap_raw = creatDir([write_dir filesep 'tf_raw_alpha']);
% run through subj loop
for subjInd = 1 :length(sublist) 
    
    %% read data
    load(sublist{subjInd})
    %% Do TF analysis
    windowsize = 0.3; % 300 ms sliding time window

    cfg = [];
    cfg.taper = 'hanning'; % default hanning taper again
    cfg.method = 'mtmconvol'; % time-resolved frequency analysis (= short-time fourier transform)
    cfg.foi = [8:1:12]; % frequencies of interest (foi)
    cfg.toi = [0:0.001:1]; % times of interest (i.e. where to centre the time-windows for each Fourier analysis on)
    cfg.t_ftimwin = ones(1, length(cfg.foi))*windowsize; % same window for each frequency.
    cfg.pad = 4; % padding the data to obtains the desired frequency resolution
    cfg.keeptrials = 'yes';
    cfg.output = 'pow'; % straight to power
    cfg.channel = [channels.visualL channels.visualR];
    data_tfr = ft_freqanalysis(cfg, data); % tfr.powspctrm = 4D (trials, electrodes, frequencies, timepoints => see also "tfr.dimord");
    
    save([write_dir_tf_Lap_raw filesep sublist{subjInd}(end-7:end)], 'data_tfr');
    clear data, data_tfr
    
end

%% group analysis post Event (aw vs. to vs. noMS)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_raw/';
cond_raw = [postEvent_dir 'event_raw'];

postEvent = {cond_raw};

cfg = [];
cfg.input_file = write_dir_tf_Lap_raw;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'raw'};
cfg.write_dir = [write_dir];
cfg.fileName = 'raw_Lap';
GA_data = eegFutureTF_GApostEvent(cfg);
%%
%% sum plot (aw vs. to vs. noMS)
cfg = [];
cfg.cond2plot = {'raw' 'raw'}%, 'noMS'};
cfg.i_freq = freqs.alphafreq;
%cfg.controlCond = 1;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_raw_Lap.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';

cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%%
load('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_raw_Lap.mat');
alphaSupData = squeeze(mean(GA_struct.power(:,1,:,:),3));
timeWin = dsearchn(GA_struct.time',[0:0.001:1.0]')';
alphaSupData = alphaSupData(:,timeWin);
figure
plot(mean(alphaSupData))

%% plot overLap Figure

overAlpha = - mean(alphaSupData);
overN2PC = - mean(N2pcData);
overToward = mean(gazeData);
overShift = mean(shiftData);

overAlpha =overAlpha -overAlpha(1);
overN2PC =overN2PC -overN2PC(1);
overToward= overToward -overToward(1)
overShift = overShift - overShift(1);


overAlpha = overAlpha ./ max(overAlpha)% - min(overAlpha));
overN2PC =  gsmooth(overN2PC,20);
overN2PC =  overN2PC ./ max(overN2PC)% - min(overN2PC)),20);

overToward = overToward ./ max(overToward)% - min(overToward));
overShift = overShift ./ max(overShift)% - min(overShift));
figure
plot(overAlpha) 
hold on
plot(overN2PC)
plot(overToward)
plot(overShift)
xlim([0 1000])
legend({'alpha', 'N2PC', 'Toward', 'ShiftRate'})

%% plot correlation 
figure('Name',['correlation matrix'],'NumberTitle','off', 'Position',[100 100 1500 1200])

subplot(4,4,1)

cfg =[];
cfg.dataA = shiftData;
cfg.dataB = shiftData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1])
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% shift, gaze, n2pc, alpha
subplot(4,4,2)

cfg =[];
cfg.dataA = shiftData;
cfg.dataB = gazeData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])

subplot(4,4,5)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% 
subplot(4,4,3)

cfg =[];
cfg.dataA = shiftData;
cfg.dataB = N2pcData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
subplot(4,4,9)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%%
%% 
subplot(4,4,4)

cfg =[];
cfg.dataA = shiftData;
cfg.dataB = alphaSupData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])

subplot(4,4,13)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% 
subplot(4,4,6)

cfg =[];
cfg.dataA = gazeData;
cfg.dataB = gazeData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% 
%% 
subplot(4,4,7)

cfg =[];
cfg.dataA = gazeData;
cfg.dataB = N2pcData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
subplot(4,4,10)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%%
subplot(4,4,8)

cfg =[];
cfg.dataA = gazeData;
cfg.dataB = alphaSupData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
subplot(4,4,14)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% 
subplot(4,4,11)

cfg =[];
cfg.dataA = N2pcData;
cfg.dataB = N2pcData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
%% 
subplot(4,4,16)

cfg =[];
cfg.dataA = alphaSupData;
cfg.dataB = alphaSupData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])

%%
subplot(4,4,12)

cfg =[];
cfg.dataA = N2pcData;
cfg.dataB = alphaSupData;
corMat = crossCorr(cfg);

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat,50,'linecolor','none');
colorbar
colormap((cmap))
caxis([-1 1]) 
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])

subplot(4,4,15)

cmap = brewermap([],'*RdBu');
[C,h] = contourf([0:1:1000],[0:1:1000], corMat',50,'linecolor','none');
colorbar
colormap((cmap))
set(gca,'xtick',[],'xticklabel',[],'ytick',[],'yticklabel',[])
caxis([-1 1]) 