function [resp_time_index, clearedData] = removeRTOutlier(data, aboveLine, outlierThresholdRT)
if aboveLine ~= 0
    data_noAbove = data(data < aboveLine);
else
    data_noAbove = data;
end

SD  = std(data_noAbove);
max = outlierThresholdRT *SD + nanmean(data);
min = -outlierThresholdRT *SD + nanmean(data);
resp_time_index = (data < max) & (data > min) & (data < aboveLine);
clearedData = data(resp_time_index);
        
  
end