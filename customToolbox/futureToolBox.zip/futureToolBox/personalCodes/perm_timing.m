function [data_out] = perm_timing(cfg)

% example:
% parent_folder = '/Volumes/LaCie/EEG_data/ReAnalysisFreek/EEG_eye_probe/';
% write_dir_eeg = creatDir([parent_folder 'eeg_results']);
% load([write_dir_eeg '/group_results/GA_hiPre_alpha_earlyVslate_thre3.mat']);
%
% cfg = [];
% cfg.data_cond1=squeeze(mean(GA_struct.power(:,1,:, :),3)); subj * time
% cfg.data_cond2=squeeze(mean(GA_struct.power(:,2,:, :),3)); subj * time
% cfg.time = GA_struct.time .*1000;
% cfg.time_i = [0 1000];
% [out_results]=perm_timing(cfg);
% Baiwei & Freek (2021), at vu

half_point = 0.5;
num_perm = 10000;

v2struct(cfg);

%%
colors = [237 152 121; 173,216,161; 162 209 216];
colors_line = [204 63 50; 85 161 92; 50 120 201];

% colors = [249 222 223; 210,237,225; 210 237 242];
% colors_line = [233 101 104; 76 169 108; 76 170 192];
colors = colors/256;
colors_line = colors_line/256;
%% restrict data range
tsel = time >= time_i(1) & time <= time_i(2);
time = time(tsel);
data_cond1 = data_cond1(:,tsel);
data_cond2 = data_cond2(:,tsel);

%% find minimum & half-times of minimum

% minimum
[a1,b1] = min(squeeze(mean(data_cond1)));
[a2,b2] = min(squeeze(mean(data_cond2)));
mintime1 = time(b1); 
mintime2 = time(b2); 
mintimedif = (mintime2-mintime1);
[mintime1, mintime2, mintimedif]

minval1 = a1;
minval2 = a2;

% find times to scan, now that we know where the peak is
time2scan1 = time <= mintime1; % find point between beginning of the window and the identified peak
timeScanned1 = time(time2scan1); % the actual valyes of the time that we will scan
time2scan2 = time <= mintime2;
timeScanned2 = time(time2scan2);

% get half times
propOfPeak = half_point;
[a1,b1] = min(abs(    mean(data_cond1(:,time2scan1)) - minval1*propOfPeak )); 
[a2,b2] = min(abs(    mean(data_cond2(:,time2scan2)) - minval2*propOfPeak )); 
halftime1 = timeScanned1(b1);
halftime2 = timeScanned2(b2);

haldtimedif = halftime2-halftime1;
[halftime1, halftime2, haldtimedif]

%% plot raw data
figure('position', [100, 100, 1200, 300], 'color', [1 1 1]); 
subplot(1,3,1)
title('raw data');
mplot1 = lineErr_plot(time, data_cond1, colors_line(1,:), 'ci');
mplot2 = lineErr_plot(time, data_cond2, colors_line(3,:), 'ci');
ax = gca;
plot([mintime1 mintime1], ax.YLim, '--r')
plot([mintime2 mintime2], ax.YLim, '--b')
plot([halftime1 halftime1], ax.YLim, '--r')
plot([halftime2 halftime2], ax.YLim, '--b')
%% permutations
npp = size(data_cond1,1);

for permutation = 1:num_perm
    infoDisp(['getting latency difference in permutation ', num2str(permutation) '/' num2str(num_perm)], 'loop',permutation, num_perm);
    
    for pp = 1:npp
        if round(rand) == 1 % randomly flip cond 1 and 2 for some participants
            d1(pp,:) = data_cond2(pp,:);
            d2(pp,:) = data_cond1(pp,:);
        else
            d1(pp,:) = data_cond1(pp,:);
            d2(pp,:) = data_cond2(pp,:);
        end
    end
    
    [a1,b1] = min(squeeze(mean(d1)));
    [a2,b2] = min(squeeze(mean(d2)));
    mintime1x = time(b1);
    mintime2x = time(b2);
    mintimedifx(permutation) = (mintime2x-mintime1x); 
    
    % also for halfway time
    minval1x = a1;
    minval2x = a2;
    
    time2scan1 = time <= mintime1x; % find point between beginning of the window and the identified peak
    timeScanned1 = time(time2scan1); % the actual valyes of the time that we will scan
    time2scan2 = time <= mintime2x;
    timeScanned2 = time(time2scan2);

    [a1,b1] = min(abs(    mean(d1(:,time2scan1)) - minval1x*propOfPeak ));
    [a2,b2] = min(abs(    mean(d2(:,time2scan2)) - minval2x*propOfPeak ));
    halftime1x = timeScanned1(b1);
    halftime2x = timeScanned2(b2);
    
    haldtimedifx(permutation) = halftime2x-halftime1x;
    
end

%% plot
subplot(1,3,2); title('minimum time dif'); hold on;
h1 = histogram(mintimedifx, 50,'Normalization','probability'); hold on; 
h1.FaceColor = colors(1,:);
h1.EdgeColor = colors(1,:);
ax = gca;
plot([mintimedif, mintimedif], ax.YLim, '--k', 'Linewidth', 2);
ylabel('Prob.');
set(gca, 'FontSize', 20,'Fontname','Arial', 'LineWidth', 1.2,'TickDir','out');

subplot(1,3,3);  title('half way time dif'); hold on;
h2 = histogram(haldtimedifx, 50,'Normalization','probability'); hold on; 
h2.FaceColor = colors(3,:);
h2.EdgeColor = colors(3,:);
ax = gca;
plot([haldtimedif, haldtimedif], ax.YLim, '--k', 'Linewidth', 2);
ylabel('Prob.');
set(gca, 'FontSize', 20,'Fontname','Arial', 'LineWidth', 1.2,'TickDir','out');

%%
p_halftime = mean(haldtimedifx >= haldtimedif)
p_mintime = mean(mintimedifx >= mintimedif)


data_out.p_mintime =p_mintime;
data_out.p_halftime =p_halftime;
data_out.mintime1= mintime1;
data_out.mintime2=mintime2;
data_out.halftime1=halftime1;
data_out.halftime2=halftime2;
data_out.half_point =half_point;
data_out.time_i= time_i;
end