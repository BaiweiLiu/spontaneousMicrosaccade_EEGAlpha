%% Analysis script behavioral pilot 

%% It's always good to start with a clean sheet
clear, close all, warning('off','all')

%% Set directions

scripts_folder = '/Users/bwliu/Library/Mobile Documents/com~apple~CloudDocs/Projects/PrepareWM4Action/Prepare_multiple_task/Storing&interference/Exp1_Eyetracker/analysisScripts';
parent_folder = '/Users/bwliu/Library/Mobile Documents/com~apple~CloudDocs/Projects/PrepareWM4Action/Prepare_multiple_task/Storing&interference/Exp1_Eyetracker/data';
package_folder = '/Users/baiweil/Documents/MATLAB';
addpath(package_folder,'-begin');addpath(scripts_folder,'-begin');

read_dir = [parent_folder filesep 'epochedEye.mat']; 
load(read_dir)
%%
for i=1:size(rawData,1)
    rawDataCell{i,1}= rawData(i,1:2501);
    y = rawDataCell;
end
test_loc ={};
subjs =[];
probe_cat = {};
cond = {};
subjID = {'01' '02' '03' '04' '05' '06' '07' '08' '09' '10' '11' '12' '13' '14' '15' '16' '17' '18' '19' '20'};
for i=1:size(locINDs, 1)
    if strfind(locINDs(i,:), 'left') 
        str = 'left';
    elseif strfind(locINDs(i,:), 'right')
        str = 'right';
    elseif strfind(probINDs(i,:), 'recall') &  strfind(encodings(i,:), '1')
        str = 'left';
    elseif strfind(probINDs(i,:), 'recall') &  strfind(encodings(i,:), '2')
        str = 'right';
    elseif strfind(probINDs(i,:), 'search') &  strfind(encodings(i,:), '1')
        str='right';
    elseif strfind(probINDs(i,:), 'search') &  strfind(encodings(i,:), '2')
        str='left';
    end
    
    if strfind(probINDs(i,:), 'recall')
        prob = 'recall';
    elseif strfind(probINDs(i,:), 'search')
        prob = 'search';
    end
    

    for sID = 1:length(subjID)
        if strfind(subj(i,:), subjID{sID})
            subjstr = str2num(subjID{sID});
        end
    end
    
    if strfind(conds(i,:),'pure')
        condstr = 'pure';
    elseif strfind(conds(i,:),'mix')
        condstr = 'mix';
    elseif strfind(conds(i,:),'neutral')
        condstr = 'neutral';
    end
    test_loc{i,1}= str;
    subjs(i,1)=subjstr;
    probe_cat{i,1} = prob;
    cond{i,1} = condstr;
end
%%
clear g
x=linspace(-500,2000,2501);
g(1,1)=gramm('x',x,'y',y, 'color',test_loc, 'subset', subjs ~= 9 );
g(1,1).stat_summary();
g(1,1).facet_grid(cond,probe_cat);
g(1,1).axe_property('YLim',[800 880],'YTick', [800:10:880]);
figure('Position',[100 100 800 1200]);
g(1,1).set_names('column','Probe Task','row','Cond','x','Time (0 = probe onset)','y','Gaze position on x axis (from left to right)', 'color','# location of tested items');
g(1,1).set_title('PP02');
g.draw();

%%
clear g
x=linspace(-500,2000,2501);
g(1,1)=gramm('x',x,'y',y, 'color',test_loc,'subset', subjs < 4 );
g(1,1).stat_summary();
g(1,1).facet_grid(subjs,probe_cat,'scale','independent');
%g(1,1).axe_property('YLim',[820 900],'YTick', [800:10:900]);
g(1,1).set_title('PP03');
g(1,1).set_names('column','Probe Task','row','Encoding Condition','x','Time (0 = probe onset)','y','Gaze position on x axis (from left to right)', 'color','# location of tested items');
figure('Position',[100 100 800 1200]);
g.draw();
%% mix
for p = {'recall' 'search'}
    for c = {'pure' 'mix' 'neutral'}
        for s =[4 5 6 7 8 9 10]
            left = rawData(strcmp(probe_cat,p) & strcmp(cond,c) & strcmp(test_loc,'left') & subjs ==s,:);
            right = rawData(strcmp(probe_cat,p) & strcmp(cond,c) & strcmp(test_loc,'right') & subjs ==s,:);
            left = left(:, 1:1301); right = right(:, 1:1301);
            recall_pure2= mean(right - left,1);
            eval([ p{1} '_' c{1} num2str(s) '= mean(right,1) - mean(left,1);'])
        end
    end
end
recall_pure = mean([recall_pure4;recall_pure5;recall_pure6;recall_pure7;recall_pure8;recall_pure9;recall_pure10]);
search_pure = mean([search_pure4;search_pure5;search_pure6;search_pure7;search_pure8;search_pure9;search_pure10]);
recall_mix = mean([recall_mix4;recall_mix5;recall_mix6;recall_mix7;recall_mix8;recall_mix9;recall_mix10]);
search_mix = mean([search_mix4;search_mix5;search_mix6;search_mix7;search_mix8;search_mix9;search_mix10]);
recall_neutral = mean([recall_neutral4;recall_neutral5;recall_neutral6;recall_neutral7;recall_neutral8;recall_neutral9;recall_neutral10]);
search_neutral = mean([search_neutral4;search_neutral5;search_neutral6;search_neutral7;search_neutral8;search_neutral9;search_neutral10]);
%%
y = {recall_pure'; search_pure'; recall_mix'; search_mix';recall_neutral'; search_neutral'};
probe = {'recall' 'search' 'recall' 'search' 'recall' 'search'};
cond = {'pure' 'pure' 'mix' 'mix' 'neutral' 'neutral'};
clear g
x=linspace(-500,800,1301);
g(1,1)=gramm('x',x,'y',y, 'color',cond);
g(1,1).geom_line();
g(1,1).facet_grid([],probe);
g(1,1).set_names('column','Probe Task','x','Time (0 = probe onset)','y','Towardness (right minus left)', 'color','# Encoding condition');
figure('Position',[100 100 800 500]);
g.draw();
