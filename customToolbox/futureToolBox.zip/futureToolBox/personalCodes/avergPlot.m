function avergPlot(cfg, y)
% baiwei, vu, 2021

%% setting for plot

colors = [237 152 121; 173,216,161; 162 209 216];
colors_line = [204 63 50; 85 161 92; 50 120 201];
colors = colors/256;
colors_line = colors_line/256;
v2struct(cfg) % label, yli
%% setting for plot

%% 

if size(y,2) == 3
    x = [1 4 7];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.15,'spread',0.8...
            ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20);
    hold off 
    set(gca, 'FontSize', 20,'Fontname','Arial');
    box off  
    set(gca,'XColor','w') 
    set(gca,'xtick',[]);
    ylim(yli)
    hold on 
    
    yl= ylim;
    [~,p_value,~,t_value] = ttest(y(:,1), y(:,2));
    p_value = roundn(p_value,-3);
    t_val = abs(t_value.tstat);
    t_val = roundn(t_val,-3);
    txt = [label{1} ' vs ' label{2} ':'];
    text(1,yl(1)-(yl(2)-yl(1))/20*2,txt,'FontSize',18)
    txt = ['p = ' num2str(p_value)];txt = ['p = ' num2str(p_value)]; if p_value < 0.001;  txt = 'p < 0.001'; end
    text(1,yl(1)-(yl(2)-yl(1))/20*5,txt,'FontSize',18)
    txt = ['t = ' num2str(t_val)];
    text(1,yl(1)-(yl(2)-yl(1))/20*8,txt,'FontSize',18)
    
    %%
    yl= ylim;
    [~,p_value,~,t_value] = ttest(y(:,2), y(:,3));
    p_value = roundn(p_value,-3);
    t_val = abs(t_value.tstat);
    t_val = roundn(t_val,-3);
    
    txt = [label{2} ' vs ' label{3} ':'];
    text(1,yl(1)-(yl(2)-yl(1))/20*11,txt,'FontSize',18)
    txt = ['p = ' num2str(p_value)]; if p_value < 0.001;  txt = 'p < 0.001'; end
    text(1,yl(1)-(yl(2)-yl(1))/20*14,txt,'FontSize',18)
    txt = ['t = ' num2str(t_val)];
    text(1,yl(1)-(yl(2)-yl(1))/20*17,txt,'FontSize',18)
    
    %%
     %%
    yl= ylim;
    [~,p_value,~,t_value] = ttest(y(:,1), y(:,3));
    p_value = roundn(p_value,-3);
    t_val = abs(t_value.tstat);
    t_val = roundn(t_val,-3);
    
    txt = [label{1} ' vs ' label{3} ':'];
    text(1,yl(1)-(yl(2)-yl(1))/20*20,txt,'FontSize',18)
    txt = ['p = ' num2str(p_value)]; if p_value < 0.001;  txt = 'p < 0.001'; end
    text(1,yl(1)-(yl(2)-yl(1))/20*23,txt,'FontSize',18)
    txt = ['t = ' num2str(t_val)];
    text(1,yl(1)-(yl(2)-yl(1))/20*26,txt,'FontSize',18)
    
    %%
    lenChear1 =  length(label{1})+length(label{2})+length(label{3})+2;
    lenChear2 =  length(label{2})+length(label{3})+1;
    lenChear3 =  length(label{3})-1;
    
    text(7.0 - 0.32*lenChear1,yl(2)+ 0.8*(yl(2)-yl(1))/20*3,label{1},'FontSize',20,'Color', colors_line(1,:))
    text(7.0 - 0.32*lenChear2,yl(2)+ 0.8*(yl(2)-yl(1))/20*3,label{2},'FontSize',20,'Color', colors_line(2,:))
    text(7.0 - 0.32*lenChear3,yl(2)+ 0.8*(yl(2)-yl(1))/20*3,label{3},'FontSize',20,'Color', colors_line(3,:))

elseif size(y,2) == 2
    
     x = [1 4];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.15,'spread',0.8...
            ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20);
    hold off 
    set(gca, 'FontSize', 20,'Fontname','Arial');
    box off  
    set(gca,'XColor','w') 
    set(gca,'xtick',[]);
    ylim(yli)
    hold on 
    
    yl= ylim;
    [~,p_value,~,t_value] = ttest(y(:,1), y(:,2));
    p_value = roundn(p_value,-3);
    t_val = abs(t_value.tstat);
    t_val = roundn(t_val,-3);
    txt = [label{1} ' vs ' label{2} ':'];
    text(1,yl(1)-(yl(2)-yl(1))/20*2,txt,'FontSize',18)
    txt = ['p = ' num2str(p_value)];txt = ['p = ' num2str(p_value)]; if p_value < 0.001;  txt = 'p < 0.001'; end
    text(1,yl(1)-(yl(2)-yl(1))/20*5,txt,'FontSize',18)
    txt = ['t = ' num2str(t_val)];
    text(1,yl(1)-(yl(2)-yl(1))/20*8,txt,'FontSize',18)
    %%
    lenChear1 =  length(label{1})+length(label{2})+1;
    lenChear2 =  length(label{2});
    
    text(5.0 - 0.16*lenChear1,yl(2)+ 0.8*(yl(2)-yl(1))/20*3,label{1},'FontSize',20,'Color', colors_line(1,:))
    text(5.0 - 0.16*lenChear2,yl(2)+ 0.8*(yl(2)-yl(1))/20*3,label{2},'FontSize',20,'Color', colors_line(2,:))
end

end