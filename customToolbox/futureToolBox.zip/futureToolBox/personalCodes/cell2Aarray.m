function [out_put] = cell2Aarray(c)
    for cInd = 1:length(c)
        arr(cInd,:) = c{cInd};
    end
    out_put = arr;
end