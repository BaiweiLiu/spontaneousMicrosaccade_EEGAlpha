%% Analysis script behavioral pilot 

%% It's always good to start with a clean sheet
clear, close all, warning('off','all')

%% Set directions
parent_folder = '/Users/baiweil/Library/Mobile Documents/com~apple~CloudDocs/Projects/PrepareWM4Action/Prepare_multiple_task/Storing&interference/Exp1_Eyetracker';
scripts_folder = [parent_folder filesep 'analysisScripts'];
package_folder = '/Users/baiweil/Documents/MATLAB';
addpath(package_folder,'-begin');addpath(scripts_folder,'-begin');

read_dir = [parent_folder filesep 'data/raw_data_search']; 
write_dir = [parent_folder filesep 'data/write_data']; 

if ~exist(write_dir,'dir')
    mkdir(write_dir)
end

%% parameter
Above_reject =3000;
outlierThresholdRT = 2.5; % z-score based
condition = {'pure', 'mix', 'neutral'};
matchCond = {'match', 'nonMatch'};

cd(read_dir)
sublist=dir('*.csv');
sublist={sublist.name}; 
%% Extract and clear the subjects data

%% Trial based process
for subjInd = 1:length(sublist)  
    rawTable = readtable(sublist{subjInd},'Delimiter', '\t'); %Load the csv file
    data_test = rawTable(strcmp(rawTable.prac,'formal'),:);
    data_formal = str2listInTable(data_test, 'oris_search');
    search_cohere = {};
    locs_search = {};
    target_turn ={};
    conds_match ={};
    encod_search_cohere ={};
    for linedInd = 1:height(data_formal)    
        loc_search = find(data_formal.oris_search{linedInd} == data_formal.test_ori(linedInd));
        if loc_search <4
            loc = 'left';
        else
            loc = 'right';
        end 

        if data_formal.test_ori(linedInd) <0
            ori_turn = 'left';
        elseif data_formal.test_ori(linedInd) >0
            ori_turn = 'right';
        end

        if strcmp(loc, ori_turn)
            ori_loc_search = 'same';
        else
            ori_loc_search = 'diff';
        end
        
        if strcmp(data_formal.blockCond(linedInd), 'mix')
            if data_formal.display(linedInd) == 1
                if strcmp(data_formal.categoryOfTest,'recall')
                    data_formal.combinationOrder(linedInd) = {'left'};
                elseif strcmp(data_formal.categoryOfTest,'search')
                    data_formal.combinationOrder(linedInd) = {'right'};
                end
                
            elseif data_formal.display(linedInd) == 2
                if strcmp(data_formal.categoryOfTest,'recall')
                    data_formal.combinationOrder(linedInd) = {'right'};
                elseif strcmp(data_formal.categoryOfTest,'search')
                    data_formal.combinationOrder(linedInd) = {'left'};                
                end
            end
        end
        
        if strcmp(loc, data_formal.combinationOrder(linedInd))
            loc_encod_search = 'same';
        else
            loc_encod_search = 'diff';
        end

        if data_formal.ori_distractor(linedInd) == data_formal.ori_nonTarget(linedInd)
            cond_match = 'match';
        else
            cond_match = 'nonMatch';
        end
        
        search_cohere{linedInd} = ori_loc_search;
        locs_search{linedInd} = loc;
        target_turn{linedInd} = ori_turn;
        conds_match{linedInd} = cond_match;
        encod_search_cohere{linedInd} = loc_encod_search;
    end

    data_formal.search_cohere = search_cohere'; 

    data_formal.Search_loc = locs_search';

    data_formal.ori_turn = target_turn';

    data_formal.cond_match = conds_match';
    
    data_formal.encod_search_cohere = encod_search_cohere';
    
    if iscell(data_formal.respTime)
        data_formal = str2listInTable(data_formal, 'respTime');
        data_formal.RT = data_formal.respTime - data_formal.startTime;
    else
        data_formal.RT = data_formal.respTime - data_formal.startTime;
    end

    sum_T{subjInd} = data_formal;
end

%% Cond based process
for subjInd = 1:length(sublist)  
    subj_data = sum_T{subjInd};
    for condId = 1:length(condition)
        for matchID = 1:length(matchCond)
            cond_data = subj_data(strcmp(subj_data.blockCond,condition{condId}) & strcmp(subj_data.cond_match,matchCond{matchID}),:);
            
            [match_index, cleared_RT] = removeRTOutlier(cond_data.RT, Above_reject, outlierThresholdRT);
            cond_data(match_index == 0,:) = [];
            sum_T_condL{subjInd,condId,matchID} = cond_data;
        end
    end
end

%% sum Data and convert data to struct
Data = reshape(sum_T_condL, 1, (length(sublist))*length(condition)*length(matchCond));
for dataID = 1:length(Data)
    if dataID == 1
        sumAfter_table = Data{dataID};
    end
    sumAfter_table = [sumAfter_table; Data{dataID}];
end
Cleared_Data = table2struct(sumAfter_table,'ToScalar',true);

%% start plot 

colors = [173,216,161; 237 152 121; 96 182 196];
colors_line = [85 161 92; 204 63 50; 48 111 183];
colors = colors/256;
colors_line = colors_line/256;

%%
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','cond_match'}, 'mean', 'DataVars','RT');
figure('Position',[100 100 1800 400])
subplot(1,4,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_match = data.mean_RT(strcmp(data.cond_match,'match'),:);
    data_nonMatch = data.mean_RT(strcmp(data.cond_match,'nonMatch'),:);
    y = [data_nonMatch, data_match];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.5,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20);
end

hold off
ylabel('RT (ms)') 
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%
subplot(1,4,2);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score'}, 'mean', 'DataVars','RT');
y = [];
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    if condId ==1
    y = data.mean_RT;
    else
    y = [y data.mean_RT];
    end
end

x = [10 20 30];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.5,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

% ori loc-search coherence
subplot(1,4,3);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','search_cohere'}, 'mean', 'DataVars','RT');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_same = data.mean_RT(strcmp(data.search_cohere,'same'),:);
    data_diff = data.mean_RT(strcmp(data.search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '>');
end
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

% loc endcoing - search coherence
subplot(1,4,4);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','encod_search_cohere'}, 'mean', 'DataVars','RT');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_same = data.mean_RT(strcmp(data.encod_search_cohere,'same'),:);
    data_diff = data.mean_RT(strcmp(data.encod_search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '<');
end
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%% ACC
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','score');

figure('Position',[100 100 1800 300])
subplot(1,4,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    data_match = data.mean_score(strcmp(data.cond_match,'match'),:);
    data_nonMatch = data.mean_score(strcmp(data.cond_match,'nonMatch'),:);
    y = [data_nonMatch, data_match];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20);
end
hold off
ylabel('ACC (percent)') 
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

%
subplot(1,4,2);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','score');
y = [];
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    if condId ==1
    y = data.mean_score;
    else
    y = [y data.mean_score];
    end
end
x = [10 20 30];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

%
subplot(1,4,3);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','search_cohere'}, 'mean', 'DataVars','score');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    data_same = data.mean_score(strcmp(data.search_cohere,'same'),:);
    data_diff = data.mean_score(strcmp(data.search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '>');
end
hold off
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%
subplot(1,4,4);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','encod_search_cohere'}, 'mean', 'DataVars','score');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    data_same = data.mean_score(strcmp(data.encod_search_cohere,'same'),:);
    data_diff = data.mean_score(strcmp(data.encod_search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '<');
end
hold off
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%% Cost - RT
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score'}, 'mean', 'DataVars','RT');
y = [];
figure('Position',[100 100 900 300])
subplot(1,2,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    if condId ==1
    y = data.mean_RT;
    else
    y = [y data.mean_RT];
    end
end
y = y - y(:,3);
y = y(:,[1 2]);
x = [10 20]; 
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
ylabel('RT (ms)') 
%set(gca,'ylim',[-1000 500],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 30]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

% Cost - ACC
subplot(1,2,2);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','score');
y = [];
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    if condId ==1
    y = data.mean_score;
    else
    y = [y data.mean_score];
    end
end
y = y - y(:,3);
y = y(:,[1 2]);
x = [10 20]; 

    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
ylabel('ACC (percent)') 
%set(gca,'ylim',[0 20],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

%% Sum plot without individual resutls
clear g
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','RT');

figure('Position',[100 100 1500 600]);
g(1,1)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_RT, 'color',grouped_data.cond_match);
g(1,1).axe_property('YLim',[1000 2000],'YTick', [1000:200:2000]);
g(1,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

g(1,2)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_RT);
g(1,2).axe_property('YLim',[1000 2000],'YTick', [1000:200:2000]);
g(1,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','search_cohere'}, 'mean', 'DataVars','RT');
g(1,3)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_RT,'color',grouped_data.search_cohere);
g(1,3).axe_property('YLim',[1000 2000],'YTick', [1000:200:2000]);
g(1,3).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','encod_search_cohere'}, 'mean', 'DataVars','RT');
g(1,4)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_RT,'color',grouped_data.encod_search_cohere);
g(1,4).axe_property('YLim',[1000 2000],'YTick', [1000:200:2000]);
g(1,4).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','score');

g(2,1)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_score, 'color',grouped_data.cond_match);
g(2,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
g(2,1).axe_property('YLim',[50 100],'YTick', [40:10:100]);

g(2,2)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_score);
g(2,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
g(2,2).axe_property('YLim',[50 100],'YTick', [40:10:100]);


grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','search_cohere'}, 'mean', 'DataVars','score');
g(2,3)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_score,'color',grouped_data.search_cohere);
g(2,3).axe_property('YLim',[50 100],'YTick', [40:10:100]);
g(2,3).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','encod_search_cohere'}, 'mean', 'DataVars','score');
g(2,4)=gramm('x',grouped_data.blockCond,'y',grouped_data.mean_score,'color',grouped_data.encod_search_cohere);
g(2,4).axe_property('YLim',[50 100],'YTick', [40:10:100]);
g(2,4).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

g.set_order_options('x',{'pure', 'mix','neutral'})
g(1,:).set_names('column','pp','x','Encoding condition','y','Reaction time (ms)', 'color','# match condition');
g(2,:).set_names('column','pp','x','Encoding condition','y','ACC', 'color','# match condition');
g(:,2).set_color_options('map','brewer2')
g(:,3:4).set_color_options('map','d3_10')
g(:,2:4).axe_property('YLabel',[]);
g(1,:).axe_property('XLabel',[]);
g.set_layout_options('legend',false);
g.set_text_options('base_size',15,'label_scaling',1.4)
g.draw()

%% cost plot  without individual resutls
clear g
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','RT');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_RT' 'GroupCount'},'cond_match');
U.matchCost = U.mean_RT_match - U.mean_RT_nonMatch;
% grouped_data(strcmp(grouped_data.blockCond,'neutral') &
figure('Position',[100 100 1500 600]);

g(1,1)=gramm('x',U.blockCond,'y',U.matchCost);
g(1,1).axe_property('YLim',[-200 100],'YTick', [-200:50:100]);
g(1,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','RT');
U = unstack(grouped_data,{'mean_RT' 'GroupCount'},'blockCond');
U.mean_RT_mix = U.mean_RT_mix - U.mean_RT_neutral;
U.mean_RT_pure = U.mean_RT_pure - U.mean_RT_neutral;
U.mean_RT_neutral = [];
U.Properties.VariableNames{'mean_RT_mix'} = 'mix';
U.Properties.VariableNames{'mean_RT_pure'} = 'pure';
U = stack(U, {'mix', 'pure'});
U.Properties.VariableNames{'mix_pure'} = 'benifit';
U.Properties.VariableNames{'mix_pure_Indicator'} = 'blockCond';

g(1,2)=gramm('x',U.blockCond,'y',U.benifit);
g(1,2).axe_property('YLim',[-200 100],'YTick', [-200:50:100]);
g(1,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','search_cohere'}, 'mean', 'DataVars','RT');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_RT' 'GroupCount'},'search_cohere');
U.cohereCost = U.mean_RT_diff - U.mean_RT_same;

g(1,3)=gramm('x',U.blockCond,'y',U.cohereCost);
g(1,3).axe_property('YLim',[-100 200],'YTick', [-100:50:200]);
g(1,3).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','encod_search_cohere'}, 'mean', 'DataVars','RT');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_RT' 'GroupCount'},'encod_search_cohere');
U.cohereCost = U.mean_RT_diff - U.mean_RT_same;

g(1,4)=gramm('x',U.blockCond,'y',U.cohereCost);
g(1,4).axe_property('YLim',[0 400],'YTick', [-200:50:200]);
g(1,4).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','score');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_score' 'GroupCount'},'cond_match');
U.matchCost = U.mean_score_match - U.mean_score_nonMatch;

g(2,1)=gramm('x',U.blockCond,'y',U.matchCost);
g(2,1).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
g(2,1).axe_property('YLim',[-20 5],'YTick', [-20:5:5]);

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','score');

U = unstack(grouped_data,{'mean_score' 'GroupCount'},'blockCond');
U.mean_score_mix = U.mean_score_mix - U.mean_score_neutral;
U.mean_score_pure = U.mean_score_pure - U.mean_score_neutral;
U.mean_score_neutral = [];
U.Properties.VariableNames{'mean_score_mix'} = 'mix';
U.Properties.VariableNames{'mean_score_pure'} = 'pure';
U = stack(U, {'mix', 'pure'});
U.Properties.VariableNames{'mix_pure'} = 'benifit';
U.Properties.VariableNames{'mix_pure_Indicator'} = 'blockCond';

g(2,2)=gramm('x',U.blockCond,'y',U.benifit);
g(2,2).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});
g(2,2).axe_property('YLim',[-10 10],'YTick', [-10:5:10]);

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','search_cohere'}, 'mean', 'DataVars','score');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_score' 'GroupCount'},'search_cohere');
U.cohereCost = U.mean_score_diff - U.mean_score_same;

g(2,3)=gramm('x',U.blockCond,'y',U.cohereCost);
g(2,3).axe_property('YLim',[-20 0],'YTick', [-20:5:0]);
g(2,3).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','encod_search_cohere'}, 'mean', 'DataVars','score');

grouped_data.Properties.RowNames ={};
U = unstack(grouped_data,{'mean_score' 'GroupCount'},'encod_search_cohere');
U.cohereCost = U.mean_score_diff - U.mean_score_same;

g(2,4)=gramm('x',U.blockCond,'y',U.cohereCost);
g(2,4).axe_property('YLim',[-50 0],'YTick', [-50:10:0]);
g(2,4).stat_summary('type','ci','geom',{'bar' 'black_errorbar'});

g.set_order_options('x',{'pure', 'mix','neutral'})
g(1,:).set_names('column','pp','x','Encoding condition','y','Reaction time (ms)', 'color','# match condition');
g(2,:).set_names('column','pp','x','Encoding condition','y','ACC', 'color','# match condition');
g(:,2).set_color_options('map','brewer2')
g(:,3:4).set_color_options('map','d3_10')
g(:,2:4).axe_property('YLabel',[]);
g(1,:).axe_property('XLabel',[]);
g.set_layout_options('legend',false);
g.set_text_options('base_size',15,'label_scaling',1.4)
g.draw()
