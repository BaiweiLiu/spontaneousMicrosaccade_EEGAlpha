function h = freeksGazeMap(x,y,centers,fig)

h = hist3([y(:), x(:)],'Ctrs', centers); % for some reason have to put y/x in there...
h = (h/sum(h(:))) * 100; % to get to proportion / percentage
% h(h==0) = nan;

if fig
imagesc(h);
set(gca, 'YDir','normal', ...
    'XTick', [find(centers{1}==-100), find(centers{1}==0), find(centers{1}==100)], 'XTickLabel', {'-100','0','100'}, ...
    'YTick', [find(centers{2}==-100), find(centers{2}==0), find(centers{2}==100)], 'YTickLabel', {'-100','0','100'}) 
colormap('hot'); caxis([0 max(max(h))]);

max(max(h))
end
%% smooth?
% data = [x(:), y(:)]'
% [X,Y] = meshgrid(1:size(data,2), 1:size(data,1));
% 
% %// Define a finer grid of points
% [X2,Y2] = meshgrid(1:0.1:size(data,2), 1:0.1:size(data,1));
% 
% %// Interpolate the data and show the output
% outData = interp2(X, Y, data, X2, Y2, 'linear');
% imagesc(outData);
% 
% %// Cosmetic changes for the axes
% set(gca, 'XTick', linspace(1,size(X2,2),size(X,2))); 
% set(gca, 'YTick', linspace(1,size(X2,1),size(X,1)));
% set(gca, 'XTickLabel', 1:size(X,2));
% set(gca, 'YTickLabel', 1:size(X,1));