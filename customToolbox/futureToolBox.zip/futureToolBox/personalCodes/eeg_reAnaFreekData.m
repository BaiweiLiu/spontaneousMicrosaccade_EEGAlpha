%% Analysis script for EEG data 

%% It's always good to start with a clean sheet
clc, clear, close all, warning('off','all')

%% set project name
projectname = 'Re analysis Freek data';

%% Set directions
parent_folder = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/';

cfg= [];
cfg.package_folder = '/Users/baiweil/Documents/MATLAB_pacakges/';
cfg.scripts_path = [parent_folder  'Scripts'];
cfg.eyeLab_path = [parent_folder 'eyeLab'];
cfg.eegFuture_path = [parent_folder 'eegFuture'];
cd(cfg.eyeLab_path);
eyeLab_setup(cfg);

read_dir1 = [parent_folder  'data' filesep 'EEG_raw/session1'];
read_dir2 = [parent_folder  'data' filesep 'EEG_raw/session2'];

write_dir = creatDir([parent_folder 'eegResults']);
write_dir_tf = creatDir([write_dir filesep 'data_tf']);
write_dir_tf_noLap = creatDir([write_dir filesep 'data_tf_noLap']);
write_dir_MVPA = creatDir([write_dir filesep 'results_MVPA']);
write_dir_epoch = creatDir([write_dir filesep 'data_epoch']);

%% channel and freqs selection
[channels,freqs] = eegFuture_selection();

%% triggers
trigs.left_en = [21 22];
trigs.right_en= [23 24];
trigs.left_hand = [21 23];
trigs.right_hand = [22 24];
trigs.epoch = [21:24];

%% epoch time 
epoch_time = [-1 2];

%% clean data
subList1 = get_subFiles(read_dir1,'*.cnt');
subList2 = get_subFiles(read_dir2,'*.cnt');


% run through subj loop
for subjInd = 1:length(subList1)
    
    %% subject specific information
    disp([' ']);  disp([' ']);      disp(['getting data from ', subList1{subjInd}(71:73), ' and ', subList2{subjInd}(71:74) ]);    disp([' ']);  disp([' ']);
    
    %% step 1 read in data in all at once and re-reference (for .cnt data works better to first read in all data, and later epoch it)
    cfg = [];
    cfg.dataset = subList1{subjInd};
    cfg.dataformat = 'ns_cnt32';
    cfg.headerformat = 'ns_cnt32';
    cfg.eventformat = 'ns_cnt32';
    cfg.reref = 'yes';
    cfg.implicitref = 'LM'; % left mastoid during recording
    cfg.refchannel = {'LM','RM'};
    cfg.dftfilter = 'yes';
    data1 = ft_preprocessing(cfg);
    
    % load session 2
    cfg.dataset = subList2{subjInd};
    data2 = ft_preprocessing(cfg);
    
    
    %% step 2 segment into trials of interest
    cfg = [];
    cfg.dataset = subList1{subjInd};
    cfg.trialdef.eventtype = 'trigger';
    cfg.trialdef.eventvalue = trigs.epoch;
    cfg.trialdef.prestim = -epoch_time(1);
    cfg.trialdef.poststim = epoch_time(2);
    cfg = ft_definetrial(cfg);
    cfg.trl(:,[1,2]) = cfg.trl(:,[1,2])+24; % to realign to photo-diode measurement: maximal deflection at 24 ms after trigger
    data1 = ft_redefinetrial(cfg, data1);
    
    
    cfg = [];
    cfg.dataset = subList2{subjInd};
    cfg.trialdef.eventtype = 'trigger';
    cfg.trialdef.eventvalue = trigs.epoch;
    cfg.trialdef.prestim = -epoch_time(1);
    cfg.trialdef.poststim = epoch_time(2);
    cfg = ft_definetrial(cfg);
    cfg.trl(:,[1,2]) = cfg.trl(:,[1,2])+24; % to realign to photo-diode measurement: maximal deflection at 24 ms after trigger
    data2 = ft_redefinetrial(cfg, data2);
        
    
    %% fix some noisy channels before appending the sessions
    
    % fix noisy channels in ds1 only
    if ismember(subjInd, 1)
        badchan = ismember(data1.label, {'FC5'});
        replacingchans = ismember(data1.label, {'FC3','FC1'});
        for trl = 1:length(data1.trial)
            data1.trial{trl}(badchan,:) = squeeze(mean(data1.trial{trl}(replacingchans,:)));
        end
    elseif ismember(subjInd, 2)
        badchan = ismember(data1.label, {'C1'});
        replacingchans = ismember(data1.label, {'C3','Cz'});
        for trl = 1:length(data2.trial)
            data1.trial{trl}(badchan,:) = squeeze(mean(data1.trial{trl}(replacingchans,:)));
        end
    end
    
    % fix noisy channels in ds2 only
    if ismember(subjInd, 18)
        badchan = ismember(data2.label, {'F8'});
        replacingchans = ismember(data2.label, {'AF3','F6'});
        for trl = 1:length(data2.trial)
            data2.trial{trl}(badchan,:) = squeeze(mean(data2.trial{trl}(replacingchans,:)));
        end
    end
    
    % fix noisy chan in both ds1 and ds2
    if ismember(subjInd, 25)
        badchan = ismember(data1.label, {'AF8'});
        replacingchans = ismember(data1.label, {'F8','Fp2'});
        for trl = 1:length(data1.trial)
            data1.trial{trl}(badchan,:) = squeeze(mean(data1.trial{trl}(replacingchans,:)));
        end
        for trl = 1:length(data2.trial)
            data2.trial{trl}(badchan,:) = squeeze(mean(data2.trial{trl}(replacingchans,:)));
        end
    end
    
    %% append datasets now  
    data2save = ft_appenddata(cfg, data1, data2);
    
    %% remove irrelevant channels
    cfg = [];
    cfg.channel = {'all','-LM','-RM'};
    data2save = ft_selectdata(cfg, data2save);
    
    %% correct EEG labels so fieltrip understand them properly
    lab2check = {'FP1','FP2','FPz','Cpz'};
    labcorrect = {'Fp1','Fp2','Fpz','CPz'};
    errchan = ismember(data2save.label, lab2check);
    whicherr = ismember(lab2check,data2save.label(errchan));
    data2save.label(errchan) = labcorrect(whicherr);
    data = data2save; clear data2save
    %% save appended data
    save([write_dir_epoch filesep 'pp' subList1{subjInd}(72:73) '.mat'], 'data');
end

%% clean data
cd(write_dir_epoch)
sublist=dir('*.mat');
sublist={sublist.name}; 

% run through subj loop
for subjInd = 1:length(sublist)
    
    cfg = [];
    
    % input and output file
    cfg.epoch_dir = [write_dir_epoch filesep sublist{subjInd}];
    cfg.out_put = write_dir;
    cfg.subj_name = sublist{subjInd}(1:4);
    
    % clean setting
    cfg.ica_here = true; % whether ICA has already been down before
    cfg.plot_out = false; % whether plot results
    cfg.ICA_onlyEEG = false; % whether run ICA including the EOG
    cfg.autoICA = true; % whether remove blink compoents auto 
    cfg.autoICA_co_remove = 0.4; % the correlation value used to remove blink compoents auto 
    cfg.i_channel = [channels.visualL channels.visualR channels.motionL channels.motionR];
    cfg.i_freq = [8 30];
    cfg.do_visualRemove = true; % whether clean the data by visual remove
    
    eegFuture_proprocess(cfg);  
end

%% do a time-frequency analysis
cd('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/Epoch_data')
sublist=dir('*.mat');
sublist={sublist.name}; 

% run through subj loop
for subjInd = 1 :length(sublist) 
    
    %% read data
    cfg.data_set = write_dir;
    cfg.subj_name = sublist{subjInd}(1:4);
    cfg.apply_ica = true;
    cfg.apply_VR = true;    
    cfg.apply_laplacian = false;
    cfg.ICA_onlyEEG = false;
    data = eegFuture_readData(cfg);
    
    %% Do TF analysis
    windowsize = 0.3; % 300 ms sliding time window

    cfg = [];
    cfg.taper = 'hanning'; % default hanning taper again
    cfg.method = 'mtmconvol'; % time-resolved frequency analysis (= short-time fourier transform)
    cfg.foi = [1:1:50]; % frequencies of interest (foi)
    cfg.toi = [data.time{1}(1):0.05:data.time{1}(end)]; % times of interest (i.e. where to centre the time-windows for each Fourier analysis on)
    cfg.t_ftimwin = ones(1, length(cfg.foi))*windowsize; % same window for each frequency.
    cfg.pad = 4; % padding the data to obtains the desired frequency resolution
    cfg.keeptrials = 'yes';
    cfg.output = 'pow'; % straight to power
    data_tfr = ft_freqanalysis(cfg, data); % tfr.powspctrm = 4D (trials, electrodes, frequencies, timepoints => see also "tfr.dimord");
    
    save([write_dir_tf_noLap filesep sublist{subjInd}(1:4) '.mat'], 'data_tfr');
    clear data, data_tfr
    
end

%% group analysis post Event (aw vs. to vs. noMS)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_aw = [postEvent_dir 'event_aw'];
cond_to = [postEvent_dir 'event_to'];
cond_noMS = [postEvent_dir 'event_noMS'];

postEvent = {cond_aw cond_to cond_noMS};

cfg = [];
cfg.input_file = write_dir_tf;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'aw', 'to', 'noMS'};
cfg.write_dir = [write_dir];
cfg.fileName = 'AW_To_noMS_Lap';
GA_data = eegFutureTF_GApostEvent(cfg);

%% indiv plot (aw vs. to vs. noMS)
dim2Name = {'aw', 'to', 'noMS'};
for condInd = 1:length(dim2Name)
    cfg = [];
    cfg.plotType = 'indiv';
    cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_AW_To_noMS_Lap.mat';
    cfg.value = 'contrVSipi';
    cfg.cond2plot = {dim2Name{condInd}};
    cfg.time2plot = [-0.2 1];
    cfg.subFig = true;
    cfg.dim3 = false;
    cfg.limitZ = [-20 20];
    cfg.i_freq = freqs.alphafreq;
    cfg.averagePower = false;

    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);
end
    %cfg.controlCond = 3;
    cfg.cond2plot = {'aw', 'to', 'noMS'};
    cfg.averagePower = true;
    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);
%% sum plot (aw vs. to vs. noMS)
cfg = [];
cfg.cond2plot = {'aw', 'to', 'noMS'}%, 'noMS'};
cfg.i_freq = freqs.alphafreq;
%cfg.controlCond = 1;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_AW_TO_noMS_Lap.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';

cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%% group analysis post Event (early vs. late)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_to_early = [postEvent_dir 'event_to_early'];
cond_to_late = [postEvent_dir 'event_to_late'];

postEvent = {cond_to_early cond_to_late};

cfg = [];
cfg.input_file = write_dir_tf;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'to-early', 'to-late'};
cfg.write_dir = [write_dir];
cfg.fileName = 'early_late_Lap';
GA_data = eegFutureTF_GApostEvent(cfg);

%% indiv plot (early vs. late)
dim2Name = {'to-early', 'to-late'};
for condInd = 1:length(dim2Name)
    cfg = [];
    cfg.plotType = 'indiv';
    cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_early_late_Lap.mat';
    cfg.value = 'contrVSipi';
    cfg.cond2plot = {dim2Name{condInd}};
    cfg.time2plot = [-0.2 1];
    cfg.subFig = true;
    cfg.dim3 = false;
    cfg.limitZ = [-20 20];
    cfg.i_freq = freqs.alphafreq;
    cfg.averagePower = false;

    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);
end

cfg.cond2plot =dim2Name
%cfg.controlCond = 1;
cfg.averagePower = true;
figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
eegFuture_plot(cfg);
%% sum plot (early vs. late)
cfg = [];
cfg.cond2plot = {'to-early', 'to-late'};
cfg.i_freq = freqs.alphafreq;
%cfg.controlCond = 1;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_early_late_Lap.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 900 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';

cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%% group analysis post Event 
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_aw = [postEvent_dir 'event_aw'];
cond_to = [postEvent_dir 'event_to'];
cond_noMS = [postEvent_dir 'event_noMS'];

postEvent = {cond_aw cond_to cond_noMS};

cfg = [];
cfg.input_file = write_dir_tf;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'aw', 'to', 'noMS'};
cfg.write_dir = [write_dir];
cfg.fileName = 'AW_To_noMS_Lap';
GA_data = eegFutureTF_GApostEvent(cfg);

%% indiv plot
dim2Name = {'aw', 'to', 'noMS'};
for condInd = 1:length(dim2Name)
    cfg = [];
    cfg.plotType = 'indiv';
    cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_AW_To_noMS_Lap.mat';
    cfg.value = 'contrVSipi';
    cfg.cond2plot = {dim2Name{condInd}};
    cfg.time2plot = [-0.2 1];
    cfg.subFig = true;
    cfg.dim3 = false;
    cfg.limitZ = [-20 20];
    cfg.i_freq = freqs.alphafreq;
    cfg.averagePower = false;

    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);
end
    
    cfg.cond2plot = {'aw', 'to', 'noMS'};
    cfg.averagePower = true;
    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);
%% sum plot
cfg = [];
cfg.cond2plot = {'aw', 'to', 'noMS'};
cfg.i_freq = freqs.alphafreq;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GAAW_TO_noMS.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';
cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%% group analysis post Event 
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_to_q1 = [postEvent_dir 'event_to_q1'];
cond_to_q2 = [postEvent_dir 'event_to_q2'];
cond_to_q3 = [postEvent_dir 'event_to_q3'];
cond_to_q4 = [postEvent_dir 'event_to_q4'];

postEvent = {cond_to_q1 cond_to_q2 cond_to_q3 cond_to_q4};

cfg = [];
cfg.input_file = write_dir_tf_noLap;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'to-q1', 'to-q2', 'to-q3', 'to-q4'};
cfg.write_dir = [write_dir];
cfg.fileName = 'quantile_noLap';
GA_data = eegFutureTF_GApostEvent(cfg);

%% indiv plot
dim2Name = {'to-q1', 'to-q2', 'to-q3', 'to-q4'};
for condInd = 1:length(dim2Name)
    cfg = [];
    cfg.plotType = 'indiv';
    cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_quantile_Lap.mat';
    cfg.value = 'contrVSipi';
    cfg.cond2plot = {dim2Name{condInd}};
    cfg.time2plot = [-0.2 1];
    cfg.subFig = true;
    cfg.dim3 = false;
    cfg.limitZ = [-20 20];
    cfg.i_freq = freqs.alphafreq;
    cfg.averagePower = false;

    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);

end
cfg.cond2plot = dim2Name;
cfg.averagePower = true;
figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
eegFuture_plot(cfg);
%% sum plot
cfg = [];
cfg.cond2plot = {'to-q1', 'to-q2', 'to-q3', 'to-q4'};
cfg.i_freq = freqs.alphafreq;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_quantile_Lap.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';
cfg.controlCond = 1;
cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%% group analysis post Event 
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_to_t1 = [postEvent_dir 'event_to_thr1'];
cond_to_t2 = [postEvent_dir 'event_to_thr2'];
cond_to_t3 = [postEvent_dir 'event_to_thr3'];

postEvent = {cond_to_t1 cond_to_t2 cond_to_t3};

cfg = [];
cfg.input_file = write_dir_tf_noLap;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'early', 'mid', 'late'};
cfg.write_dir = [write_dir];
cfg.fileName = 'three_noLap';
GA_data = eegFutureTF_GApostEvent(cfg);

%% indiv plot
dim2Name = {'early', 'mid', 'late'};
for condInd = 1:length(dim2Name)
    cfg = [];
    cfg.plotType = 'indiv';
    cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_three_Lap.mat';
    cfg.value = 'contrVSipi';
    cfg.cond2plot = {dim2Name{condInd}};
    cfg.time2plot = [-0.2 1];
    cfg.subFig = true;
    cfg.dim3 = false;
    cfg.limitZ = [-20 20];
    cfg.i_freq = freqs.alphafreq;
    cfg.averagePower = false;

    figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
    eegFuture_plot(cfg);

end
cfg.cond2plot = dim2Name;
cfg.averagePower = true;
figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
eegFuture_plot(cfg);
%% sum plot
cfg = [];
cfg.cond2plot = {'early', 'mid', 'late'};
cfg.i_freq = freqs.alphafreq;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GA_three_Lap.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.dim3 = false;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-10 10];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 1200 300])
eegFuture_plot(cfg);

cfg.plotType = 'sum';
%cfg.controlCond = 1;
cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 600 300])
eegFuture_plot(cfg);

%% group analysis 
cfg = [];
cfg.input_file = write_dir_tf;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.cond_trigger = {trigs.epoch trigs.epoch}; 
cfg.dim3 = false;
cfg.dim2Name = {'cVSi', };
cfg.dataName = 'contrVSipi';
cfg.comp = true;
cfg.compareCond = {[1 2]};
cfg.write_dir = [write_dir];
cfg.fileName = 'CVSI';
cfg.time2plot = []
GA_data = eegFuture_groupAnalysis(cfg);

%% indiv plot
cfg = [];
cfg.plotType = 'indiv';
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GACVSI.mat';
cfg.value = 'contrVSipi';
cfg.cond2plot = {'cVSi'};
cfg.time2plot = [-0.2 1];
cfg.subFig = true;
cfg.dim3 = false;
cfg.limitZ = [-20 20];
cfg.i_freq = freqs.alphafreq;
cfg.averagePower = false;

figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
eegFuture_plot(cfg);

cfg.cond2plot = {'cVSi'};
cfg.averagePower = true;
figure('Name',['indiviResults'],'NumberTitle','off', 'Position',[100 100 1200 800])
eegFuture_plot(cfg);

%% sum plot
cfg.cond2plot = {'cVSi'};
cfg.i_freq = freqs.alphafreq;
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_TF/GACVSI.mat';
cfg.averagePower = false;
cfg.t_mask = true;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-7 7];
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
eegFuture_plot(cfg);

cfg.plotType = 'sum';
cfg.cond2plot = {'cVSi'};
cfg.averagePower = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 800 400])
eegFuture_plot(cfg);

%%

%% group analysis (ERP)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_aw = [postEvent_dir 'event_aw'];
cond_to = [postEvent_dir 'event_to'];
cond_noMS = [postEvent_dir 'event_noMS'];

postEvent = {cond_aw cond_to cond_noMS};

cfg = [];

cfg.apply_ica = true;
cfg.apply_VR = true;    
cfg.apply_laplacian = true;
cfg.ica_onlyEEG = false;

cfg.data_dir = write_dir;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'aw', 'to', 'noMS'};
cfg.write_dir = [write_dir];
cfg.fileName = 'AW_To_noMS_Lap_N2pc';
cfg.baselinewindow = [-0.25 0];
eegFuture_GApostevent(cfg)

%% sum plot
cfg.cond2plot = {'aw', 'to', 'noMS'};
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_ERP/GA_AW_To_noMS_Lap_N2pc.mat';
cfg.t_mask = true;
cfg.time2plot = [-0.2 1.2];
cfg.limitZ = [-0.0002 0.0004];
cfg.subFig = true;
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
g = eegFutureEEG_plot(cfg);

line([0.2 0.2],[-0.0002 0.0004],'Color','r','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
line([0.3 0.3],[-0.0002 0.0004],'Color','r','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
%% group analysis (ERP)
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_to_early = [postEvent_dir 'event_to_early'];
cond_to_late = [postEvent_dir 'event_to_late'];

postEvent = {cond_to_early cond_to_late};


cfg = [];

cfg.apply_ica = true;
cfg.apply_VR = true;    
cfg.apply_laplacian = true;
cfg.ica_onlyEEG = false;

cfg.data_dir = write_dir;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'to-early', 'to-late'};
cfg.write_dir = [write_dir];
cfg.fileName = 'early_late_Lap_N2pc';
cfg.baselinewindow = [-0.25 0];
eegFuture_GApostevent(cfg)

%% sum plot
cfg =[];
cfg.dim3 = false;
cfg.cond2plot = {'to-early', 'to-late'};
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_ERP/GA_early_late_Lap_N2pc.mat';
cfg.t_mask = true;
cfg.time2plot = [-0.2 1.2];
%cfg.controlCond = 1;
cfg.limitZ = [-0.0002 0.0004];
cfg.subFig = true;
cfg.plotType = 'sum';
cfg.singleCond = true;
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
eegFutureEEG_plot(cfg);

%% %% indiv topo plot
cd('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/Epoch_data')
sublist=dir('*.mat');
sublist={sublist.name}; 
output_cleanData = creatDir([write_dir filesep 'cleanData_lapICAremove']);
for subjInd = 1:length(sublist) 
     clear data
    %% read data
    cfg.data_set = write_dir;
    cfg.subj_name = sublist{subjInd}(1:4);
    cfg.apply_ica = true;
    cfg.apply_VR = true;    
    cfg.apply_laplacian = true;
    cfg.ICA_onlyEEG = false;
    data = eegFuture_readData(cfg);
    save([output_cleanData filesep sublist{subjInd}],'data')
end

%%

sublist = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/cleanData_lapICAremove','*.mat');
sublist_okTrl = get_subFiles('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep','*.mat');

postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2/';
cond_aw = [postEvent_dir 'event_aw'];
cond_to = [postEvent_dir 'event_to'];
cond_noMS = [postEvent_dir 'event_noMS'];

postEvent= {cond_aw cond_to cond_noMS};
GA_ERP = [];
for eventInd = 1:length(postEvent)
    sublist_postEvent = get_subFiles(postEvent{eventInd},'*.mat');
    
    for subjInd = 1:length(sublist) 

        %% read data
        clear data
        disp(['load subj ' sublist{subjInd}(end-7:end-4)])
        load(sublist{subjInd})
        load(sublist_okTrl{subjInd})
        
        load(sublist_postEvent{subjInd})

        cond_sel = events_sel(trl2keep)';
        

        %figure('Name',[sublist{subjInd}(end-7:end-4)],'NumberTitle','off', 'Position',[100 100 1200 900]);

        cfg =[];
        cfg.ERP_data = data;
        cfg.comp_trig = {trigs.left_en trigs.right_en}; 
        cfg.time2plot = [[0 0.1]; [0.1 0.2]; [0.2 0.3]; [0.3 0.4]; [0.4 0.5]; [0.5 0.6]];
        cfg.top_loc= [parent_folder 'eegFuture' filesep 'chan_loc_England.mat'];
        cfg.maker_channel=[];
        cfg.plotTitle = [];
        cfg.cond_sel = cond_sel;
        cfg.plotFigure = false;
        cfg.zLimits  = [-0.0004 0.0004];
        cfg.GA = false;
        normalize_data = eegFuture_multiTopoplotER(cfg);

        GA_ERP(eventInd,subjInd, :,:) = normalize_data;
    end
end
%%
filed = creatDir([write_dir filesep 'topoRe']);
save ([filed filesep 'topo.mat'], 'GA_ERP');
%%
load('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/topoRe/topo.mat')
%%
cond_str = {'aw', 'to', 'noMs'};
for i= 1:3
    figure('Name', cond_str{i},'NumberTitle','off', 'Position',[100 100 1200 300]);
    ERP_data = [];
    ERP_data.trial = squeeze(GA_ERP(i,:,:,:));
    cfg.GA = true;
    cfg.maker_channel=[];
    cfg.plotTitle = [];
    cfg.top_loc= [parent_folder 'eegFuture' filesep 'chan_loc_England.mat'];
    cfg.comp_trig = {trigs.left_en trigs.right_en}; 
    cfg.ERP_data = ERP_data;
    cfg.ERP_time =ERP_time;
    cfg.time2plot = [[0 0.1]; [0.1 0.2]; [0.2 0.3]; [0.3 0.4]; [0.4 0.5]; [0.5 0.6]; [0.6 0.7]; [0.7 0.8]];
    cfg.plotFigure = true;
    cfg.zLimits  = [-0.0001 0.0001];
    eegFuture_multiTopoplotER(cfg);
end

%%
figure('Name', ['GA: recall-search'],'NumberTitle','off', 'Position',[100 100 1200 300]);
GA_motion.trial = GA_ERP;

ERP_data.trial = GA_motion;
cfg.GA = true;
cfg.ERP_data = ERP_data;
cfg.ERP_time =ERP_time;
cfg.time2plot = [[0 0.1]; [0.1 0.2]; [0.2 0.3]; [0.3 0.4]; [0.4 0.5]; [0.5 0.6]; [0.6 0.7]; [0.7 0.8]];
cfg.plotFigure = true;
cfg.zLimits  = [-0.0001 0.0001];
eegFuture_multiTopoplotER(cfg);

