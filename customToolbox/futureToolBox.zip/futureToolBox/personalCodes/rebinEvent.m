function rebinEvent(cfg)
% function eegFuture_GAbinEr(cfg)
% Description: read the bin events and bin the ERP data, then creat a data
% for all subject
%
%       cfg.event_file          = string specifying the directory where the bin_event files are.
%       cfg.output_dir          = uknow.
%       cfg.binTye              = type of bin e.g.,: Trial
%       cfg.binNum              = number of bin in trialtype bin
%
% part of the eegFuture toolbox, by Baiwei Liu, VU, 2021
%

% default values


% extract cfg value
v2struct(cfg);

% create output file
outfile = creatDir(output_dir);

% load info 
sublist_event = get_subFiles(event_file);

subjnum = length(sublist_event);


for subInd = 1:subjnum
    clear events_sel
    load(sublist_event{subInd})
    trialNum = length(events_sel);
    
    if strcmp(binType,'trial')
        old_sel = events_sel;
        trialsInbin = trialNum/binNum;
        bi_sel = [0:trialsInbin:trialNum];
        
        
        for binInd = 1:binNum
            bin_select = zeros(1,trialNum);
            minValue = bi_sel(binInd)+1;
            maxValue = bi_sel(binInd+1);
            bin_select(minValue:maxValue) = ones(1,trialsInbin);
            events_sel = old_sel & bin_select;
            events_raw = bin_select;
            outfile_bin = creatDir([outfile filesep 'bin' num2str(binInd)]);
            save([outfile_bin filesep sublist_event{subInd}(end-7:end-4)], 'events_sel','events_raw');
        end
    end
    
end


end