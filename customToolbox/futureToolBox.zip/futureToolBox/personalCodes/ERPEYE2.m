% sort trial based on time  
write_dir = [parent_folder filesep 'eyeGazeResults']; 
sublist = get_subFiles([write_dir filesep 'saccDetect'])
% 
timePool = [[200, 600]];
for i = 1: size(timePool,1)
    for subInd = 1:length(sublist)
        cfg =[];
        cfg.time = [-500:1:1200];
        cfg.time_i = timePool(i,:);
        cfg.time_control = [0,200];
        cfg.midCut = 350;
        cfg.input_file = sublist{subInd};
        cfg.output_dir = [write_dir filesep 'postEvent_' num2str(timePool(i,:))];
        eyeLab_sortMS(cfg)
    end
end

%% plot
% Group level eye position 
%postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_controlMS';
write_dir = [parent_folder filesep 'eyeGazeResults']; 
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_200  600';
postEvent = get_subFiles(postEvent_dir,'event*');
cfg = [];
cfg.epoch_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data'];
cfg.goodness_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/trialClean/trial_ok_index'];
cfg.channel = {'eyeX' 'eyeY'};
cfg.cond_trigger = {{trigs.left_en, trigs.right_en}}; 
cfg.postEvent = postEvent;
cfg.dim3 = false;
cfg.dim2Name = {'aw-200-350','aw-350-600','noMS-200-600','toward-200-350', 'toward-350-600'}; % the order of lable should be same as the lable in postEvent folder 
cfg.dataName = 'twoCond';
cfg.write_dir = write_dir;
cfg.removeBadTrial = false;
GA_data = eyeLab_groupAnalysis(cfg);


%%
write_dir = [parent_folder filesep 'eyeGazeResults']; 
cfg = [];
%cfg.plotType = 'indiv';
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResultsgroupResults/twoCond_GA.mat';
cfg.value = 'toward';
cfg.dim3 = false;
cfg.figure_dir = creatDir([write_dir filesep 'figures' filesep 'pos']);
%eyeLab_plot(cfg);

cfg.plotType = 'sum';
%cfg.subplotInd = [thresholdInd,minDis4Ms];
% if exist('g_gaze')
%     cfg.g = g_gaze;
% end
%cfg.plot_title = ['thre' num2str(threshold) '_' 'minDis' num2str(minDis4Ms)];
cfg.plot_title = ['control'];
cfg.timeLine = [0.2 0.35 0.6];
g_gaze = eyeLab_plot(cfg);

%%
%% group analysis (ERP)
write_dir = creatDir([parent_folder 'eegResults']);
postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_200  600/';
cond_to_early = [postEvent_dir 'event_to_late'];
cond_to_late = [postEvent_dir 'event_to_early'];
cond_noMS = [postEvent_dir 'event_noMS'];
cond_aw_early = [postEvent_dir 'event_aw_late'];
cond_aw_late = [postEvent_dir 'event_aw_early'];

postEvent = {cond_to_early cond_to_late cond_noMS cond_aw_early cond_aw_late};

cfg = [];

cfg.apply_ica = true;
cfg.apply_VR = true;    
cfg.apply_laplacian = true;
cfg.ica_onlyEEG = false;

cfg.data_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/cleanData_lapICAremove';
cfg.dataHere =true;
cfg.valueType = 'contrVSipi';
cfg.valueTrig = {trigs.left_en trigs.right_en};
cfg.valueChannel = {channels.visualL channels.visualR};
cfg.postEvent = postEvent; 
cfg.dim3 = false;
cfg.trial_ok_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/data_clean_epoch/trial_keep';
cfg.dim2Name = {'to-early', 'to-late','noMS', 'aw-early', 'aw-late'};
cfg.write_dir = [write_dir];
cfg.fileName = 'early_late_Lap_N2pc';
cfg.baselinewindow = [-0.25 0];
eegFuture_GApostevent(cfg)

%% sum plot
cfg =[];
cfg.dim3 = false;
cfg.cond2plot = {'to-early', 'to-late','noMS'}%, 'aw-early', 'aw-late'};
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegResults/groupResults_ERP/GA_early_late_Lap_N2pc.mat';
cfg.t_mask = true;
cfg.time2plot = [-0.2 1.2];
%cfg.controlCond = 1;
cfg.limitZ = [-0.0002 0.0004];
cfg.subFig = true;
cfg.plotType = 'sum';
cfg.singleCond = true;
cfg.timeLine = [0.2 0.35 0.6];
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
eegFutureEEG_plot(cfg);

cfg.cond2plot = {'aw-early', 'aw-late'}%, 'aw-early', 'aw-late'};
figure('Name',['sumResults'],'NumberTitle','off', 'Position',[100 100 500 400])
eegFutureEEG_plot(cfg);

%%
A = cell2Aarray(GA_shift.hz_to);
time = [-500:1:1200];
cfg =[];
cfg.dataA = A(:,500:1500);
cfg.dataB = A(:,500:1500);
cor_matrx = crossCorr(cfg);
%%
cmap = brewermap([],'*RdBu');
figure()
[C,h] = contourf([0:1:1000],[0:1:1000], cor_matrx);
colorbar
colormap((cmap))
caxis([-1 1])
%%
A_N2PC = squeeze(GA_struct.ERP(:,4,:));
timeWin = dsearchn(GA_struct.time',[0:0.001:1.0]')';
A_N2PC = A_N2PC(:,timeWin);
cfg =[];
cfg.dataA = A_N2PC;
cfg.dataB = A_N2PC;
cor_matrx_N2PC = crossCorr(cfg);

%%
cmap = brewermap([],'*RdBu');
figure()
[C,h] = contourf([0:1:1000],[0:1:1000], cor_matrx_N2PC);
colorbar
colormap((cmap))
caxis([-1 1])
%%
GazeShiftA = A(:,500:1500);
cfg =[];
cfg.dataA = GazeShiftA;
cfg.dataB = A_N2PC;
cor_matrx_cross = crossCorr(cfg);
%%
cmap = brewermap([],'*RdBu');
figure()
[C,h] = contourf([0:1:1000],[0:1:1000], cor_matrx_cross);
colorbar
colormap((cmap))
caxis([-1 1])