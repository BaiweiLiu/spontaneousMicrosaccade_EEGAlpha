function [B, LL] = JV10_function (X, T, NT, B_start)
% --> www.paulbays.com

if (nargin<2 || size(X,2)>1 || size(T,2)>1 || size(X,1)~=size(T,1) || nargin>2 && ~isempty(NT) && (size(NT,1)~=size(X,1) || size(NT,1)~=size(T,1)))     
    error('Input is not correctly dimensioned');
    return; 
end

if (nargin>3 && (B_start(1)<0 || any(B_start(2:4)<0) || any(B_start(2:4)>1) || abs(sum(B_start(2:4))-1) > 10^-6))
    error('Invalid model parameters');
    return;
end

MaxIter = 10^4; MaxdLL = 10^-4;

n = size(X,1); 

if (nargin<3) 
    NT = zeros(n,0); nn = 0;
else
    nn = size(NT,2);
end

% Default starting parameters
if (nargin<4)    
    K = 5; Pt = 0.5; 
    if (nn>0) Pn = 0.3; else Pn = 0; end
    Pu = 1-Pt-Pn;
else
    K = B_start(1); 
    Pt = B_start(2); Pn = B_start(3); Pu = B_start(4);
end

E  = X-T; E = mod(E + pi, 2*pi) - pi;
NE = repmat(X,1,nn)-NT; NE = mod(NE + pi, 2*pi) - pi;


LL = nan; dLL = nan; iter = 0;

while (1)
    iter = iter + 1;
    
    Wt = Pt * vonmisespdf(E,0,K);
    Wg = Pu * ones(n,1)/(2*pi);

    if nn==0
        Wn = zeros(size(NE));
    else
        Wn = Pn/nn * vonmisespdf(NE,0,K);
    end
    
    W = sum([Wt Wn Wg],2);
    
    dLL = LL-sum(log(W));
    LL = sum(log(W));
    if (abs(dLL) < MaxdLL | iter > MaxIter) break; end
    
    Pt = sum(Wt./W)/n;
    Pn = sum(sum(Wn,2)./W)/n; 
    Pu = sum(Wg./W)/n;
            
    rw = [(Wt./W) (Wn./repmat(W,1,nn))]; 
    
    S = [sin(E) sin(NE)]; C = [cos(E) cos(NE)];
    r = [sum(sum(S.*rw)) sum(sum(C.*rw))];
    
    if sum(sum(rw))==0
        K = 0;
    else
        R = sqrt(sum(r.^2))/sum(sum(rw));        
        K = A1inv(R);
    end
    
    if n<=15
        if K<2
            K = max(K-2/(n*K), 0);
        else
            K = K * (n-1)^3/(n^3+n);
        end
    end       
end

if iter>MaxIter
    warning('JV10_function:MaxIter','Maximum iteration limit exceeded.');
    B = [NaN NaN NaN NaN]; LL = NaN;
else  
    B = [K Pt Pn Pu];
end

%%

function K = A1inv(R)

if (0 <= R & R < 0.53)
    K = 2 * R + R^3 + (5 * R^5)/6;
elseif (R < 0.85)
    K = -0.4 + 1.39 * R + 0.43/(1 - R);
else
    K = 1/(R^3 - 4 * R^2 + 3 * R);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Copyright 2010 Paul Bays. This program is free software: you can     %
%   redistribute it and/or modify it under the terms of the GNU General  %
%   Public License as published by the Free Software Foundation.         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [B, LL] = JV10_fit (X, T, NT)
% JV10_FIT (X, T, NT)
%   Returns maximum likelihood parameters B for a mixture model describing 
%   recall responses X in terms of target T, non-target NT, and uniform 
%   responses. Inputs should be in radians, -PI <= X < PI. Fitting is based 
%   on an EM algorithm with multiple starting parameters.
%
%   B = JV10_FIT (X, T, NT) returns a vector [K pT pN pU], where K is 
%   the concentration parameter of a Von Mises distribution capturing 
%   response variability, pT is the probability of responding with the 
%   target value, pN the probability of responding with a non-target 
%   value, and pU the probability of responding "randomly". 
%
%   [B LL] = JV10_FIT (X, T, NT) additionally returns the log likelihood LL.
%
%   Ref: Bays PM, Catalao RFG & Husain M. The precision of visual working 
%   memory is set by allocation of a shared resource. Journal of Vision 
%   9(10): 7, 1-11 (2009) 
%
%   --> www.paulbays.com

if (nargin<2 || size(X,2)>1 || size(T,2)>1 || size(X,1)~=size(T,1) || nargin>2 && ~isempty(NT) && (size(NT,1)~=size(X,1) || size(NT,1)~=size(T,1)))     
    error('Input is not correctly dimensioned'); return; 
end

n = size(X,1); 

if (nargin<3) NT = zeros(n,0); nn = 0; else  nn = size(NT,2); end

% Starting parameters
K = [     1   10  100];
N = [  0.01  0.1  0.4];
U = [  0.01  0.1  0.4];

if nn==0, N = 0; end

LL = -inf; B = [NaN NaN NaN NaN];

warning('off','JV10_function:MaxIter');

% Parameter estimates

for i=1:length(K)
    for j=1:length(N)
        for k=1:length(U)
            [b ll] = JV10_function(X,T,NT,[K(i) 1-N(j)-U(k) N(j) U(k)]);
            if (ll>LL)
                LL = ll;
                B = b;
            end
        end
    end
end

warning('on','JV10_function:MaxIter');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Copyright 2010 Paul Bays. This program is free software: you can     %
%   redistribute it and/or modify it under the terms of the GNU General  %
%   Public License as published by the Free Software Foundation.         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function X = wrap(Y, bound)
% X = WRAP(Y)
%   Maps Y values onto circular space (-PI <= X < PI). 
%   X = WRAP(Y, BOUND) specifies alternative bounds (default is PI).
%
%   --> www.paulbays.com

if nargin<2, bound = pi; end

X = mod(Y + bound, bound*2) - bound;