%% Analysis script behavioral pilot 

%% It's always good to start with a clean sheet
clc, clear, close all, warning('off','all')

%% Set directions
parent_folder = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/';

read_dir1 = [parent_folder  'exp1_sess1_eye'];
read_dir2 = [parent_folder  'exp1_sess2_eye'];


write_dir = [parent_folder filesep 'eyeGazeResults']; 

if ~exist(write_dir,'dir'); mkdir(write_dir); end

cfg= [];
cfg.package_folder = '/Users/baiweil/Documents/MATLAB_pacakges/';
cfg.scripts_path = [parent_folder  'Scripts'];
cfg.eyeLab_path = [parent_folder 'eyeLab'];

cd(cfg.eyeLab_path)
eyeLab_setup(cfg)

%% set parameter
projectname = 'reanalysisFreekData';
epoch_trig = [21:24];
epoch_time = [-0.5 1.5]; % the first is prestim, the second is poststim
localiser_trig = [201:209];
localiser_epoch_time = [-0.5 1.5];

%% Trigger for different conds
trig_left_en = [21 22];
trig_right_en= [23 24];
trig_left_hand = [21 23];
trig_right_hand = [22 24];


%% Read the files
cd(read_dir1)
sublist1=dir('*.asc');
sublist1={sublist1.name}; 

cd(read_dir2)
sublist2=dir('*.asc');
sublist2={sublist2.name}; 

%% step 1: epoch trial and localizer data
cfg = {};
for subjInd = 1:length(sublist1)
    cfg =[];
    cfg.file_name = {[read_dir1 filesep sublist1{subjInd}] [read_dir2 filesep sublist2{subjInd}]};
    cfg.outPut_folder = [parent_folder filesep 'eyeGazeResults'];
    cfg.epoch_trig = epoch_trig;
    cfg.epoch_time = epoch_time;
    cfg.localiser_trig = localiser_trig;
    cfg.localiser_epoch_time = localiser_epoch_time;
    cfg.subjID = sublist{subjInd}(2:3);
    eyeLab_preprocess(cfg)
end

%% localiser
cd([parent_folder filesep 'eyeGazeResults' filesep 'epoched_data']);
sublist=dir('*.mat');
sublist={sublist.name}; 

for subjInd = 1:length(sublist1)
    read_localiser = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/localiser_data'];
    outfilename_localiser = [ read_localiser filesep sublist{subjInd}];
    
    wr_dir = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults' filesep 'normalized_cal']; 
    if ~exist(wr_dir,'dir') ; mkdir(wr_dir); end   
    
    load(outfilename_localiser);
    
    cfg = [];
    cfg.eye_data = liser_data;
    cfg.localiser_triggers =[201 204 207 205 203 206 209];
    cfg.plotTitle = ['pp' sublist{subjInd}(1:2)];
    cfg.averg_time = [0.5 1];
    cfg.sc_size = [1680,1050]
    cfg.write_dir = wr_dir;
    eyeLab_localiser(cfg);
end

%% normalize

cd([parent_folder filesep 'eyeGazeResults' filesep 'epoched_data']);
sublist=dir('*.mat');
sublist={sublist.name}; 

for subjInd = 1:length(sublist)
    read_epoc = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/epoched_data' filesep sublist{subjInd}];
    read_loc = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_cal/data' filesep 'pp' sublist{subjInd}];
    
    load(read_epoc); load(read_loc);
    
    cfg=[];
    cfg.eye_data = eye_data;
    cfg.cal = cal;
    cfg.write_dir = [write_dir filesep 'normalized_data'];
    cfg.plotTitle = ['pp' sublist{subjInd}(1:2)];
    data = eyeLab_normalize(cfg);
    
    cfg=[];
    cfg.eye_data = data;
    cfg.noisyLine = [50 50];
    cfg.channel = {'eyeX' 'eyeY'};
    cfg.plotTitle = ['pp' sublist{subjInd}(1:2)];
    cfg.write_dir = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/' filesep 'trialClean'];
    trial_ok = eyeLab_detectNoisy(cfg);
    
    close all 
end

%% Group level analysis 

cfg = [];
cfg.epoch_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data'];
cfg.goodness_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/trialClean/trial_ok_index'];
cfg.channel = {'eyeX' 'eyeY'};
cfg.cond_trigger = {{trig_left_en, trig_right_en}; {epoch_trig, epoch_trig, epoch_trig}}; 
cfg.postEvent = postEvent;
cfg.dim3 = false;
cfg.dim2Name = {'toward','away', 'noMS'};
cfg.dataName = 'twoCond';
cfg.write_dir = write_dir;
cfg.removeBadTrial = false;
GA_data = eyeLab_groupAnalysis(cfg);

%%
cfg = [];
cfg.plotType = 'indiv';
cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResultsgroupResults/twoCond_GA.mat';
cfg.value = 'toward';
cfg.dim3 = false;
eyeLab_plot(cfg);

cfg.plotType = 'sum';
eyeLab_plot(cfg);

%% Group level analysis 

cfg = [];
cfg.epoch_file = ['/Users/baiweil/Desktop/Behavior_platform/WM4Action/write_data/normalized_data'];
cfg.goodness_file = ['/Users/baiweil/Desktop/Behavior_platform/WM4Action/write_data/trialClean/trial_ok_index'];
cfg.channel = {'eyeX' 'eyeY'};
cfg.dim2Name = {'search','recall'};
cfg.dim3Name = {'pure','mix', 'neutral'};
cfg.cond_trigger = {{trig_left_en, trig_right_en};  {trig_search, trig_recall}; {trig_pure trig_mix trig_neutral}}; 
cfg.dim3 = true;
cfg.dataName = 'threeCond';
cfg.write_dir = ['/Users/baiweil/Desktop/Behavior_platform/WM4Action/write_data/'];
GA_data = eyeLab_groupAnalysis(cfg);

%%
cfg = [];
cfg.plotType = 'indiv';
cfg.GA_address = '/Users/baiweil/Desktop/Behavior_platform/WM4Action/write_data/groupResults/threeCond_GA.mat';
cfg.value = 'toward';
cfg.dim3 = true;
eyeLab_plot(cfg);

cfg.plotType = 'sum';
eyeLab_plot(cfg);


