function [m_plot] = lineErr_plot(xax, values, rgb, shading) 

    % Input arguments 
    % xax       ---  time axis, 
    % values    ---  2D data (subjects x time), 
    % rgb: color as RGB values
    % shading: for only se 'se', for only ci 'ci', for se & ci 'both'
    
    % from Freek, Rose, Baiwei
    if size(values,1) ~= 1
        % get mean and SE
        m = squeeze(nanmean(values)); % MEAN
        se = squeeze(nanstd(values)) ./ sqrt(size(values,1)); % SE = std / sqrt(n)

        % also get 95% CI

        [~,~,ci,~] = ttest(values);
        ci(isnan(ci)) = 0;
        % flip vectors if columns instead of rows
        if size(xax,1) > size(xax,2) 
            xax = xax'; 
        end
        if size(m,1) > size(m,2) 
            m = m'; 
        end
        if size(se,1) > size(se,2) 
            se = se'; 
            se(isnan(se)) = 0;
        end
        % plot mean 
        m_plot = plot(xax, m, 'color', rgb); hold on
        % plot SE using 'patch'
        if ismember(shading, 'se') | ismember(shading, 'both') % If you want only se's or both
            patch([xax, fliplr(xax)],[m-se, fliplr(m+se)], rgb, 'edgecolor', 'none', 'FaceAlpha', .3);   % +/- 1 SEM
        end    
        if ismember(shading, 'ci') | ismember(shading, 'both') % If you want only CI's or both
            patch([xax, fliplr(xax)],[ci(1,:), fliplr(ci(2,:))], rgb, 'edgecolor', 'none', 'FaceAlpha', .2); % +/- 95% CI
        end
    else
        
         m_plot = plot(xax, values, 'color', rgb); hold on
    end
    
    set(m_plot,'LineWidth',3)
    set(gca, 'FontSize', 20,'Fontname','Arial', 'LineWidth', 1.2);
    set(gca,'TickDir','out');
    box off
    
    ax = gca;
    ax.TickLength = [0.015 0.03];


end