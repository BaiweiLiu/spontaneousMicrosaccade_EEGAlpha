function [data_out] = inCellSelec(c, index)
% select sub cell in large cell, Baiwei

for ci = 1:length(c)
    d{ci} = c{ci}{index};
end
data_out = d;
end