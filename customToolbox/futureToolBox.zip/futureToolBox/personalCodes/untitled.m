
%% It's always good to start with a clean sheet
clear, close all, warning('off','all')

%% Set directions
parent_folder = '/Users/baiweil/Desktop/Behavior_platform/WM4Action';
scripts_folder = [parent_folder filesep 'analysisScripts'];
package_folder = '/Users/baiweil/Documents/MATLAB';
addpath(package_folder,'-begin');addpath(scripts_folder,'-begin');

read_dir = [parent_folder filesep 'be_data/raw_data_search']; 
write_dir = [parent_folder filesep 'be_data/write_data']; 

if ~exist(write_dir,'dir')
    mkdir(write_dir)
end

%% parameter
Above_reject =1500;
outlierThresholdRT = 2.5; % z-score based
condition = {'pure', 'mix', 'neutral'};
matchCond = {'match', 'nonMatch'};

cd(read_dir)
sublist=dir('*.csv');
sublist={sublist.name}; 
%% Extract and clear the subjects data

%% Trial based process
for subjInd = 1:length(sublist)  
    rawTable = readtable(sublist{subjInd},'Delimiter', '\t'); %Load the csv file
    data_test = rawTable(strcmp(rawTable.prac,'formal'),:);
    data_formal = str2listInTable(data_test, 'oris_search');
    search_cohere = {};
    locs_search = {};
    target_turn ={};
    conds_match ={};
    encod_search_cohere ={};
    if iscell(data_formal.respTime)
        data_formal = data_formal(~strcmp(data_formal.respTime, 'False'),:);
        data_unresponse = data_test(strcmp(data_test.respTime, 'False'),:);
        data_formal = str2listInTable(data_formal, 'respTime');
    end 
    for linedInd = 1:height(data_formal)  
        A = data_formal.oris_search(linedInd) 
        B = [A{1}]
        loc_search = find(B == data_formal.test_ori(linedInd));
        if loc_search <4
            loc = 'left';
        else
            loc = 'right';
        end 

        if data_formal.test_ori(linedInd) <0
            ori_turn = 'left';
        elseif data_formal.test_ori(linedInd) >0
            ori_turn = 'right';
        end

        if strcmp(loc, ori_turn)
            ori_loc_search = 'same';
        else
            ori_loc_search = 'diff';
        end
        
        if strcmp(data_formal.blockCond(linedInd), 'mix')
            if data_formal.display(linedInd) == 1
                if strcmp(data_formal.categoryOfTest,'recall')
                    data_formal.combinationOrder(linedInd) = {'left'};
                elseif strcmp(data_formal.categoryOfTest,'search')
                    data_formal.combinationOrder(linedInd) = {'right'};
                end
                
            elseif data_formal.display(linedInd) == 2
                if strcmp(data_formal.categoryOfTest,'recall')
                    data_formal.combinationOrder(linedInd) = {'right'};
                elseif strcmp(data_formal.categoryOfTest,'search')
                    data_formal.combinationOrder(linedInd) = {'left'};                
                end
            end
        end
        
        if strcmp(loc, data_formal.combinationOrder(linedInd))
            loc_encod_search = 'same';
        else
            loc_encod_search = 'diff';
        end

        if data_formal.ori_distractor(linedInd) == data_formal.ori_nonTarget(linedInd)
            cond_match = 'match';
        else
            cond_match = 'nonMatch';
        end
        
        search_cohere{linedInd} = ori_loc_search;
        locs_search{linedInd} = loc;
        target_turn{linedInd} = ori_turn;
        conds_match{linedInd} = cond_match;
        encod_search_cohere{linedInd} = loc_encod_search;
    end

    data_formal.search_cohere = search_cohere'; 

    data_formal.Search_loc = locs_search';

    data_formal.ori_turn = target_turn';

    data_formal.cond_match = conds_match';
    
    data_formal.encod_search_cohere = encod_search_cohere';
    
    if iscell(data_formal.respTime)
        data_formal = str2listInTable(data_formal, 'respTime');
        data_formal.RT = data_formal.respTime - data_formal.startTime;
    else
        data_formal.RT = data_formal.respTime - data_formal.startTime;
    end

    sum_T{subjInd} = data_formal;
    responseRate(subjInd) = height(data_unresponse) / height(data_test);
end

%% Cond based process
for subjInd = 1:length(sublist)  
    subj_data = sum_T{subjInd};
    for condId = 1:length(condition)
        for matchID = 1:length(matchCond)
            cond_data = subj_data(strcmp(subj_data.blockCond,condition{condId}) & strcmp(subj_data.cond_match,matchCond{matchID}),:);
            
            [match_index, cleared_RT] = removeRTOutlier(cond_data.RT, Above_reject, outlierThresholdRT);
            cond_data(match_index == 0,:) = [];
            sum_T_condL{subjInd,condId,matchID} = cond_data;
        end
    end
end

%% sum Data and convert data to struct
Data = reshape(sum_T_condL, 1, (length(sublist))*length(condition)*length(matchCond));
for dataID = 1:length(Data)
    if dataID == 1
        sumAfter_table = Data{dataID};
    end
    sumAfter_table = [sumAfter_table; Data{dataID}];
end
Cleared_Data = table2struct(sumAfter_table,'ToScalar',true);

%% start plot 

colors = [173,216,161; 237 152 121; 96 182 196];
colors_line = [85 161 92; 204 63 50; 48 111 183];
colors = colors/256;
colors_line = colors_line/256;

%%
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','cond_match'}, 'mean', 'DataVars','RT');
figure('Position',[100 100 1800 400])
subplot(1,4,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_match = data.mean_RT(strcmp(data.cond_match,'match'),:);
    data_nonMatch = data.mean_RT(strcmp(data.cond_match,'nonMatch'),:);
    y = [data_nonMatch, data_match];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.5,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20);
end

hold off
ylabel('RT (ms)') 
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%
subplot(1,4,2);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score'}, 'mean', 'DataVars','RT');
y = [];
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    if condId ==1
    y = data.mean_RT;
    else
    y = [y data.mean_RT];
    end
end

x = [10 20 30];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.5,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

% ori loc-search coherence
subplot(1,4,3);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','search_cohere'}, 'mean', 'DataVars','RT');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_same = data.mean_RT(strcmp(data.search_cohere,'same'),:);
    data_diff = data.mean_RT(strcmp(data.search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '>');
end
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

% loc endcoing - search coherence
subplot(1,4,4);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','score','encod_search_cohere'}, 'mean', 'DataVars','RT');
cohere = {'same' 'diff'}
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}) & grouped_data.score == 100,:);
    data_same = data.mean_RT(strcmp(data.encod_search_cohere,'same'),:);
    data_diff = data.mean_RT(strcmp(data.encod_search_cohere,'diff'),:);
    y = [data_same, data_diff];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20,'dotMarker', '<');
end
hold off
set(gca,'ylim',[500 3000],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
%% ACC
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond','cond_match'}, 'mean', 'DataVars','score');

figure('Position',[100 100 1800 300])
subplot(1,4,1);
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    data_match = data.mean_score(strcmp(data.cond_match,'match'),:);
    data_nonMatch = data.mean_score(strcmp(data.cond_match,'nonMatch'),:);
    y = [data_nonMatch, data_match];
    x = [condId*20-10 condId*20];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[colors(condId,:);[1.0,1.0,1.0]],'dotFaceColor',[[1.0,1.0,1.0];colors(condId,:)],'lineColor',colors_line(condId,:)...
        ,'lineWidth',5,'dotSize',20);
end
hold off
ylabel('ACC (percent)') 
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 70]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);

%
subplot(1,4,2);
grouped_data = grpstats(sumAfter_table,{'subj', 'blockCond'}, 'mean', 'DataVars','score');
y = [];
for condId = 1:length(condition)
    data = grouped_data(strcmp(grouped_data.blockCond,condition{condId}),:);
    if condId ==1
    y = data.mean_score;
    else
    y = [y data.mean_score];
    end
end
x = [10 20 30];
    HDots = dotdensity(x, y, 'meanLine', 'on','delta',1.0,'spread',3.0 ...
        ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
        ,'lineWidth',5,'dotSize',20, 'dotMarker', '^');
hold off
set(gca,'ylim',[40 100],'TickLength', [0.03,0.2]);
set(gca,'xlim',[0 40]);
set(gca, 'FontSize', 20,'Fontname','Arial');
box off  
set(gca,'XColor','w') 
set(gca,'xtick',[]);
