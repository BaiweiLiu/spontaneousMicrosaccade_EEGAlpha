%% Time-frequency analysis
%% It's always good to start with a clean sheet
clear, close all, warning('off','all')

%% SET DEFAULT FOLDERS, ADD TF TOOLBOX, AND GET DATA
projectname = 'WM_diff_task';

% Indicate which computer you are going to use
Comp = 'm'; % 'm' (mac) or 'l' (linux) or 'w'(windows)
% Set directions
parent_folder = '/Users/baiweil/Library/Mobile Documents/com~apple~CloudDocs/Projects/PrepareWM4Action/Prepare_multiple_task/SelectingTask';
package_folder = '/Users/baiweil/Documents/MATLAB';

% Raw .bdf data folder
clear_data_dir = [parent_folder filesep 'data' filesep 'data_epoched'];
% Read dir
readdir     = clear_data_dir;
% output data folder
write_tf_dir = [parent_folder filesep 'data' filesep 'data_TF'];

if ~exist(write_tf_dir,'dir')
    mkdir(write_tf_dir)
end
% Add TF toolbox dir
tf_dir = [package_folder filesep 'tfdecomp-master'];
addpath(tf_dir)
%% triggers and events
left = [21 26 11 16 71 76 61 66];
right = [22 27 12 17 72 77 62 67];

Ori_left = [21 11 71 61 22 12 72 62 ];
Ori_right =[26 16 76 66  27 17 77 67];

task_recall = [16 66 17 67 11 61 12 62];
task_search = [21 71 22 72 26 76 27 77];

Cue_trigger = [21 26 11 16 71 76 61 66 22 27 12 17 72 77 62 67];
%% Get all the data file names
cd(clear_data_dir)
sublist=dir('*.set');
sublist={sublist.name};

Cond = {'left', 'right'};
%% Analysis_4_subjects
for subno = 1:length(sublist) 
    %% Load data
    % Data name
    filename = [clear_data_dir filesep sublist{subno}];
    % Load data
    fprintf('Loading subject %i of %i for analysis ...\n',subno,length(sublist));
    filename
    EEG = pop_loadset(filename);
    %% Lapacian
    %[ EEG.data(1:64,:,:), EEG.G, EEG.H ] = laplacian_perrinX(EEG.data(1:64,:,:),[EEG.chanlocs(1:64).X],[EEG.chanlocs(1:64).Y],[EEG.chanlocs(1:64).Z]);
    %% Set default parameter
    cfg = [];
    cfg.channels = 1:64;
    cfg.chanlocs = EEG.chanlocs;
    cfg.times2save = -500:20:1500;
    cfg.frequencies = [1 40 25]; % from min to max in nsteps
    cfg.cycles = [3 12]; % min max number of cycles used for min max frequency
    cfg.scale = 'log'; % whether the above frequency settings will be logarithmically (recommended) or linearly scaled ('lin')
    cfg.basetime = [-500 -200]; % pre-stim baseline
    cfg.baselinetype = 'conavg'; % 'conavg' or 'conspec'
    cfg.erpsubtract = false; % if true, non-phase-locked (i.e. "induced") power will be computed by subtracting the ERP from each single trial
    cfg.matchtrialn = true; % if true, conditions will be equated in terms of trial count (so SNR is comparable across conditions)
    cfg.srate = EEG.srate;
    cfg.eegtime = EEG.times;

    cfg.report_progress = true;
    cfg.save_output = true;
    cfg.overwrite = false;
    cfg.writdir = write_tf_dir;
    %% Read all the events and load data for different condition
    clear events;
    events = zeros(1,EEG.trials);
    for cEv = 1:numel(EEG.epoch)
         events(cEv) = cell2mat(EEG.epoch(cEv).eventtype(cell2mat(EEG.epoch(cEv).eventlatency)==0));
    end
    eegdat = cell(1,length(Cond));
    for j =[1:2]
        % Get data
        trialtype = ismember(events,eval(cell2mat(Cond(j))));
        if length(trialtype)> 720
           trialtype = trialtype(length(trialtype)-720+1:length(trialtype))
        end
        eegdat{j} = EEG.data(:,:,trialtype==1);
            
    end
    %% Data_file_name
    cfg.filename = [sublist{subno}(1:4) '_tfdecomp_output.mat'];
    [tf_pow,tf_phase,dim] = tfdecomp(cfg,eegdat);
    eval([sublist{subno}(1:4) '_pow=tf_pow;'])
    eval([sublist{subno}(1:4) '_pha=tf_phase;'])
    eval([sublist{subno}(1:4) '_dim=dim;'])
 
end
%% Load data in case of you start the script and plot again.
for subno = 1:length(sublist) 
    filename = [write_tf_dir filesep sublist{subno}(1:4) '_tfdecomp_output.mat'];
    load(filename)
    eval([sublist{subno}(1:4) '_pow=tf_pow;'])
    eval([sublist{subno}(1:4) '_pha=tf_phase;'])
    eval([sublist{subno}(1:4) '_dim=dim;'])
end
%%
All_pow1 = cat(5,pp01_pow,pp02_pow,pp03_pow,pp04_pow);
All_pha1 = cat(5,pp01_pow,pp02_pow,pp03_pow,pp04_pow);
%All_pow2 = mean(All_pow1,6);
All_pow2 = mean(All_pow1,5);
%%
cfg = [];
cfg.stat        = 'T';
cfg.dim         = dim;
cfg.toi         = [-500 1000];
cfg.toi_p       = [-500 1000];
cfg.foi         = [8 13]; %'all'
cfg.chan        = {'PO3','PO4','P3','P4','O1','O2', 'Pz'};
cfg.pval        = 0.05;
cfg.plot_output = 'yes';
cfg.single_subject = false;
cfg.metric = {'pow'};
cfg.freq = [8 13];
cfg.time = [500 1000];
cfg.scale = 'log';
cfg.markevents = [0];
All_pow2=permute(All_pow1,[5 1 2 3 4]);
tfmultiplot(cfg,All_pow2,dim);
%% plo-average freq and time
cfg = [];
cfg.dim         = dim;
cfg.toi         = [-500 1000];
cfg.foi         = [8 13]; %'all'
cfg.chan        = {'PO3','PO4','P3','P4','O1','O2', 'Pz'};
cfg.avgoverfreq = 'yes';
cfg.avgoverchan = 'yes';
cfg.avgovertime = 'yes';
cd(parent_folder)
average_pow = run_av_time_freq(cfg, All_pow1);
X2 = squeeze(mean(average_pow,3));
%% plot basic figure

cfg = [];

cfg.single_subject = true;
cfg.metric = {'pow'};
cfg.chan = {'PO3','PO4','P3','P4','O1','O2','Pz'};%{'PO3','PO4','P3','P4','O1','O2','PO7','PO8','P7','P8','P1','P2','P5','P6','P9','P10'};
cfg.freq = [8 13];  
cfg.time = [0 0];
cfg.scale = 'log';
cfg.connames = {'New2','Re2','New4','Re4'}; % this gives us a legend for the power line plot
cfg.markevents = [0 600];
cfg.cmap = 'lines';
%cfg.linecols = {[0 0.4470 0.7410] [0.9290 0.6940 0.1250] [0.4940 0.1840 0.5560] [0.3010 0.7450 0.9330]}
cfg.figtitle = 'Alpha Power';
All_pow2 = squeeze(mean(All_pow1,5));

All_pow3 = permute(All_pow1,[5 1 2 3 4]);
%All_pow4 = permute(pp31_pow,[5 1 2 3 4]);
%tfmultiplot(cfg,All_pow3,dim);
%plot4paper(cfg,All_pow2,dim);
All_zero = zeros(size(All_pow3));
sum_value = createFigure(cfg,All_zero,dim);

%for subno = 1:length(sublist) 
%    All_pow2=squeeze(All_pow1(:,:,:,:,subno));
%    tfmultiplot(cfg,All_pow2,dim);
%end
%%

cfg = [];
cfg.stat        = 'T';
cfg.dim         = dim;
cfg.toi         = [-500 6500];
cfg.toi_p       = [-500 6500];
cfg.foi         = 'all' %[7 12];
cfg.chan        = {'PO3','PO4','P3','P4','O1','O2', 'Pz'};
cfg.pval        = 0.05;
cfg.plot_output = 'yes';
cfg.single_subject = true;
cfg.metric = {'pow'};
cfg.freq = [8 13];
cfg.time = [1000 1400];
cfg.scale = 'log';
cfg.markevents = [0];
%cfg.cmap = cmap;

cfg.avgoverfreq = 'yes';
cfg.foi         = [8 13];

con = permute(All_pow1,[5 1 2 3 4]);
%con1 = squeeze(mean(con(:,:,:,:,:),2));

for coninx = 1:4
    con2 = squeeze(con(:,coninx,:,:,:));
    tfstat_anti = tfclustperm_tf(cfg,con2);
end

%% plot difference 

cfg = [];
cfg.stat        = 'T';
cfg.dim         = dim;
cfg.toi         = [-500 1000];
cfg.toi_p       = [-500 1000];
cfg.foi         = [8 13]; %'all'
cfg.chan        = {'PO3','PO4','P3','P4','O1','O2', 'Pz'};
cfg.pval        = 0.05;
cfg.plot_output = 'yes';
cfg.single_subject = false;
cfg.metric = {'pow'};
cfg.freq = [8 13];
cfg.time = [1000 1400];
cfg.scale = 'log';
cfg.markevents = [0];
cfg.figureTitle = 'R4-N4';
%cfg.cmap ='lines';

cfg.avgoverfreq = 'yes';

con = permute(All_pow1,[5 1 2 3 4]);
%con1 = squeeze(mean(con(:,:,:,:,:),2));
con1 = squeeze(con(:,1,:,:,:));
con2 = squeeze(con(:,3,:,:,:));
conZero = con2;
conZero= zeros(size(conZero));
tfstat_anti = tfclustperm_tf(cfg,con1,con2);

%%
for subno = 1:length(sublist) 
    All_pow2=squeeze(All_pow1(:,:,:,:,subno));
    tfmultiplot(cfg,All_pow2,dim);
end
%% Statistical analysis
cfg = [];
cfg.stat        = 'T';
cfg.dim         = dim;
cfg.toi         = [-500 1000];
cfg.toi_p       = [-500 1000];
%cfg.foi         = [8 13];
cfg.chan        = {'PO3','PO4','P3','P4','O1','O2', 'Pz'};
cfg.pval        = 0.05;
cfg.plot_output = 'yes';
%cfg.cmap        = cmap;
% cfg.chandiff = {};
%cfg.foi         = [8 13];
cfg.avgoverfreq = 'yes';
cfg.avgoverfreq = 'no';
con = permute(All_pow1,[5 1 2 3 4]);
con1 = squeeze(con(:,2,:,:,:));
con2 = squeeze(con(:,1,:,:,:));
tfstat_anti = tfclustperm_tf(cfg,con1,con2);
%cfg.avgoverfreq = 'yes';
%cfg.foi         = [8 13];
%tfstat_anti = tfclustperm_tf(cfg,con1);
%%
 
con = permute(All_pow,[5 1 2 3 4]);
con1 = squeeze(mean(con(:,:,:,:,:),2));
%con2 = squeeze(con(:,1,:,:,:));
tfstat_anti = tfclustperm_tf(cfg,con1);
