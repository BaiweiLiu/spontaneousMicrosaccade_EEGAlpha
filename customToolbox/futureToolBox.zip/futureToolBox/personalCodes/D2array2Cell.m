function [data_out] = D2array2Cell(input)
for i = 1:size(input,1)
    c{i} = input(i,:);
end
data_out = c;
end