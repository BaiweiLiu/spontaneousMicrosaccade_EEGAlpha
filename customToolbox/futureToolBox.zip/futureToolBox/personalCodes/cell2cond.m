function [data_out1, data_out2] = cell2cond(input_cell, cond_maker)
c = {};
c_maker ={};
for i = 1:size(input_cell,2)  
    c = [c input_cell{i}];
    cond = repmat({cond_maker{i}},1,size(input_cell{i},2));
    c_maker = [c_maker cond];
end
data_out1 = c;
data_out2 = c_maker;
end