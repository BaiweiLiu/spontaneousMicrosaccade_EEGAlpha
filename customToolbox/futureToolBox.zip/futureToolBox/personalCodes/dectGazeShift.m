%% Analysis script behavioral pilot 

%% It's always good to start with a clean sheet
clc, clear, close all, warning('off','all')

%% Set directions
parent_folder = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/';

read_dir1 = [parent_folder  'exp1_sess1_eye'];
read_dir2 = [parent_folder  'exp1_sess2_eye'];


write_dir = [parent_folder filesep 'eyeGazeResults']; 

if ~exist(write_dir,'dir'); mkdir(write_dir); end

cfg= [];
cfg.package_folder = '/Users/baiweil/Documents/MATLAB_pacakges/';
cfg.scripts_path = [parent_folder  'Scripts'];
cfg.eyeLab_path = [parent_folder 'eyeLab'];
cfg.eegFuture_path = [parent_folder 'eegFuture'];

cd(cfg.eyeLab_path)
eyeLab_setup(cfg)

%% set parameter
projectname = 'reanalysisFreekData';
epoch_trig = [21:24];
epoch_time = [-0.5 1.5]; % the first is prestim, the second is poststim
localiser_trig = [201:209];
localiser_epoch_time = [-0.5 1.5];

%% Trigger for different conds
trig_left_en = [21 22];
trig_right_en= [23 24];
trig_left_hand = [21 23];
trig_right_hand = [22 24];

%%
close all
pool_threshold = [3];
pool_minDis4Ms = [1];
f1 = figure('Position',[100 100 1200 800]);
f2 = figure('Position',[100 100 1200 800]);
f = {f1 f2};
clear g_shift
clear g_gaze
for thresholdInd = 1:length(pool_threshold)
    for minDisInd = 1:length(pool_minDis4Ms)
        threshold = pool_threshold(thresholdInd);
        minDis4Ms = pool_minDis4Ms(minDisInd);
        %% detect ms
        data_file = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data/';
        cd(data_file);
        sublist=dir('*.mat');
        sublist={sublist.name}; 
        for subInd = 1:length(sublist)

            cfg = [];
            cfg.read_file = [data_file filesep sublist{subInd}];
            cfg.smooth_raw = false;
            cfg.smooth_der = true;
            cfg.smooth_der2 = true;
            cfg.smooth_step = 7;
            cfg.latency = [-0.5 1.2];
            cfg.ntrl = 5;
            cfg.threshold = threshold;
            cfg.winbef = [50 0];
            cfg.winaft = [50 100];
            cfg.minISI = 100;
            cfg.minDis = minDis4Ms;
            cfg.trig_left = trig_left_en;
            cfg.plotFig = true;
            cfg.trig_right = trig_right_en;
            cfg.output_dir = write_dir;
            cfg.subjID = sublist{subInd}(1:end-4);
            eyeLab_mSaccDetect(cfg);
        end

        %% sort trial based on ms
        cd([write_dir filesep 'saccDetect']);
        sublist=dir('*.mat');
        sublist={sublist.name}; 
% 
        for subInd = 1:length(sublist)
            cfg =[];
            cfg.time = [-500:1:1200];
            cfg.time_i = [200, 600];
            cfg.time_control = [-500,200];
            cfg.input_file = [write_dir filesep 'saccDetect' filesep sublist{subInd}];
            cfg.output_dir = [write_dir filesep 'postEvent_controlMS'];
            eyeLab_sortMS(cfg)
        end
        
        %%
        eventFolders = {'event_raw'}
        for eventInd = 1:numel(eventFolders)
            eventF = eventFolders{eventInd};
            %% extract shift data
            cfg=[];
            cfg.time_i = [200, 600];
            cfg.time = [-500:1:1200];
            cfg.input_dir = [write_dir filesep 'saccDetect'];
            cfg.output_dir = [write_dir filesep 'shiftGA'];
            cfg.outfile_name = ['thre' num2str(threshold) '_' 'minDis' num2str(minDis4Ms) '_' eventF(7:end)];
            cfg.good_trial_dir = [write_dir filesep 'postEvent_controlMS' filesep eventF];
            eyeLab_GAshift(cfg)

            %% plot eye shift
            cfg = [];
            cfg.time = [-500:1:1200];
            cfg.plotType = 'sum';
%             cfg.figInd = f;
%             if exist('g_shift')
%                 cfg.g = g_shift;
%             end
            cfg.subFigInd = [3,3,(thresholdInd-1)*3 + minDisInd];
            cfg.figure_dir = creatDir([write_dir filesep 'figures' filesep 'shift']);
            cfg.plot_title = ['thre-' num2str(threshold) '-minDis-' num2str(minDis4Ms) '-' eventF(7:end)];
            cfg.GA_address = [write_dir filesep 'shiftGA' filesep 'thre' num2str(threshold) '_' 'minDis' num2str(minDis4Ms) '_' eventF(7:end) '.mat'];
            %cfg.subplotInd = [thresholdInd,minDis4Ms];
            g_shift = eyeLab_plotShift(cfg)
        end
        %% plot eye position 
        % Group level eye position 
        %postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent_controlMS';
        postEvent_dir = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/postEvent2';
        cfg = [];
        cfg.epoch_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/normalized_data'];
        cfg.goodness_file = ['/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResults/trialClean/trial_ok_index'];
        cfg.channel = {'eyeX' 'eyeY'};
        cfg.cond_trigger = {{trig_left_en, trig_right_en}}; 
        cfg.postEvent_dir = postEvent_dir;
        cfg.postEvent = {'event_aw' 'event_to' 'event_noMS'};
        cfg.dim3 = false;
        cfg.dim2Name = {'away','toward', 'noMs'}; % the order of lable should be same as the lable in postEvent folder 
        cfg.dataName = 'twoCond';
        cfg.write_dir = write_dir;
        cfg.removeBadTrial = false;
        GA_data = eyeLab_groupAnalysis(cfg);

        %%
        cfg = [];
        cfg.plotType = 'indiv';
        cfg.GA_address = '/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eyeGazeResultsgroupResults/twoCond_GA.mat';
        cfg.value = 'toward';
        cfg.dim3 = false;
        cfg.figure_dir = creatDir([write_dir filesep 'figures' filesep 'pos']);
        eyeLab_plot(cfg);

        cfg.plotType = 'sum';
        %cfg.subplotInd = [thresholdInd,minDis4Ms];
        if exist('g_gaze')
            cfg.g = g_gaze;
        end
        %cfg.plot_title = ['thre' num2str(threshold) '_' 'minDis' num2str(minDis4Ms)];
        cfg.plot_title = ['control']
        g_gaze = eyeLab_plot(cfg);
        
    end
end
%%
figure_dir = creatDir([write_dir filesep 'figures' filesep 'GA']);
figure(f{1})
set(f{1},'defaultfigurecolor','w');
imagewd = getframe(gcf);
imwrite(imagewd.cdata, [figure_dir filesep 'rate_MS' '.tiff']);

figure(f{2})
set(f{2},'defaultfigurecolor','w');
imagewd = getframe(gcf);
imwrite(imagewd.cdata, [figure_dir filesep 'magnitude' '.tiff']);

figure('Position',[100 100 1200 800])
g_gaze.draw()

imagewd = getframe(gcf);
imwrite(imagewd.cdata, [figure_dir filesep 'gaze' '.tiff']);

figure('Position',[100 100 1200 800])
g_shift.draw()

imagewd = getframe(gcf);
imwrite(imagewd.cdata, [figure_dir filesep 'shift' '.tiff']);

%%
for i = 1:3
    for d = 1:3
        line([200 200],[0 1.5],'Color','k','LineStyle','--','Parent',g_shift(i,d).facet_axes_handles(1))
        line([600 600],[0 1.5],'Color','k','LineStyle','--','Parent',g_shift(i,d).facet_axes_handles(1))
        line([0 0],[-2 10],'Color','k','LineStyle','--','Parent',g_gaze(i,d).facet_axes_handles(1));
        line([-0.25 1.25],[0 0],'Color','k','LineStyle','--','Parent',g_gaze(i,d).facet_axes_handles(1));
        
    end
end
% %% setting for plot 
% colors = [173,216,161; 237 152 121; 96 182 196];
% colors_line = [85 161 92; 204 63 50; 48 111 183];
% colors = colors/256;
% colors_line = colors_line/256;
% colorMaker = [repmat({'toward'},1,length(GA_shiftL_to)) repmat({'away'},1,length(GA_shiftL_to)) repmat({'toward'},1,length(GA_shiftL_to)) repmat({'away'},1,length(GA_shiftL_to))];
% 
% 
% lineMaker = [repmat({'left_item'},1,length(GA_shiftL_to)) repmat({'left_item'},1,length(GA_shiftL_to)) repmat({'right_item'},1,length(GA_shiftL_to)) repmat({'right_item'},1,length(GA_shiftL_to))];
%  
% y = [GA_hzL_to GA_hzL_aw GA_hzR_to GA_hzR_aw];
% 
% clear g
% g = gramm('x', [-500:1:1200], 'y', y, 'color', colorMaker,'lightness',lineMaker)% 'subset', strcmp(lineMaker,'left_item'))%,'lightness',lineMaker);
% g.stat_summary();
% g.set_line_options('style',{'-'});
% g.set_color_options('lightness_range',[30 60]);
% g.set_text_options('base_size',15,'label_scaling',1.4);
% g.set_names('x','Time (0 = onset of probe)','y','Frequency of shifts per s','color','Direction');
% g.axe_property('Xlim', [-200 1000], 'YLim',[0 1.5],'YTick',[0: 0.2: 2]);
% figure('Position',[100 100 500 300])
% g.draw()
% line([200 200],[0 1.5],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1))
% line([500 500],[0 1.5],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1))
% % snapnow;
% % g.update('subset', strcmp(lineMaker,'right_item'));
% % g.stat_summary();
% % g.set_line_options('style',{'--'});
% % g.no_legend();
% % g.draw()
% %%
% figure('Position',[100 100 1200 300])
% y = [];condId =1;
% subplot(1,3,1);
% y = [GA_HZ_to' GA_HZ_aw'];
% x = [1 4];
%     HDots = dotdensity(x, y, 'meanLine', 'on','delta',0.15,'spread',0.8 ...
%         ,'dotEdgeColor',[1.0,1.0,1.0],'dotFaceColor',colors,'lineColor',colors_line ...
%         ,'lineWidth',5,'dotSize',20);
% hold off
% ylabel('Percetage of shift over trials') 
% % set(gca,'ylim',[0 1000],'TickLength', [0.03,0.2]);
% % set(gca,'xlim',[0 40]);
% set(gca, 'FontSize', 20,'Fontname','Arial');
% box off  
% set(gca,'XColor','w') 
% set(gca,'xtick',[]);
% %% Load shift d
% cd([write_dir filesep 'saccDetect']);
% sublist=dir('*.mat');
% sublist={sublist.name}; 
% gaze_window = [200, 500]; time = [-500:1:1200];
% t2sort = dsearchn(time', gaze_window');
% GA_HZ_to =[];GA_HZ_aw = [];
% 
% outfile = [write_dir filesep 'postEvent'];
% outfile_to = creatDir([outfile filesep 'event_to']);
% outfile_aw = creatDir([outfile filesep 'event_aw']);
% outfile_noMS = creatDir([outfile filesep 'event_noMS']);
% 
% postEvent = {outfile_to outfile_aw outfile_noMS};
% figure('Position',[100 100 1200 800])
% for subInd = 1:length(sublist)
%     
%     load(sublist{subInd});
%     numTrials = size(gazeShift.gazeL_to,1);
%     trial_to = zeros(1,numTrials);
%     trial_aw = zeros(1,numTrials);
%     trial_noMs = ones(1,numTrials);
%     for trialID = 1 : numTrials 
%         [~, indL_to]=ismember(1,gazeShift.gazeL_to(trialID,[t2sort(1):t2sort(2)]));
%         [~, indL_aw]=ismember(1,gazeShift.gazeL_aw(trialID,[t2sort(1):t2sort(2)]));
%         [~, indR_to]=ismember(1,gazeShift.gazeR_to(trialID,[t2sort(1):t2sort(2)]));
%         [~, indR_aw]=ismember(1,gazeShift.gazeR_aw(trialID,[t2sort(1):t2sort(2)]));
%         if (indL_to+indR_to) > 0
%             trial_to(trialID) =1;
%         end
%         
%         if (indL_aw+indR_aw) > 0
%             trial_aw(trialID) =1;
%         end
%         
%         if (indL_to+indR_to + indL_aw+indR_aw) >0 
%             trial_noMs(trialID) = 0;
%         end
%     end
%     
%     trial_to = logical(trial_to);
%     trial_aw = logical(trial_aw);
%     trial_noMs = logical(trial_noMs);
%     events_sel = trial_to;
%     save([outfile_to  filesep sublist{subInd}], 'events_sel');
%     events_sel = trial_aw;
%     save([outfile_aw  filesep sublist{subInd}], 'events_sel');
%     events_sel = trial_noMs;
%     save([outfile_noMS  filesep sublist{subInd}], 'events_sel');
    
%     % extract the shift rate
%     shiftRateL_tow = sum(gazeShift.gazeL_to(trial_to,:),1)/(numTrials/2);
%     shiftRateL_away = sum(gazeShift.gazeL_aw(trial_to,:),1)/(numTrials/2);
%     shiftRateR_tow = sum(gazeShift.gazeR_to(trial_to,:),1)/(numTrials/2);
%     shiftRateR_away = sum(gazeShift.gazeR_aw(trial_to,:),1)/(numTrials/2);
%     
%     % convert to the shift hz
%     hzL_to = smoothdata(shiftRateL_tow,2,'movmean',100) * 1000;
%     hzL_aw = smoothdata(shiftRateL_away,2,'movmean',100) * 1000;
%     hzR_to = smoothdata(shiftRateR_tow,2,'movmean',100) * 1000;
%     hzR_aw = smoothdata(shiftRateR_away,2,'movmean',100) * 1000;
%     
%     % get rate of shift in toi
%     rate_tow = mean([shiftRateL_tow; shiftRateR_tow],1);
%     rate_awa = mean([shiftRateL_away; shiftRateR_away],1);
%     
%     Rate_to_toi = sum(rate_tow(t2plot(1):t2plot(2)));
%     Rate_aw_toi = sum(rate_awa(t2plot(1):t2plot(2)));
%     
%     % get power 
%     powerL_to = abs(nanmean(gazeShift.powerL_to,1));
%     powerL_aw = abs(nanmean(gazeShift.powerL_aw,1));
%     powerR_to = abs(nanmean(gazeShift.powerR_to,1));
%     powerR_aw = abs(nanmean(gazeShift.powerR_aw,1));
%     
%     % smooth power
%     powerL_to_sm = smoothdata(powerL_to,2,'movmean',100);
%     powerL_aw_sm = smoothdata(powerL_aw,2,'movmean',100);
%     powerR_to_sm = smoothdata(powerR_to,2,'movmean',100);
%     powerR_aw_sm = smoothdata(powerR_aw,2,'movmean',100);
%     
%     % set the GA data
%     GA_RateL_toi_to(subInd) = Rate_to_toi;
%     GA_RateL_toi_aw(subInd) = Rate_aw_toi;
%     GA_RateR_toi_to(subInd) = Rate_to_toi;
%     GA_RateR_toi_aw(subInd) = Rate_aw_toi;
%     
%     GA_hzL_to{subInd} = hzL_to;
%     GA_hzL_aw{subInd} = hzL_aw;
%     GA_hzR_to{subInd} = hzR_to;
%     GA_hzR_aw{subInd} = hzR_aw;
%     
%     hz_to = mean([hzL_to; hzR_to]);
%     hz_aw = mean([hzL_aw; hzR_aw]);
%     power_to = mean([powerL_to_sm; powerR_to_sm]);
%     power_aw = mean([powerL_aw_sm; powerR_aw_sm]);
%     
% %     hzaw = sum(gazeShift_denBin([2,4],:),1)*2;
% 
%     subplot(5,5,subInd)
%     plot([-500:1:1200],hz_to,'Color','r');hold on
%     plot([-500:1:1200],hz_aw,'Color','b'); 
%     plot([200 200],[0 1.5],'--k'); 
%     plot([500 500],[0 1.5],'--k'); 
%     xlim([-200 1000]); ylim([0 2.5]);
%     title(sublist{subInd}(1:end-4))
%     xlabel('Time (0 = onset of probe)')
%     if ismember(subInd,[1 6 11 16 21])
%         legend('Toward','Away')
%         ylabel('Shift HZ (rate/second)')
%     end
% end