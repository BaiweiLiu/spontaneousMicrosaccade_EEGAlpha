function [data_out] = select_colors(num_col, color_range, sa, lum)
% function used to select colors 
% baiwei, vu, 2021
if num_col > 1
    color_step = (color_range(2) - color_range(1)) / num_col;
    for colInd = 1: num_col
        (color_range(1)+(colInd-1) * color_step)/360
       colors(colInd,1:3) =  hsl2rgb([(color_range(1)+(colInd-1) * color_step)/360, sa/100, lum/100 ]);
    end
end
data_out = colors;
end