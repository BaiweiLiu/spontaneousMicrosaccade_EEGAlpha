function out_put = crossCorr(cfg)

v2struct(cfg)

for colIndA = 1:size(dataA,2)
    A = dataA(:,colIndA);
    for colIndB = 1:size(dataB,2)
        B = dataB(:,colIndB);
        r = corr(A,B);
        r_matrix(colIndA,colIndB) = r;
    end
end
out_put = r_matrix;
end