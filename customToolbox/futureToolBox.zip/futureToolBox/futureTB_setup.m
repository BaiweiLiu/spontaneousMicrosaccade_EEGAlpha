function eyelab_setup(cfg)

error =false;
% prepare
restoredefaultpath

% eyelab 
eyeLab_path = [cfg.futureTB_path filesep 'eyeLab'];
if (exist(eyeLab_path,'dir') == 7) && (~isdeployed)
    addpath(genpath(eyeLab_path),'-begin');
    disp('EyeLab is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, CANNOT FIND ELELAB TOOLBOX AT ' eyelab_path ', CHECK THE PATHS ']);
end

v2struct(cfg);

% eegFuture 
eegFuture_path = [cfg.futureTB_path filesep 'eegFuture'];
if (exist(eegFuture_path,'dir') == 7) && (~isdeployed)
    addpath(genpath(eegFuture_path),'-begin');
    disp('eegFuture is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, CANNOT FIND eegFuture TOOLBOX AT ' eegFuture_path ', CHECK THE PATHS ']);
end

% fmriLab 
eegFuture_path = [cfg.futureTB_path filesep 'fmriLab'];
if (exist(eegFuture_path,'dir') == 7) && (~isdeployed)
    addpath(genpath(eegFuture_path),'-begin');
    disp('fmriLab is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, CANNOT FIND fmriLab TOOLBOX AT ' eegFuture_path ', CHECK THE PATHS ']);
end
% self-scripts code
scripts_path = [cfg.futureTB_path filesep 'personalCodes'];
if (exist(scripts_path,'dir') == 7) && (~isdeployed)
    addpath(genpath(scripts_path),'-begin');
    disp('Your personal codes is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, cannot find your code at ' scripts_path ', CHECK THE PATHS ']);
end

% path definitions

ft_path = [package_folder 'fieldtrip'];
gm_path = [package_folder 'gramm'];
bayslab_path = [package_folder 'bayslab_toolbox'];

% FT
if (exist(ft_path,'dir') == 7) && (~isdeployed)
    addpath(ft_path,'-begin');
    ft_defaults; % find default options and files  
    addpath([ft_path filesep 'qsub']);
    disp('Fieldtrip is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, please put the FIELDTRIP TOOLBOX at ' package_folder]);
end

% gramm
if (exist(gm_path,'dir') == 7) && (~isdeployed)
    addpath(gm_path,'-begin');
    disp('Gramm is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, please put the GRAMM TOOLBOX at ' package_folder]);
end

% bayslab_toobox
if (exist(bayslab_path,'dir') == 7) && (~isdeployed)
    addpath(bayslab_path,'-begin');
    disp('Bayslab toobox is prepared sucessfully');
elseif ~isdeployed
    error = true;
    disp(['WARNING, please put the bayslab toobox at ' package_folder]);
end

if ~ error
disp('All codes are okay, enjoy!!');
end

close;
clear;