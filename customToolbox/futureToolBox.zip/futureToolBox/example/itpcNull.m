clear all
close all
clc
%% try out for different trial numbers to see that it matters
cnt = 0;
for ntrials = [10, 100, 500, 1000];
    cnt = cnt+1;
    %% draw random set of angles, many times and get "null-ITPC values"
    nsimulations = 1000;
    for iteration = 1:nsimulations; % how many times draw a random sample
        x = (rand(ntrials,1)-0.5)+(rand(ntrials,1)-0.5)*i;
        x = x ./ abs(x);
        if iteration == 1 figure(1); subplot(2,2,cnt); compass(x); end;
        mrv(iteration) = abs(mean(x)); % mean resultant vector, just like ITPC
    end
    %% plot and also get median over the nsimulations
    figure(2);
    subplot(2,2,cnt); hist(mrv, 100); title([num2str(ntrials), 'trls']);
    xlim([0 0.2])
    med = median(mrv); % median random "itpc"
    xlabel(['med = ', num2str(med)]);
end