function [data_out] = eegFuture_topoplot(cfg)
titleSW = true;
v2struct(cfg); % cfg = TF_data, average_power, averg_time, top_loc, maker_channel, plotTitle,comp_trig
load(top_loc); cmap = brewermap([],'*RdBu');

t2plot=dsearchn(TF_data.time',averg_time')';
f2plot=dsearchn(TF_data.freq', average_power')';

foifreq = [num2str(average_power(1)) '-' num2str(average_power(2))]; 
toiTime = [num2str(averg_time(1)) '-' num2str(averg_time(2))];

foi_seq = [f2plot(1):f2plot(2)];
toi_seq = [t2plot(1):t2plot(2)];

if ~GA
    condA = ismember(TF_data.trialinfo(:,1), comp_trig{1}); 
    condB = ismember(TF_data.trialinfo(:,1), comp_trig{2});

    
   if ~exist('cond_sel')
        topodatA =squeeze(mean(TF_data.powspctrm(condA,:,foi_seq,toi_seq),[1 3 4]));
        topodatB =squeeze(mean(TF_data.powspctrm(condB,:,foi_seq,toi_seq),[1 3 4]));
   else 

        topodatA =squeeze(mean(TF_data.powspctrm(condA'&cond_sel,:,foi_seq,toi_seq),[1 3 4]));
        topodatB =squeeze(mean(TF_data.powspctrm(condB'&cond_sel,:,foi_seq,toi_seq),[1 3 4]));
   end
    data2plot = ((topodatA - topodatB)./(topodatA + topodatB))*100;
else
    
    data2plot = squeeze(mean(TF_data.powspctrm(:,:,foi_seq,toi_seq),[1 3 4]));
end
topoplot(data2plot,chan_loc,'electrodes','off','emarker2',{maker_channel,'*','k',5,1},'whitebk','on','plotrad',0.5,'style', 'map','maplimits',zLimits);
if titleSW; title([plotTitle ' ' toiTime 'ms | ' foifreq 'Hz']); end 
colormap(cmap)

if ~GA
    if ~exist('cond_sel')
        topodatA =squeeze(mean(TF_data.powspctrm(condA,:,:,:),[1]));
        topodatB =squeeze(mean(TF_data.powspctrm(condB,:,:,:),[1]));
   else 

        topodatA =squeeze(mean(TF_data.powspctrm(condA'&cond_sel,:,:,:),[1]));
        topodatB =squeeze(mean(TF_data.powspctrm(condB'&cond_sel,:,:,:),[1]));
   end
    data2plot = ((topodatA - topodatB)./(topodatA + topodatB))*100;
    
    data_out = data2plot;
end
end