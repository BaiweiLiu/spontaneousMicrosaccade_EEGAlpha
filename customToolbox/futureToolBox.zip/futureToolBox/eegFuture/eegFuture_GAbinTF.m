function eegFuture_GAbinTF(cfg)

% function eegFuture_GAbinTF(cfg)
% Description: read the bin events and bin the ERP data, then creat a data
% for all subject
%
%       cfg.eeg_file            = string specifiying the directory where the epoched eeg files are;
%       cfg.event_file          = string specifying the directory where the bin_event files are.
%       cfg.output_dir          = uknow.
%       cfg.valueChannel        = to-be-analysised channels
%       cfg.baselinewindow      = basedline window for ERP
%       cfg.valueTrig           = left_en and right_en triggers 
%       cfg.fileName            = uknow.
%       cfg.minTrials           = the minim num of trials in one bin, if no,
%       cfg.trial_ok_dir        = uknow.
%       cfg.valueType           = toward or away, which value you want to get.
%       then Nan
%       cfg.reLoc               = relocate the data based on bin value
%       cfg.sampleRate          = the sample rate of eeg data
%
% part of the eegFuture toolbox, by Baiwei Liu, VU, 2021
%

% default values
sampleRate = 1000;
reLoc = false;

% extract cfg value
v2struct(cfg);

% create output file
outfile = creatDir(output_dir);

% get list of input files
sublist_eeg = get_subFiles(eeg_file);
sublist_event = get_subFiles(event_file);

%% get clean file
for goodInd  = 1: length(goodness_file)
    sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
end

%% run subLoop
for subInd = 1:length(sublist_eeg)

    infoDisp(['load event data for subj ' sublist_event{subInd}(end-7:end-4)]);
    load(sublist_event{subInd});  
    numBin =  size(event.sel,1);
    
    infoDisp(['Read cleaned data for subj ' sublist_eeg{subInd}(end-7:end-4)]);
    
    %% read data
    cfg = [];
    cfg.input_dir = sublist_eeg{subInd};
    cfg.goodness_file = inCellSelec(sublist_goodTl,subInd);
    [data,trialOK] = eegFuture_readTF(cfg);
    
    f2sort = dsearchn(data.freq', i_freq')';
    
%     % time lock-analysis
%     cfg = [];
%     cfg.keeptrials = 'yes';
%     ERP_data = ft_timelockanalysis(cfg, data);
    
    % size of epoch time
    if ~reLoc
        timeSize = size(data.powspctrm,4);
    else
        timeSize = (reLocWindow(2) - reLocWindow(1)) * 1000 * (sampleRate/1000);
    end
    
    % get left and right channels
    channel_left = match_str(data.label, valueChannel{1});
    channel_right = match_str(data.label, valueChannel{2});
    
    % get left and right trials
    left = ismember(data.trialinfo(:,1), valueTrig{1});
    right = ismember(data.trialinfo(:,1), valueTrig{2});

    % t2plot=dsearchn(ERP_data.time',averg_time')';
    % toi_seq = [t2plot(1):t2plot(2)];

    for binInd = 1:numBin 
        contra = []; ipi = []; cvsi = [];

        cond_sel = event.sel(binInd,trialOK);
        if reLoc
            cond_value = event.value(binInd,trialOK);
        end

        
        if ~reLoc
            
            % get and averaging contral and ipsi ERP 
            a = mean(mean(data.powspctrm(left&cond_sel',channel_right,f2sort(1):f2sort(2),:))); % contra-chR
            b = mean(mean(data.powspctrm(right&cond_sel',channel_right,f2sort(1):f2sort(2),:))); % ipsi-chR
            c = mean(mean(data.powspctrm(right&cond_sel',channel_left,f2sort(1):f2sort(2),:))); % contra-chL
            d = mean(mean(data.powspctrm(left&cond_sel',channel_left,f2sort(1):f2sort(2),:))); % ipsi-chL

            cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
            cvsi_chL = squeeze(((a-b) ./ (a+b)) * 100);
            cvsi = (cvsi_chR + cvsi_chL) ./ 2;

            contra = (a+c)./2;
            ipi = (b+d)./2;
        
        else
            % locations of the trial in bin
            trial_sel = find(cond_sel);
            
            if sum(cond_sel) >= minTrials
                for trialSelInd = 1:length(trial_sel)

                    % get one location of the trial in bin
                    trialInd = trial_sel(trialSelInd);

                    % get one value of the trial
                    trialValue = cond_value(trialInd);

                    % from time to index
                    t2sort = dsearchn(data.time',[trialValue/1000+reLocWindow(1); trialValue/1000+reLocWindow(2)]);

                    if left(trialInd) >0           
                        a = mean(data.powspctrm(trialInd,channel_right,f2sort(1):f2sort(2),[t2sort(1):t2sort(2)-1]),2); % contra
                        b = mean(data.powspctrm(trialInd,channel_left,f2sort(1):f2sort(2),[t2sort(1):t2sort(2)-1]),2); % ipsi
                        
                    elseif right(trialInd) >0
                        a = mean(data.powspctrm(trialInd,channel_left,f2sort(1):f2sort(2),[t2sort(1):t2sort(2)-1]),2);% contra
                        b = mean(data.powspctrm(trialInd,channel_right,f2sort(1):f2sort(2),[t2sort(1):t2sort(2)-1]),2); % ipsi
                    end
                    
                    contra(trialSelInd,:,:) = squeeze(a);
                    ipi(trialSelInd,:,:) = squeeze(b); 
                end
                contra = mean(contra);
                ipi = mean(ipi);
                cvsi = (contra - ipi) ./(contra + ipi) *100;
            end
            
        end
        if sum(cond_sel) >= minTrials
            data_cvsi(1,binInd,:) = squeeze(mean(contra));
            data_cvsi(2,binInd,:) = squeeze(mean(ipi));
            data_cvsi(3,binInd,:) = squeeze(mean(cvsi));
        else
            infoDisp('Number of trials is too low!','line')
            data_cvsi(1,binInd,:) = NaN(1,timeSize);
            data_cvsi(2,binInd,:) = NaN(1,timeSize);
            data_cvsi(3,binInd,:) = NaN(1,timeSize);
        end
    end
    
    GA_eeg.data(subInd,:,:,:) = data_cvsi;
    GA_eeg.subjName{subInd} = sublist_eeg{subInd}(end-7:end-4);
end

% save the data 
GA_eeg.time = data.time;
GA_eeg.bin = numBin;
GA_eeg.timeBin = event.timeBin;

GA_eeg.dimName = {'subjID', 'dataKind', 'binInd', 'time'};
save([outfile filesep 'GA_' fileName '.mat'], 'GA_eeg'); 
end