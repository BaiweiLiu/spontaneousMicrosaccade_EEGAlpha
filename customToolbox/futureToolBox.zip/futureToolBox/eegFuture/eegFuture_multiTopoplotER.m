function [data_out] = eegFuture_multiTopoplotER(cfg)

v2struct(cfg);

for timeInd = 1:size(time2plot,1)
    subplot(1,size(time2plot,1),timeInd)
    cfg =[];
    cfg.GA = GA;
    cfg.comp_trig = comp_trig;
    cfg.ERP_data = ERP_data;
    cfg.averg_time = time2plot(timeInd,:);
    cfg.top_loc= top_loc;
    cfg.maker_channel=maker_channel;
    cfg.plotTitle = [];
    cfg.zLimits = zLimits;
    cfg.plotFigure = plotFigure;
    cfg.baselinewindow = baselinewindow;
    if GA ; cfg.ERP_time =ERP_time;end
    if exist('cond_sel'); cfg.cond_sel = cond_sel; end
    eegFuture_topoplotER(cfg);
end

if ~GA; data_out = eegFuture_topoplotER(cfg); end
end