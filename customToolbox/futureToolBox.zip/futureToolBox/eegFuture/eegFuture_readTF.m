function [data_out, trial_ok] = eegFuture_readTF(cfg)

% function eegFuture_readTF(cfg)
% Description: grand average the gaze resutls
%       cfg.input_dir       = the dir of epoched eye_data
%       cfg.goodness_file   = dir of events we use to select trial.
%
% part of the eyeLab toolbox, by Baiwei Liu, VU, 2021
%

%% extract value
v2struct(cfg); 

%%
load(input_dir);
if ~isfield(data_tfr,'powspctrm')
    data_tfr.powspctrm = abs(data_tfr.fourierspctrm).^2;
end
numTrial = size(data_tfr.powspctrm,1);

%% removebad trials
if exist('goodness_file')
    tl_ok = 0;
    for fileInd  = 1: length(goodness_file)
        load(goodness_file{fileInd})
        if  size(event.sel,1) >1
            event.sel = event.sel';
        end
        tl_ok = event.sel + tl_ok;
    end
    trial_ok = ismember(tl_ok, length(goodness_file));
else
    trial_ok = ones(1,numTrial);
end   

infoDisp(['get ' num2str(sum(trial_ok)) '/' num2str(numTrial) ' to process'], 'line')

cfg = [];
cfg.trials = trial_ok;
data = ft_selectdata(cfg, data_tfr);

data_out = data;
end