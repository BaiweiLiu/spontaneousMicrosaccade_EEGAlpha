function [output] = eegFuture_tfPlot(cfg)

cluster_mask = true;
npermutations = 10000;
v2struct(cfg);

t_i = dsearchn(time', time_i')';
t_sel = [t_i(1):t_i(end)];

data2plot = tf_data(:,:,t_sel);
data_cond1 = squeeze(data2plot);
data_cond2 = zeros(size(data_cond1));

cfg = [];
cfg.xax = time(t_sel);
cfg.yax = freq;
cfg.npermutations = npermutations;
cfg.clusterStatEvalaluationAlpha = 0.025;
cfg.nsub = size(tf_data,1);
cfg.statMethod = 'montecarlo';  
state_mask = frevede_ftclusterstat2D(cfg,data_cond1,data_cond2)

%%
cmap = brewermap([],'*RdBu');

data2plot = tf_data(:,:,t_sel);
data2plot(isnan(data2plot)) = 0;
dummy = [];
dummy.time =time(t_sel);
dummy.freq = freq;
dummy.data2plot(1,:,:) = squeeze(mean(data2plot));
dummy.dimord = 'chan_freq_time';
dummy.channel = {'cvsi'};
dummy.label= {'cvsi'};
dummy.mask = state_mask.mask;

cfg = [];
cfg.parameter = 'data2plot';
cfg.figure = 'gcf';
if cluster_mask
    cfg.maskparameter = 'mask';
end
if exist('zli')
    cfg.zlim  = zli;
end
cfg.maskstyle = 'outline';

ft_singleplotTFR(cfg, dummy)

colormap((cmap));
colorbar off
title([])
cl=get(gca,'clim'); 
set(gca, 'FontSize', 20,'Fontname','Arial', 'LineWidth', 1.2);
set(gca,'TickDir','out');

output = state_mask;
end