lables = data.label;
old_lables = {chan_loc.labels};

for chanInd= 1:length(lables(1:end-2))
    lable = lables{chanInd};
    ind = strcmp(lable, old_lables);
    new_chan_loc(chanInd) = chan_loc(ind);
end
chan_loc = new_chan_loc;

save('/Users/baiweil/AnalysisDesk/ReAnalysisFreekData/eegFuture/chan_loc_England.mat', 'chan_loc');