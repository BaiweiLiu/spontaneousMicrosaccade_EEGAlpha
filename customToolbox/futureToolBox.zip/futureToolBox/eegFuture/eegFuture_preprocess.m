function [data_out] = eegFuture_preprocess(cfg)

% function eegFuture_preprocess(cfg)
% Description: the bin data based on the latency of sacc
%
%       cfg.epoch_dir           = dir of epoched data
%       cfg.input_dir           = dir of raw eeg data if no epoched data
%       cfg.epoch_time          = uknow
%       cfg.epoch_trig          = uknow
%       cfg.subj_name           = name of subject
%       cfg.output_dir          = uknow.
%       cfg.ica_here            = whether there already have ica
%       cfg.plot_out            = uknow;
%       cfg.ICA_onlyEEG         = do ica with EEG or EEG + EOG
%       cfg.autoICA             = remove ica commpoents visually or
%       automatically
%       cfg.autoICA_co_remove   = the threshold for sutomatically removing the ica.
%       cfg.i_channel           = interesting channel
%       cfg.i_freq              = interesting freqency
%       cfg.do_visualRemove     = whether do visual remove
% part of the eegFuture toolbox, by Baiwei Liu, VU, 2021
%
dataType = 'bdf';
% default values
v2struct(cfg); 

% create files
outfile_data = creatDir([output_dir filesep 'data_clean_epoch']);
outfile_results = creatDir([output_dir filesep 'data_clean_results']); 

Epochfile = creatDir([outfile_data filesep 'Epoch_data']);
icafile = creatDir([outfile_data filesep 'ICA_comp']); 
remv_compfile = creatDir([outfile_data filesep 'remv_comp']); 
trig_numfile = creatDir([outfile_data filesep 'trig_num']); 
trial2keepfile =  creatDir([outfile_data filesep 'trial_keep']); 

%% check datafile
% check header

if ~exist('epoch_dir')
    hdr = ft_read_header(input_dir);

    % check events
    event = ft_read_event(input_dir);
    sel = find(strcmp({event.type}, 'STATUS'));
    event = event(sel);

    figure; 
    g(1,1) = gramm('x', [event.sample], 'y', [event.value]);
    g(1,1).geom_point();
    g.set_text_options('base_size',15,'label_scaling',1.4);
    g.set_names('x','sample in recording','y','trigger value');
    g.draw();

    imagewd = getframe(gcf);
    imwrite(imagewd.cdata, [outfile_results filesep 'trig_results_' subj_name '.tiff']);

    mtable=tabulate([event.value]);
    mtable(mtable(:,2)==0,:)=[];
    mtable=mtable(:,[1 2]);
    if checkTrig
        disp(mtable)
        disp('Make sure the triggers and their number of ocurrence in the experiment make sense! If so, type in dbcont and hit enter...')
        keyboard
    end

    %% epoch
    cfg = [];
    cfg.dataset = data_set;
    cfg.trialdef.eventtype  = 'STATUS';
    cfg.trialdef.eventvalue = epoch_Event; % probe
    cfg.trialdef.prestim    = -epoch_time(1); % from 2.5 sec before probe onset
    cfg.trialdef.poststim   = epoch_time(2);; % til 2.5 sec after
    cfg = ft_definetrial(cfg);

    cfg.reref = 'yes';
    cfg.refchannel = refchannel; % reref to avg of both mastoids
    cfg.demean = 'yes';
    data = ft_preprocessing(cfg);

    %% create EOG
    Veog1 = ismember(data.label,  vert_EOG{1});   Veog2 = ismember(data.label,  vert_EOG{2}); % bipolar EOG chan 
    Heog1 = ismember(data.label,  hori_EOG{1});   Heog2 = ismember(data.label,  hori_EOG{2}); % bipolar EOG chan 
    data.label(end+1:end+2) = {'VEOG','HEOG'};
    for trl = 1:size(data.trial,2)
        data.trial{trl}(end+1,:) = data.trial{trl}(Veog1,:) - data.trial{trl}(Veog2,:);
        data.trial{trl}(end+1,:) = data.trial{trl}(Heog1,:) - data.trial{trl}(Heog2,:);
    end
    %% convert to 10-10 system labels
    cfg = [];
    cfg.layout = layoutset; % assumes this is standard
    layout = ft_prepare_layout(cfg);
    data.label(1:64) = layout.label(1:64);
else
    load(epoch_dir)
end

%% keep only channels of interest
if strcmp(dataType, 'cnt')
    cfg = [];
    cfg.channel = {'EEG','VEOG','HEOG'};
    data = ft_selectdata(cfg, data);
end

%% run fast ICA and check eog component detectability

cfg = [];
cfg.keeptrials = 'yes';
if ICA_onlyEEG; cfg.channel = {'EEG'}; 
%else  cfg.channel = {'EEG','VEOG','HEOG'}; 
end

d_eeg = ft_timelockanalysis(cfg, data);

% run ica
if ica_here
    
    load([outfile_data filesep 'ICA_comp' filesep subj_name '.mat']);
else
    
    cfg = [];
    cfg.method = 'fastica';
    ica = ft_componentanalysis(cfg, d_eeg);
end

% time lock the ica data
cfg = [];
cfg.keeptrials = 'yes';
d_ica = ft_timelockanalysis(cfg, ica); 

if strcmp(dataType, 'cnt')
    % get the EOG data
    cfg.channel = {'VEOG'};
    d_veog = ft_timelockanalysis(cfg, data); 
    cfg.channel = {'HEOG'};
    d_heog = ft_timelockanalysis(cfg, data);
else
    cfg.channel = {'EOG'};
    d_1 = ft_timelockanalysis(cfg, data); 
    d_eog = d_1.trial(:,1,:);
end

if strcmp(dataType, 'cnt')
    x = [];
    y = [];
    x_v = d_veog.trial(:,1,:); % eog
    x_h = d_heog.trial(:,1,:); % eog
else
    x = [];
    y = [];
    x_v = d_eog; % eog
    x_h = d_eog; % eog
end

% caculated the correlation
for c = 1:size(d_ica.trial,2)
    y = d_ica.trial(:,c,:); % components
    rBlink(c) = corr(y(:), x_v(:),'rows','complete');; mark1{c} = 'blink';
    rSac(c) = corr(y(:), x_h(:),'rows','complete');; mark2{c} = 'sacc';
end

% plot the ica results
figure; 
if strcmp(dataType, 'cnt')
    subplot(2,1,1); bar(1:c, abs(rSac),'r'); title('R-SACCADE'); xticks(1:5:c);
    subplot(2,1,2); bar(1:c, abs(rBlink), 'b'); title('R-BLINK'); xticks(1:5:c);
else
    bar(1:c, abs(rSac),'r'); title('R-SACCADE&Blink'); xticks(1:5:c);
end
xlabel('comp #');

% save the epoch results  
imagewd = getframe(gcf);
imwrite(imagewd.cdata, [outfile_results filesep 'ica_co_' subj_name '.tiff']);

if autoICA
    if strcmp(dataType, 'cnt')
        co_blink = find(abs(rSac) > autoICA_co_remove);
        co_sacc = find(abs(rBlink) > autoICA_co_remove);
        comp2rem = unique([co_blink co_sacc]);
    else
        co_blink = find(abs(rSac) > autoICA_co_remove);
        comp2rem = unique(co_blink);
    end
else
    comp2rem = input('bad components are: ');
end

% clean blink ica comp
cfg = [];
cfg.component = comp2rem;
data_clean_ica = ft_rejectcomponent(cfg, ica, data);

%% Clean and visualize the results 
if do_visualRemove
    disp('step: visual remove')
    data_clean_ica.trialinfo(:,end+1) = 1:size(data_clean_ica.trialinfo,1);
    trials_old = data_clean_ica.trialinfo(:,end);

    disp('Visual remove for all data')
    cfg = [];
    cfg.method = 'summary';
    cfg.channel = {'EEG'};
    data_vr = ft_rejectvisual(cfg, data_clean_ica);

    disp('Visual remove for interesting channel')
    cfg.keepchannel = 'yes';
    cfg.channel = i_channel;
    data_vr = ft_rejectvisual(cfg, data_vr);

    disp('Visual remove for interesting Freqency')
    cfg.channel = {'EEG'};
    cfg.preproc.bpfilter = 'yes';
    cfg.preproc.bpfreq = i_freq;
    data_vr = ft_rejectvisual(cfg, data_vr);

    disp('Visual remove for interesting Freqency in interesting channel')
    cfg.channel = i_channel;
    data_vr = ft_rejectvisual(cfg, data_vr);

    % caculate remove data
    trials_new = data_vr.trialinfo(:,end);
    trl2keep = ismember(trials_old, trials_new);
else 
    %load([trial2keepfile filesep subj_name '.mat'])
    trl2keep = ones(size(d_eeg.trialinfo));
end

cfg = [];
cfg.trials = logical(trl2keep);
data_clean_ica_vr = ft_selectdata(cfg, data_clean_ica);

propkeep = mean(trl2keep);
fprintf('step: %i/%i trials have been marked in visual remove phase \n', length(data.trial)-sum(trl2keep),length(data.trial));

%% Plot results
%keyboard
cfg = [];
if strcmp(dataType, 'cnt')
    cfg.channel = {'VEOG' 'HEOG'};
else
    cfg.channel = {'EOG'};
end
cfg.keeptrials  = 'yes';
EOG = ft_timelockanalysis(cfg, data); % calculate the trial average

EOG_data1 = D2array2Cell(squeeze(mean(EOG.trial, 2)));

EOG = ft_timelockanalysis(cfg, data_clean_ica); % calculate the trial average
EOG_data2 = D2array2Cell(squeeze(mean(EOG.trial, 2)));

EOG = ft_timelockanalysis(cfg, data_clean_ica_vr); % calculate the trial average
EOG_data3 = D2array2Cell(squeeze(mean(EOG.trial, 2)));


cfg.channel = i_channel;
ioc = ft_timelockanalysis(cfg, data); % calculate the trial average
ioc_data1 = D2array2Cell(squeeze(mean(ioc.trial, 2)));

ioc = ft_timelockanalysis(cfg, data_clean_ica); % calculate the trial average
ioc_data2 = D2array2Cell(squeeze(mean(ioc.trial, 2)));

ioc = ft_timelockanalysis(cfg, data_clean_ica_vr); % calculate the trial average
ioc_data3 = D2array2Cell(squeeze(mean(ioc.trial, 2)));

clear g

[y, cond]=cell2cond({EOG_data1 EOG_data2 EOG_data3}, {'rawData' 'afterICA' 'afterICA&Remove'});
g(1,1) = gramm('x', EOG.time *1000, 'y', y ); 
g(1,1).geom_line(); 
g(1,1).set_title('EOG');
g(1,1).facet_grid([],cond);

[y, cond]=cell2cond({ioc_data1 ioc_data2 ioc_data3}, {'rawData' 'afterICA' 'afterICA&Remove'});
g(2,1) = gramm('x', EOG.time *1000, 'y', y); 
g(2,1).geom_line(); 
g(2,1).set_title(['Interesting Channel']);
g(2,1).facet_grid([],cond);

g.set_order_options('color',{'rawData' 'afterICA' 'afterICA&Remove'}, 'column', {'rawData' 'afterICA' 'afterICA&Remove'});
g.set_text_options('base_size',15,'label_scaling',1.4);
g.set_names('x','Time','y','uv','column',[]);

figure('Position',[100 100 1500 700]);
g.draw();

imagewd = getframe(gcf);
imwrite(imagewd.cdata, [outfile_results filesep 'clean_results_' subj_name '.tiff']);

%% save data
if ~exist('epoch_dir')
    save([Epochfile filesep subj_name '.mat'], 'data');
end

save([icafile filesep subj_name '.mat'], 'ica');
save([remv_compfile filesep subj_name '.mat'], 'comp2rem');
event.sel = trl2keep;
save([trial2keepfile filesep subj_name '.mat'], 'event');

if ~exist('epoch_dir')
    save([trig_numfile filesep subj_name '.mat'], 'mtable');
end

if ~plot_out
    close all
    
end
