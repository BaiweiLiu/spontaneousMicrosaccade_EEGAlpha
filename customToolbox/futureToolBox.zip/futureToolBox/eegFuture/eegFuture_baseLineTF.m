function [data_out] = eegFuture_baseLineTF(cfg)
% windowsize
% data_tfr
% baseWin
v2struct(cfg)

timesel_baseline = data_tfr.time >= baseWin(1)+(windowsize / 2) & data_tfr.time <= baseWin(2)-(windowsize / 2);

data_baseline = squeeze(mean(mean(data_tfr.powspctrm(:,:,:,timesel_baseline),4))); % mean over time in baseline period & trials
data_tfr.pows_blCorr = zeros(size(data_tfr.powspctrm));

for  tlInd = 1:size(data_tfr.powspctrm,1)
    infoDisp(['processing trial ' num2str(tlInd) '/' num2str(size(data_tfr.powspctrm,1))],'loop', tlInd, size(data_tfr.powspctrm,1))
    for timeInd = 1:size(data_tfr.powspctrm,4)
         data_tfr.pows_blCorr(tlInd,:,:,timeInd) = ((squeeze(data_tfr.powspctrm(tlInd,:,:,timeInd)) - data_baseline) ./ data_baseline) * 100;
    end
end
data_tfr.powspctrm = data_tfr.pows_blCorr;
data_tfr.pows_blCorr = [];
data_out = data_tfr;
end