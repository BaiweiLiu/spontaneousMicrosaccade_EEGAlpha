function [data_out] = eegFuture_readData(cfg)
v2struct(cfg); % cfg = data_set, subj_name, apply_ica, apply_VR, write_dir
infoDisp(['start to process subject ' subj_name]);

outfile_data = [data_set filesep 'data_clean_epoch']; 

Epochfile = [outfile_data filesep 'Epoch_data' filesep subj_name '.mat']; load(Epochfile);
icafile = [outfile_data filesep 'ICA_comp' filesep subj_name '.mat']; load(icafile);
remv_compfile = [outfile_data filesep 'remv_comp' filesep subj_name '.mat'];  load(remv_compfile);
trial2keepfile =  [outfile_data filesep 'trial_keep' filesep subj_name '.mat']; load(trial2keepfile);


if apply_ica
    infoDisp(['apply ICA to remove blink'], 'line');

    if ICA_onlyEEG; cfg.channel = {'EEG'}; 
    else  cfg.channel = {'EEG','VEOG','HEOG'}; 
    end
    data = ft_selectdata(cfg, data);
    
    cfg = [];
    cfg.component = comp2rem;
    data = ft_rejectcomponent(cfg, ica, data); 
end

if apply_VR
    infoDisp(['remove bad trial (not recommended)'], 'line');

    cfg = [];
    cfg.trials = event.sel;
    data = ft_selectdata(cfg, data);
end
%% surface laplacian?

if apply_laplacian
    infoDisp(['apply laplacian'], 'line');
    cfg = [];
    cfg.elec = ft_read_sens('standard_1020.elc');
    data = ft_scalpcurrentdensity(cfg, data);
end

data_out = data;
end