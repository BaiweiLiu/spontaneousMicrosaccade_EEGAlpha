function [g] = eegFutureEEG_plot(cfg)
badSubj = {'00000'};
v2struct(cfg); % cfg = indiv, GA_address, cond2plot, dime
load(GA_address);
GA_data = GA_struct.ERP;
cmap = brewermap([],'*RdBu');

cond_index = find(ismember(GA_struct.label, cond2plot));
subjMaker = {};condMaker = {};data_line={};

if exist('controlCond')
    c_ind = cond_index(controlCond); 
    GA_data = GA_data(:,:,:,:) - GA_data(:,c_ind,:,:);
    baselineCond = cond2plot(controlCond);
    cond2plot(controlCond) = [];
    cond_index(controlCond) = [];
end
    

if ~dim3
    if strcmp(plotType,'indiv')
        data2plot = GA_data(:,:,:);

        if ~subFig
            for subjInd = 1:GA_struct.subjNum
                for condInd = 1:length(cond_index)
                    data_line{end+1} = squeeze(data2plot(subjInd,cond_index(condInd),:))';
                    subjMaker{end+1} = ['pp' num2str(subjInd)];
                    condMaker{end+1} = cond2plot{condInd};
                end
        end
            g= gramm('x',GA_struct.time, 'y',data_line, 'color', condMaker);
            g.geom_line();
            g.facet_grid([],subjMaker);
            g.set_text_options('base_size',15,'label_scaling',1.4);
            g.set_names('x','Time (0 = event)','y','cVsi (%)','column','subj');
            g.axe_property('XLim',time2plot,'YLim',limitZ,'YTick',[limitZ(1): 5: limitZ(2)]);
            g.set_order_options('color', GA_struct.label);
            g.draw();
        else
            
            maxRow = ceil(sqrt(GA_struct.subjNum));
            for subjInd = 1:GA_struct.subjNum
                for condInd = 1:length(cond_index)
                    data_line{condInd} = squeeze(data2plot(subjInd,cond_index(condInd),:))';
                    subjMaker = GA_struct.subjID{subjInd};
                    condMaker{condInd} = cond2plot{condInd};
                end

                rawInd = ceil(subjInd/maxRow);
                colInd = subjInd - (rawInd-1)* maxRow;
                g(rawInd,colInd)= gramm('x',GA_struct.time, 'y',data_line,'color', condMaker);
                g(rawInd,colInd).geom_line();
                g(rawInd,colInd).set_title(subjMaker);
            end
            g.set_text_options('base_size',15,'label_scaling',1.4);
            g.set_names('x','Time (0 = event)','y','cVsi (%)','column','subj');
            g.axe_property('XLim',time2plot, 'YLim',limitZ,'YTick',[limitZ(1): (limitZ(2)-limitZ(1))/4 : limitZ(2)]);
            g.draw();

            for subjInd = 1:GA_struct.subjNum

                rawInd = ceil(subjInd/maxRow);
                colInd = subjInd - (rawInd-1)* maxRow;
                line([time2plot(1) time2plot(2)],[0 0],'Color','k','LineStyle','--','Parent',g(rawInd,colInd).facet_axes_handles(1))
                line([0 0],limitZ,'Color','k','LineStyle','--','Parent',g(rawInd,colInd).facet_axes_handles(1))
            end

        end
    elseif strcmp(plotType,'sum')
        data2plot = GA_data;

        for subjInd = 1:GA_struct.subjNum
            if ~ismember(GA_struct.subjID{subjInd}, badSubj)
                for condInd = 1:length(cond_index)
                    data_line{end+1} =  gsmooth(squeeze(data2plot(subjInd,cond_index(condInd),:))',20);%squeeze(data2plot(subjInd,cond_index(condInd),:))';
                    subjMaker{end+1} = GA_struct.subjID{subjInd};
                    condMaker{end+1} = cond2plot{condInd};
                end
            end
        end

        g= gramm('x',GA_struct.time, 'y',data_line, 'color', condMaker);
        g.stat_summary();
        g.set_text_options('base_size',15,'label_scaling',1.4);
        g.set_names('x','Time (0 = event)','y','cVsi','column','subj');
        g.axe_property('XLim',time2plot, 'YLim',limitZ,'YTick',[limitZ(1): (limitZ(2)-limitZ(1))/4 : limitZ(2)]);
        g.set_order_options('color', cond2plot)
        if ~singleCond
            g.set_order_options('color', GA_struct.label);
        end

        if ~ exist('controlCond')
            g.set_title('sum');
        else
            g.set_title([ 'sum-baseLine:' baselineCond]);
        end

        g.draw();      

        line([time2plot(1) time2plot(2)],[0 0],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1))
        line([0 0],limitZ,'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1))
        if exist('timeLine')
            for lineInd = 1:length(timeLine)
                line([timeLine(lineInd) timeLine(lineInd)],[-2 10],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1));
            end
        end
    end

end
end