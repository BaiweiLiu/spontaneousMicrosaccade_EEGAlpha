function eegFuture_GAtopoplot(cfg,GA)

v2struct(cfg);
if GA
TF_data.powspctrm = [];
TF_data.powspctrm = GA;
end
for freqInd=1:size(freq2plot,1)
    for timeInd = 1:size(time2plot,1)
        subplot(size(freq2plot,1),size(time2plot,1),(freqInd-1)*size(time2plot,1)+timeInd)
        cfg =[];
        cfg.comp_trig = 0;
        cfg.TF_data = TF_data;
        cfg.average_power = freq2plot(freqInd,:);
        cfg.averg_time = time2plot(timeInd,:);
        cfg.top_loc= top_loc;
        cfg.maker_channel=maker_channel;
        cfg.plotTitle = [];
        eegFuture_topoplot(cfg);
     end
end
    
end
