function eegFuture_plot(cfg)
chroma_range = 70;
lightness_range = 60;
hue_range = [25 385];

v2struct(cfg); % cfg = indiv, GA_address, cond2plot, dime
load(GA_address);
GA_data = GA_struct.power;
cmap = brewermap([],'*RdBu');


cond_index = find(ismember(GA_struct.label, cond2plot));
subjMaker = {};condMaker = {};data_line={};
if exist('controlCond')
    c_ind = cond_index(controlCond); 
    GA_data = GA_data(:,:,:,:) - GA_data(:,c_ind,:,:);
    baselineCond = cond2plot(controlCond);
    cond2plot(controlCond) = [];
    cond_index(controlCond) = [];
end
    

if ~dim3
    if strcmp(plotType,'indiv')
        if ~averagePower
        for subjInd = 1:GA_struct.subjNum
            for condInd = 1:length(cond_index)
                if ~subFig
                    
                    subplot(size(GA_struct.label,2),GA_struct.subjNum,(condInd-1)*GA_struct.subjNum + subjInd)
                else
                    
                    %subplot(ceil(sqrt(GA_struct.subjNum)),ceil(sqrt(GA_struct.subjNum)),(condInd-1)*GA_struct.subjNum + subjInd)
                    subplot(5,5,subjInd)
                end
                data2plot = squeeze(GA_data(subjInd,cond_index(condInd),:,:));
                contourf(GA_struct.time,GA_struct.freq,data2plot,50,'linecolor','none')
                cl=get(gca,'clim'); title([cond2plot{condInd} ': pp' num2str(subjInd)])
                set(gca, 'FontSize', 20,'Fontname','Arial');
                xlim(time2plot)
                caxis(limitZ)
                colorbar
                colormap((cmap))
            end
        end
        else
            f2plot=dsearchn(GA_struct.freq', i_freq')';
            foi_seq = [f2plot(1):f2plot(2)];
            foifreq = [num2str(i_freq(1)) '-' num2str(i_freq(2))]; 
            data2plot = squeeze(mean(GA_data(:,:,foi_seq,:),3));
            
            if ~subFig
                for subjInd = 1:GA_struct.subjNum
                    for condInd = 1:length(cond_index)
                        data_line{end+1} = squeeze(data2plot(subjInd,cond_index(condInd),:))';
                        subjMaker{end+1} = ['pp' num2str(subjInd)];
                        condMaker{end+1} = cond2plot{condInd};
                    end
            end
                g= gramm('x',GA_struct.time, 'y',data_line, 'color', condMaker);
                g.geom_line();
                g.facet_grid([],subjMaker);
                g.set_text_options('base_size',15,'label_scaling',1.4);
                g.set_names('x','Time (0 = event)','y','cVsi (%)','column','subj');
                g.axe_property('XLim',time2plot,'YLim',limitZ,'YTick',[limitZ(1): 5: limitZ(2)]);
                g.set_order_options('color', GA_struct.label);
                g.draw();
            else
                maxRow = ceil(sqrt(GA_struct.subjNum));
                for subjInd = 1:GA_struct.subjNum
                    for condInd = 1:length(cond_index)
                        data_line{condInd} = squeeze(data2plot(subjInd,cond_index(condInd),:))';
                        subjMaker = ['pp' num2str(subjInd)];
                        condMaker{condInd} = cond2plot{condInd};
                    end
                    
                    rawInd = ceil(subjInd/maxRow);
                    colInd = subjInd - (rawInd-1)* maxRow;
                    g(rawInd,colInd)= gramm('x',GA_struct.time, 'y',data_line,'color', condMaker);
                    g(rawInd,colInd).geom_line();
                    g(rawInd,colInd).set_title(subjMaker);
                end
                g.set_text_options('base_size',15,'label_scaling',1.4);
                g.set_names('x','Time (0 = event)','y','cVsi (%)','column','subj');
                g.axe_property('XLim',time2plot, 'YLim',limitZ,'YTick',[limitZ(1): (limitZ(2)-limitZ(1))/4 : limitZ(2)]);
                g.draw();
                
                for subjInd = 1:GA_struct.subjNum
                    
                    rawInd = ceil(subjInd/maxRow);
                    colInd = subjInd - (rawInd-1)* maxRow;
                    line([time2plot(1) time2plot(2)],[0 0],'Color','k','LineStyle','--','Parent',g(rawInd,colInd).facet_axes_handles(1))
                    line([0 0],limitZ,'Color','k','LineStyle','--','Parent',g(rawInd,colInd).facet_axes_handles(1))
                end
                
            end
        end
    elseif strcmp(plotType,'sum')
            if ~averagePower
                for condInd = 1:length(cond_index)
                    subplot(1, length(cond_index),condInd);
                    [h,p,ci,t] = ttest(GA_data(:,cond_index(condInd),:,:));
                    
                    data2plot = squeeze(nanmean(GA_data(:,cond_index(condInd),:,:),1));
                    %data2plot = squeeze(t.tstat);
                    
                    contourf(GA_struct.time,GA_struct.freq,data2plot,50,'linecolor','none')
                    cl=get(gca,'clim'); 
                    set(gca, 'FontSize', 20,'Fontname','Arial');
                    if ~ exist('controlCond')
                        title([cond2plot{condInd} '-sum']);
                    else
                        title([cond2plot{condInd} '-sum-baseLine:' baselineCond]);
                    end
                    xlim(time2plot)
                    caxis(limitZ);
                    colorbar;
                    colormap((cmap));
                end
            else
                f2plot=dsearchn(GA_struct.freq', i_freq')';
                foi_seq = [f2plot(1):f2plot(2)];
                foifreq = [num2str(i_freq(1)) '-' num2str(i_freq(2))]; 
                data2plot = squeeze(nanmean(GA_data(:,:,foi_seq,:),3));
     
                for subjInd = 1:GA_struct.subjNum
                    for condInd = 1:length(cond_index)
                        data_line{end+1} = squeeze(data2plot(subjInd,cond_index(condInd),:))';
                        subjMaker{end+1} = ['pp' num2str(subjInd)];
                        condMaker{end+1} = cond2plot{condInd};
                        
                    end
                end
            
            g = [];
            g= gramm('x',GA_struct.time .* 1000, 'y',data_line, 'color', condMaker);
            g.stat_summary();
            g.set_text_options('base_size',15,'label_scaling',1.4);
            g.set_names('x','Time (0 = probe)','y','cVsi (%)','column','subj');
            g.axe_property('XLim',time2plot*1000, 'YLim',limitZ,'YTick',[limitZ(1): (limitZ(2)-limitZ(1))/4 : limitZ(2)]);
            g.set_order_options('color', GA_struct.label);
            g.set_color_options( 'hue_range', hue_range, 'lightness_range',lightness_range,'chroma_range',chroma_range);
            
            if ~singleCond
                g.set_order_options('color', GA_struct.label);
            end
            
            if ~ exist('controlCond')
                g.set_title('sum');
            else
                g.set_title([ 'sum-baseLine:' baselineCond]);
            end
                    
            g.draw();      
            
            line([time2plot(1)*1000 time2plot(2)*1000],[0 0],'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1))
            line([0 0],limitZ,'Color','k','LineStyle','--','Parent',g(1,1).facet_axes_handles(1))
            end
    end

end
end