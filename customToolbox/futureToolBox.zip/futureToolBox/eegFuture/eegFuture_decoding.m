function eegFuture_decoding(cfg)

v2struct(cfg); % cfg = data, out_dir, method, freq_pass, resample_rate, cond_trigger, erp_baseline, channels, run_tfr, 
outfile = [out_dir filesep decodName]; if ~exist(outfile,'dir'); mkdir(outfile); end;
c1 = ismember(data.trialinfo(:,1), cond_trigger{1})'; % vector telling which trials are "left stim"
c2 = ismember(data.trialinfo(:,1), cond_trigger{2})'; % vector telling which trials are "right stim"

%% baseline correction
cfg = [];
cfg.demean = 'yes';
cfg.baselinewindow = erp_baseline; % pre-stimulus baseline window
data = ft_preprocessing(cfg, data);

%% decide what aspect of the data to look at... e.g., raw time-domain signal, or amplitude at specific frequency?

if run_tfr    % only execute if above true  
   
   cfg = [];
   cfg.bpfilter = 'yes';
   cfg.bpfreq = freq_pass; % the frequency of interest
   cfg.hilbert = 'yes'; % also taking "hilbert" with give amplitude timecourse at this frequency -- as shown in plot below
   data = ft_preprocessing(cfg, data);
   
elseif exist('freq_pass')
   cfg = [];
   cfg.bpfilter = 'yes';
   cfg.bpfreq = freq_pass;
   data = ft_preprocessing(cfg, data);   
end

%% downsample
if exist('resample_rate')
    cfg = [];
    cfg.resamplefs = resample_rate;
    data = ft_resampledata(cfg,data);
end

%% 
%% select data, clean, and get all data into single matrix
% select data 
cfg = [];
%cfg.latency = [-.1 1.5]; % just keep -100 to +600 ms -- makes it a bit faster below.
cfg.channel = channels; % only keep EEG electrodes (remove EOG etc.) -- always make sure to think about what you wish to include and NOT include in the multi-variate pattern used for decoding below.
data = ft_selectdata(cfg, data);

% get all data into single matrix 
cfg = [];
cfg.keeptrials = 'yes';
data = ft_timelockanalysis(cfg, data); % put all trials into a single matrix

%% loop over trials and timepoints to get similarity to matching and non-matching classes (i.e. the actual "decoding"), and calculate decoding accuracy
% using a "leave-one-out" approach (i.e., iterative "testing" each trial against all remaining trials)
% logic: if pattern distinguishes between the two classes, the pattern in a given trial (at a given timepoint) should be MORE SIMILAR to other trials from the MATCHING (same) vs. NON-MATCHING (different) class.
% => we therefore just need to look at pattern similarities (below, we quantify similarity in three different ways).
reverseStr='';
d = data.trial; % call data matrix just d, for simplifying script below -- d = trials x electrodes x timepoints

alltrials = 1:size(data.trial,1); % 1:ntrials
classes = c2; % 0 for condition 1; 1 for condition 2
for trl = alltrials % loop over all trials
    msg = sprintf(['decoding trial ', num2str(trl), ' out of ', num2str(length(alltrials))]);
    fprintf([reverseStr, msg]);
    reverseStr = repmat(sprintf('\b'), 1, length(msg));
    
    % "test data" (the data from this trial)
    thistrial = trl;
    class_thistrial = classes(trl);
    testdata = squeeze(d(thistrial,:,:));    
    
    % "training data" (the matching and non-matching data from all remaining trials)
    othertrials = ~ismember(alltrials, thistrial); % mark which trials are NOT the current trial - to compare the current trial against (never include "test" data in "training set")
    other_matching = othertrials & (classes==class_thistrial); %  trials from same class to which current trial belongs (EXCEPT the one we are currently looping over - i.e. "leave-one-out")
    other_nonmatching = othertrials & (classes~=class_thistrial); % trials for class to which current trials does NOT belong   
    traindata_match = squeeze(mean(d(other_matching,:,:))); % average over all matching trials
    traindata_nonmatch = squeeze(mean(d(other_nonmatching,:,:))); % average over all non-matching trials    
    
    % now loop over time points to run classification separately for each timepoint
    for time = 1:length(data.time)      
    %% three different ways to "quantify" similarity to matching and non-matching classes of data (calculate and store separately for each trial and timepoint in the loop)
    % metric 3 - mahalanobis distance -- also taking covariance into account - i.e. distances normalised by the covariance structure in the data... should be more appropriate/sensitive
    covar = cov(squeeze(d(othertrials,:,time))); % covariance over all other trials, at this time point
    covar = nearestSPD(covar);
    mahdist_to_match(trl,time) = pdist([testdata(:,time)'; traindata_match(:,time)'], 'mahalanobis', covar);
    mahdist_to_nonmatch(trl,time) = pdist([testdata(:,time)'; traindata_nonmatch(:,time)'], 'mahalanobis', covar);
    mah_dist(trl,time) = mahdist_to_match(trl,time)- mahdist_to_nonmatch(trl,time);
    mah_acc(trl,time) = mahdist_to_match(trl,time) < mahdist_to_nonmatch(trl,time); % correct classification if SMALLER distance to MATCH trials... incorrect otherwise  
    mah_dist_norm(trl,time) = (mahdist_to_match(trl,time)- mahdist_to_nonmatch(trl,time)) / (mahdist_to_match(trl,time)+ mahdist_to_nonmatch(trl,time)) ;
    
    end % end of loop over time points  
end % end of loop over trials
% get the t value
for time = 1:length(data.time)    
    h(time) = ttest(mahdist_to_match(:,time),mahdist_to_nonmatch(:,time),'Tail','left','Alpha',0.05);
end
% save
decoding_scores.time = data.time;
decoding_scores.dist = mah_dist;
decoding_scores.acc = mah_acc;
decoding_scores.dist_norm = mah_dist_norm;
decoding_scores.t_val = h;

save([outfile filesep subjName '.mat'],'decoding_scores')
end