function [data_out] = eegFuture_groupAnalysis_MVPA(cfg)

v2struct(cfg); % cfg = file, decodName, kindOfResult, out_dir
outfile = [out_dir filesep 'GA_MVPA']; if ~exist(outfile,'dir') ; mkdir(outfile); end
condMaker = {}; subjMaker ={}; data_plot = {};
for condInd = 1:length(decodName)
    
    cd([file filesep decodName{condInd}]);
    sublist=dir('*.mat');
    sublist={sublist.name};
    
    for subjInd = 1:length(sublist)
        indiv_data = [];
        load(sublist{subjInd});
        eval(['indiv_data = decoding_scores.' kindOfResult ';']);
        data_mean = squeeze(mean(indiv_data,1));
        GA_data(subjInd,condInd,:) = data_mean;
        condMaker{end+1} = decodName{condInd};
        subjMaker{end+1} = ['pp' num2str(subjInd) ];
        data_plot{end+1} = data_mean;
    end
end
GA_struct.subjNum = subjInd;
GA_struct.GA_data = GA_data;
GA_struct.value = kindOfResult;
GA_struct.decodName =decodName;
GA_struct.condMaker = condMaker;
GA_struct.subjMaker = subjMaker;
GA_struct.data_plot = data_plot;
GA_struct.plotTime = decoding_scores.time;

save([outfile filesep 'GA_results.mat'], 'GA_struct');

end