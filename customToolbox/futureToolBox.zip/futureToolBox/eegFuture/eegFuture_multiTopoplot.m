function [data_out] = eegFuture_multiTopoplot(cfg)

v2struct(cfg);

for freqInd=1:size(freq2plot,1)
    for timeInd = 1:size(time2plot,1)
        subplot(size(freq2plot,1),size(time2plot,1),(freqInd-1)*size(time2plot,1)+timeInd)
        cfg =[];
        cfg.GA = GA;
        cfg.comp_trig = comp_trig;
        cfg.TF_data = TF_data;
        cfg.average_power = freq2plot(freqInd,:);
        cfg.averg_time = time2plot(timeInd,:);
        cfg.top_loc= top_loc;
        cfg.maker_channel=maker_channel;
        cfg.plotTitle = [];
        cfg.zLimits =zLimits;
        if exist('cond_sel'); cfg.cond_sel = cond_sel; end
        eegFuture_topoplot(cfg);
    end
end
if ~GA; data_out = eegFuture_topoplot(cfg); end
end