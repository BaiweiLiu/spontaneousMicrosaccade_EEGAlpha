function eegFuture_GAbinEr(cfg)

% function eegFuture_GAbinEr(cfg)
% Description: read the bin events and bin the ERP data, then creat a data
% for all subject
%
%       cfg.eeg_file            = string specifiying the directory where the epoched eeg files are;
%       cfg.event_file          = string specifying the directory where the bin_event files are.
%       cfg.output_dir          = uknow.
%       cfg.valueChannel        = to-be-analysised channels
%       cfg.baselinewindow      = basedline window for ERP
%       cfg.valueTrig           = left_en and right_en triggers 
%       cfg.fileName            = uknow.
%       cfg.minTrials           = the minim num of trials in one bin, if no,
%       cfg.trial_ok_dir        = uknow.
%       cfg.valueType           = toward or away, which value you want to get.
%       then Nan
%       cfg.reLoc               = relocate the data based on bin value
%       cfg.sampleRate          = the sample rate of eeg data
%
% part of the eegFuture toolbox, by Baiwei Liu, VU, 2021
%

% default values
sampleRate = 1000;
reLoc = false;

% extract cfg value
v2struct(cfg);

% create output file
outfile = creatDir(output_dir);

% get list of input files
sublist_eeg = get_subFiles(eeg_file);
sublist_event = get_subFiles(event_file);

%% get clean file
for goodInd  = 1: length(goodness_file)
    sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
end

% run subLoop
for subInd = 1:length(sublist_eeg)

    infoDisp(['load event data for subj ' sublist_event{subInd}(end-7:end-4)]);
    load(sublist_event{subInd});  
    numBin =  size(event.sel,1);
    
    infoDisp(['Read cleaned data for subj ' sublist_eeg{subInd}(end-7:end-4)]);
    
    %% read data
    cfg = [];
    cfg.input_dir = sublist_eeg{subInd};
    cfg.goodness_file = inCellSelec(sublist_goodTl,subInd);
    cfg.baselinewindow  = baselinewindow;
    [data,trialOK] = eegFuture_readER(cfg);
    
   % decide what aspect of the data to look at... e.g., raw time-domain signal, or amplitude at specific frequency?
   if exist('i_freq')
       infoDisp(['convert eeg data to power data'], 'line');
       
       cfg = [];
       cfg.bpfilter = 'yes';
       cfg.bpfreq = i_freq; % the frequency of interest
       cfg.hilbert = 'yes'; % also taking "hilbert" with give amplitude timecourse at this frequency -- as shown in plot below
       data = ft_preprocessing(cfg, data);
       
       
   end
    
    
%     % time lock-analysis
%     cfg = [];
%     cfg.keeptrials = 'yes';
%     ERP_data = ft_timelockanalysis(cfg, data);
    
    % size of epoch time
    if ~reLoc
        timeSize = size(data.trial,3);
    else
        timeSize = (reLocWindow(2) - reLocWindow(1)) * 1000 * (sampleRate/1000);
    end
    
    % get left and right channels
    channel_left = match_str(data.label, valueChannel{1});
    channel_right = match_str(data.label, valueChannel{2});
    
    % get left and right trials
    left = ismember(data.trialinfo(:,1), valueTrig{1});
    right = ismember(data.trialinfo(:,1), valueTrig{2});

    % t2plot=dsearchn(ERP_data.time',averg_time')';
    % toi_seq = [t2plot(1):t2plot(2)];

    for binInd = 1:numBin 
        contra = []; ipi = []; cvsi = [];
        
        size(data.trial,3); 

        cond_sel = event.sel(binInd,trialOK);
        
        if reLoc
            cond_value = event.value(binInd,trialOK);
        end

        
        if ~reLoc
            
            % get and averaging contral and ipsi ERP 
            a = mean(mean(data.trial(left&cond_sel',channel_right,:))); % contra-chR
            b = mean(mean(data.trial(right&cond_sel',channel_right,:))); % ipsi-chR
            c = mean(mean(data.trial(right&cond_sel',channel_left,:))); % contra-chL
            d = mean(mean(data.trial(left&cond_sel',channel_left,:))); % ipsi-chL

            cvsi_chR = a-b;
            cvsi_chL = c-d;
            cvsi = (cvsi_chR + cvsi_chL) ./ 2;

            contra = (a+c)./2;
            ipi = (b+d)./2;
        
        else
            % locations of the trial in bin
            trial_sel = find(cond_sel);
            
            if sum(cond_sel) >= minTrials
                for trialSelInd = 1:length(trial_sel)

                    % get one location of the trial in bin
                    trialInd = trial_sel(trialSelInd);

                    % get one value of the trial
                    trialValue = cond_value(trialInd);

                    % from time to index
                    t2sort = dsearchn(data.time',[trialValue/1000+reLocWindow(1); trialValue/1000+reLocWindow(2)] );


                    if left(trialInd) >0
                        a = mean(data.trial(trialInd,channel_right,[t2sort(1):t2sort(2)-1]),2); % contra
                        b = mean(data.trial(trialInd,channel_left,[t2sort(1):t2sort(2)-1]),2); % ipsi
                    elseif right(trialInd) >0
                        
                        a = mean(data.trial(trialInd,channel_left,[t2sort(1):t2sort(2)-1]),2);% contra
                        b = mean(data.trial(trialInd,channel_right,[t2sort(1):t2sort(2)-1]),2); % ipsi
                    end
                    contra(trialSelInd,:) = squeeze(a);
                    ipi(trialSelInd,:) = squeeze(b); 
                end
                contra = mean(contra);
                ipi = mean(ipi);
                cvsi = contra - ipi;
                if ~exist('i_freq')
                    cvsi = contra - ipi;
                else
                    cvsi = (contra - ipi) ./(contra + ipi) *100;
                end
            end
            
        end
        if sum(cond_sel) >= minTrials
            data_cvsi(1,binInd,:) = contra;
            data_cvsi(2,binInd,:) = ipi;
            data_cvsi(3,binInd,:) = cvsi;
        else
            infoDisp('Number of trials is too low!','line')
            data_cvsi(1,binInd,:) = NaN(1,timeSize);
            data_cvsi(2,binInd,:) = NaN(1,timeSize);
            data_cvsi(3,binInd,:) = NaN(1,timeSize);
        end
    end
    
    GA_eeg.data(subInd,:,:,:) = data_cvsi;
    GA_eeg.subjName{subInd} = sublist_eeg{subInd}(end-7:end-4);
end

% save the data 
GA_eeg.time = data.time;
GA_eeg.bin = numBin;
GA_eeg.timeBin = event.timeBin;

GA_eeg.dimName = {'subjID', 'dataKind', 'binInd', 'time'};
save([outfile filesep 'GA_' fileName '.mat'], 'GA_eeg'); 
end