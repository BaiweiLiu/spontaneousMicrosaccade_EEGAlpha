function eegFuture_plot_MVPA(cfg)
v2struct(cfg); % cfg = indiv, GA_address
load(GA_address);
GA_data = GA_struct.data_plot;

cmap = brewermap([],'*RdBu');

if strcmp(GA_struct.value,'dist') | strcmp(GA_struct.value,'dist_norm'); lineValue = 0;
 elseif strcmp(GA_struct.value,'acc'); lineValue = 0.5; end;
 
if indiv
    g= gramm('x',GA_struct.plotTime, 'y',GA_data, 'color', GA_struct.condMaker);
    g.geom_line();
    g.facet_grid([],GA_struct.subjMaker);
    g.set_text_options('base_size',15,'label_scaling',1.4);
    g.set_names('x','Time (0 = event)','y',GA_struct.value,'column','subj');
    %g.axe_property('YLim',limitZ,'YTick',[limitZ(1): 5: limitZ(2)]);
    g.set_order_options('color', GA_struct.decodName);
    g.draw();
    for i = 1: GA_struct.subjNum
    line([GA_struct.plotTime(1) GA_struct.plotTime(end)],[lineValue lineValue],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(i));
    end
else
    g= gramm('x',GA_struct.plotTime, 'y',GA_data, 'color', GA_struct.condMaker);
    g.stat_summary();
    g.facet_grid([],[]);
    g.set_text_options('base_size',15,'label_scaling',1.4);
    g.set_names('x','Time (0 = event)','y',GA_struct.value,'column','subj');
    %g.axe_property('YLim',limitZ,'YTick',[limitZ(1): 5: limitZ(2)]);
    g.set_order_options('color', GA_struct.decodName);
    g.draw();
    line([GA_struct.plotTime(1) GA_struct.plotTime(end)],[lineValue lineValue],'Color','k','LineStyle','--','Parent',g.facet_axes_handles(1));
end
end