function [itpc_null,co_null] = eegFuture_getNullItpc(num_trials)
% num_trials = number of trials in this cond
num_simul = 10000;

for iteration = 1:num_simul; % how many times draw a random sample
    data = (rand(num_trials,1)-0.5)+(rand(num_trials,1)-0.5)*i;
    itpc = data ./ abs(data);
    itpc_distr(iteration) = abs(mean(itpc)); % mean resultant vector, just like ITPC
    
    coherence = mean(data) ./ mean(abs(data));
    co_distr(iteration) = squeeze(abs(coherence));
end
itpc_null = median(itpc_distr);
co_null = median(co_distr);
end

