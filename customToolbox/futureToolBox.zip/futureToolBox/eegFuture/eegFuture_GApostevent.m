function [data_out] = eegFuture_GApostevent(cfg)

v2struct(cfg); % cfg = input_file, valueType, postEvent, valueChannel, write_dir, dim2Name, trial_ok_dir

if ~dataHere 
    epoch_file = [data_dir filesep 'data_clean_epoch' filesep 'Epoch_data']; 

    cd(epoch_file)
    sublist=dir('*.mat');
    sublist={sublist.name}; 
else
    sublist = get_subFiles(data_dir);
end

outfile = creatDir(ouput_dir);

%% Read the goodness files
for goodInd  = 1: length(goodness_file)
    sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
end

for condInd = 1:size(postEvent,2)
    event_files{condInd,:} = get_subFiles(postEvent{condInd}, '*.mat');
end

%%
for subjInd = 1:length(sublist)
    
    if ~dataHere 
        %% read data
        disp(['Read epoch data for subj ' sublist{subjInd}(end-5:end-4)])
        cfg = [];
        cfg.data_set = data_dir;
        cfg.subj_name = sublist{subjInd}(1:4);
        cfg.apply_ica = apply_ica;
        cfg.ica_onlyEEG = ica_onlyEEG;
        cfg.apply_VR = apply_VR;    
        cfg.apply_laplacian = apply_laplacian;
        data = eegFuture_readData(cfg);
    else 
        infoDisp(['Read cleaned data for subj ' sublist{subjInd}(end-5:end-4)])
        %% read data
        cfg = [];
        cfg.input_dir = sublist{subjInd};
        cfg.goodness_file = inCellSelec(sublist_goodTl,subjInd);
        cfg.baselinewindow  = baselinewindow;
        [data,trialOK] = eegFuture_readER(cfg);
    end
     
    channel_left = match_str(data.label, valueChannel{1});
    channel_right = match_str(data.label, valueChannel{2});

    left = ismember(data.trialinfo(:,1), valueTrig{1});
    right = ismember(data.trialinfo(:,1), valueTrig{2});
    
    
    for condInd = 1:size(postEvent,2)
        disp(['load event file for subj ' event_files{condInd}{subjInd}(end-5:end-4)])
        load(event_files{condInd}{subjInd})

        cond_sel = event.sel(trialOK)';

        
        a = mean(mean(data.trial(left&cond_sel,channel_right,:))); % contra-chR
        b = mean(mean(data.trial(right&cond_sel,channel_right,:))); % ipsi-chR
        c = mean(mean(data.trial(right&cond_sel,channel_left,:))); % contra-chL
        d = mean(mean(data.trial(left&cond_sel,channel_left,:))); % ipsi-chL

        cvsi_chR = a-b ;
        cvsi_chL = c-d;
        data_cvsi(condInd,:) = (cvsi_chR + cvsi_chL) ./ 2;
    end
    
    raw_sel = logical(ones(size(cond_sel)));
    a = mean(mean(data.trial(left&raw_sel,channel_right,:))); % contra-chR
    b = mean(mean(data.trial(right&raw_sel,channel_right,:))); % ipsi-chR
    c = mean(mean(data.trial(right&raw_sel,channel_left,:))); % contra-chL
    d = mean(mean(data.trial(left&raw_sel,channel_left,:))); % ipsi-chL

    cvsi_chR = a-b ;
    cvsi_chL = c-d;
    data_cvsi(condInd+1,:) = (cvsi_chR + cvsi_chL) ./ 2;
    
    GA_data(subjInd,:,:) = data_cvsi;
    subjID{subjInd} = sublist{subjInd}(end-7:end-4);
end

GA_struct.subjID =  subjID;
GA_struct.subjNum = subjInd;
GA_struct.ERP = GA_data;
GA_struct.baseLine = baselinewindow;
GA_struct.time = data.time;
GA_struct.label = [dim2Name 'raw'];
GA_struct.dimName = ['subjID', 'cond', 'time'];
data_out = GA_struct;
save([outfile filesep 'GA_' fileName '.mat'], 'GA_struct'); 

end