function [data_out, trial_ok] = eegFuture_readER(cfg)

% function eegFuture_readER(cfg)
% Description: grand average the gaze resutls
%       cfg.input_dir       = the dir of epoched eye_data
%       cfg.goodness_file   = dir of events we use to select trial.
%       cfg.baselinewindow  = time window of baseLine
% part of the eegFuture toolbox, by Baiwei Liu, VU, 2021
%

%% extract value
v2struct(cfg); 

%%
load(input_dir);
numTrial = size(eeg_data.trialinfo,1);

%% removebad trials
if exist('goodness_file')
    tl_ok = 0;
    for fileInd  = 1: length(goodness_file)
        load(goodness_file{fileInd})
        if  size(event.sel,1) >1
            event.sel = event.sel';
        end
        tl_ok = event.sel + tl_ok;
    end
    trial_ok = ismember(tl_ok, length(goodness_file));
else
    trial_ok = ones(1,numTrial);
end   

infoDisp(['get ' num2str(sum(trial_ok)) '/' num2str(numTrial) ' to process'], 'line')

cfg = [];
cfg.trials = trial_ok;
data = ft_selectdata(cfg, eeg_data);

% baseline correction
if exist('baselinewindow')
    cfg = [];
    cfg.demean = 'yes';
    cfg.baselinewindow = baselinewindow; 
    data = ft_preprocessing(cfg, data);
end
cfg = [];
cfg.keeptrials = 'yes';
data = ft_timelockanalysis(cfg, data);

data_out = data;
end