function [data_out] = eegFuture_Tmask_tf(cfg)
v2struct(cfg); % data, p_value
nSubjects = size(data ,1);
[~,~,~,tmp] = ttest(data);
tmap = squeeze(tmp.tstat);

realmean = squeeze(mean(data,1));
voxel_pval = p_value;
% uncorrected pixel-level threshold
threshmean = realmean;
tmapthresh = tmap;
if strcmp(method,'tail')
    tmapthresh(abs(tmap)<tinv(1-voxel_pval/2,nSubjects-1))=0;
    threshmean(abs(tmap)<tinv(1-voxel_pval/2,nSubjects-1))=0;
elseif strcmp(method,'left')
    tmapthresh(tmap>-1.*tinv(1-voxel_pval,nSubjects-1))=0;
    threshmean(tmap>-1.*tinv(1-voxel_pval,nSubjects-1))=0;
elseif strcmp(method,'right')
    tmapthresh(tmap<tinv(1-voxel_pval,nSubjects-1))=0;
    threshmean(tmap<tinv(1-voxel_pval,nSubjects-1))=0;
end

data_out = threshmean;
end