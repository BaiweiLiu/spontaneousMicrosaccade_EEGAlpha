function [data_out]= eegFutureTF_GApostEvent(cfg)

v2struct(cfg); % cfg = input_file, valueType, postEvent, valueChannel, write_dir, dim2Name, trial_ok_dir
outfile = creatDir(output_dir);

subList_TF = get_subFiles(input_file, '*.mat');

for condInd = 1:size(postEvent,2)
    event_files{condInd,:} = get_subFiles(postEvent{condInd}, '*.mat');
end

%% Read the goodness files
for goodInd  = 1: length(goodness_file)
    sublist_goodTl{goodInd} = get_subFiles(goodness_file{goodInd});
end

%%
for subjInd = 1:length(subList_TF)
    
    %% read data
    cfg = [];
    cfg.input_dir = subList_TF{subjInd};
    cfg.goodness_file = inCellSelec(sublist_goodTl,subjInd);
    [data_tfr,trialOK] = eegFuture_readTF(cfg);
    
%     %% 
%     
%     if exist('post_trial_ok_dir')
%         disp(['load post clean trial for subj ' subList_post_tlOK{subjInd}(end-5:end-4)])
%         load(subList_post_tlOK{subjInd});
%         trl2keep2 = event_sel(trl2keep)';
%     end  
    
    channel_left = match_str(data_tfr.label, valueChannel{1});
    channel_right = match_str(data_tfr.label, valueChannel{2});

    left = ismember(data_tfr.trialinfo(:,1), valueTrig{1});
    right = ismember(data_tfr.trialinfo(:,1), valueTrig{2});
    
    for condInd = 1:size(postEvent,2)
        disp(['load TF for subj ' event_files{condInd}{subjInd}(end-5:end-4)])
        load(event_files{condInd}{subjInd})

        cond_sel = event.sel(trialOK)';

        
        
%         if ~exist('post_trial_ok_dir')
            a = mean(mean(data_tfr.powspctrm(left&cond_sel,channel_right,:,:))); % contra-chR
            b = mean(mean(data_tfr.powspctrm(right&cond_sel,channel_right,:,:))); % ipsi-chR
            c = mean(mean(data_tfr.powspctrm(right&cond_sel,channel_left,:,:))); % contra-chL
            d = mean(mean(data_tfr.powspctrm(left&cond_sel,channel_left,:,:))); % ipsi-chL
%         else 
%             a = mean(mean(data_tfr.powspctrm(left&cond_sel&trl2keep2,channel_right,:,:))); % contra-chR
%             b = mean(mean(data_tfr.powspctrm(right&cond_sel&trl2keep2,channel_right,:,:))); % ipsi-chR
%             c = mean(mean(data_tfr.powspctrm(right&cond_sel&trl2keep2,channel_left,:,:))); % contra-chL
%             d = mean(mean(data_tfr.powspctrm(left&cond_sel&trl2keep2,channel_left,:,:))); % ipsi-chL
%         end
        cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
        cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
        data_cvsi(condInd,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
    end
    
    a = mean(mean(data_tfr.powspctrm(left,channel_right,:,:))); % contra-chR
    b = mean(mean(data_tfr.powspctrm(right,channel_right,:,:))); % ipsi-chR
    c = mean(mean(data_tfr.powspctrm(right,channel_left,:,:))); % contra-chL
    d = mean(mean(data_tfr.powspctrm(left,channel_left,:,:))); % ipsi-chL

    cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
    cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
    data_cvsi(condInd+1,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
        
    GA_data(subjInd,:,:,:) = data_cvsi;
   
end

GA_struct.subjNum = subjInd;
GA_struct.power = GA_data;
GA_struct.freq = data_tfr.freq;
GA_struct.time = data_tfr.time;
GA_struct.label = [dim2Name 'raw'];
GA_struct.dimName = {'subjID', 'cond', 'freq', 'time'};
data_out = GA_struct;
save([outfile filesep 'GA_' fileName '.mat'], 'GA_struct');
end