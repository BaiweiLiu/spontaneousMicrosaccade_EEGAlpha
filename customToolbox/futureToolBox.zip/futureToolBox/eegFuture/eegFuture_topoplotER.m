function [data_out] = eegFuture_topoplotER(cfg)

v2struct(cfg); % cfg = ERP_data, average_power, averg_time, top_loc, maker_channel, plotTitle,comp_trig
load(top_loc); cmap = brewermap([],'*RdBu');


toiTime = [num2str(averg_time(1)) '-' num2str(averg_time(2))];



if ~GA
    % baseline correctioncfg = [];
    cfg.demean = 'yes';
    cfg.baselinewindow = baselinewindow; 
    ERP_data = ft_preprocessing(cfg, ERP_data); 

    cfg = [];
    cfg.keeptrials = 'yes';
    ERP_data = ft_timelockanalysis(cfg, ERP_data);
    
    t2plot=dsearchn(ERP_data.time',averg_time')';
    toi_seq = [t2plot(1):t2plot(2)];
    
    condA = ismember(ERP_data.trialinfo(:,1), comp_trig{1}); 
    condB = ismember(ERP_data.trialinfo(:,1), comp_trig{2});
    
    if ~exist('cond_sel')
        topodatA =squeeze(mean(ERP_data.trial(condA',:,toi_seq),[1 3]));
        topodatB =squeeze(mean(ERP_data.trial(condB',:,toi_seq),[1 3]));
    else 
        topodatA =squeeze(mean(ERP_data.trial(condA'&cond_sel,:,toi_seq),[1 3]));
        topodatB =squeeze(mean(ERP_data.trial(condB'&cond_sel,:,toi_seq),[1 3]));
    end
    data2plot = topodatA - topodatB;

else
    
    t2plot=dsearchn(ERP_time',averg_time')';
    toi_seq = [t2plot(1):t2plot(2)];
    
    data2plot = squeeze(mean(ERP_data.trial(:,:,toi_seq),[1 3]));
end

if plotFigure
    
topoplot(data2plot,chan_loc,'electrodes','off','emarker2',{maker_channel,'*','k',5,1},'whitebk','on','plotrad',0.5,'style', 'map', 'maplimits',zLimits);
title([plotTitle ' ' toiTime 'ms']); colormap(cmap)
end

if ~GA
   if ~exist('cond_sel')
        topodatA =squeeze(mean(ERP_data.trial(condA',:,:),1));
        topodatB =squeeze(mean(ERP_data.trial(condB',:,:),1));
    else 
        topodatA =squeeze(mean(ERP_data.trial(condA'&cond_sel,:,:),1));
        topodatB =squeeze(mean(ERP_data.trial(condB'&cond_sel,:,:),1));
    end
    data_out = topodatA - topodatB;
end
end