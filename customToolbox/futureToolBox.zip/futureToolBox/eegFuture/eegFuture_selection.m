function [channels,freqs] = eegFuture_selection()
%% set electrodes to cortex
channels.OCCIP =         {'PO7'    'PO3'    'O1'     'Iz'    'Oz'    'POz'   'PO8'   'PO4'   'O2'    'PO9'   'PO10'};
channels.PARIET =        {'P1'     'P3'     'P5'     'P7'    'Pz'    'P2'    'P4'    'P6'    'P8' };
channels.FRONTAL =       {'Fp1'    'AF7'    'AF3'    'Fpz'   'Fp2'   'AF8'   'AF4'   'AFz'   'Fz' };
channels.TEMPORAL =      {'FT7'    'C5'     'T7'     'TP7'   'CP5'   'FT8'   'C6'    'T8'    'TP8'   'CP6'};
channels.OCCIPARIET =    {'P1'     'P3'     'P5'     'P7'    'P9'    'Pz'    'P2'    'P4'    'P6'    'P8'    'P10'   'PO7'    'PO3'  'O1'    'Iz'   'Oz'    'POz'   'PO8'   'PO4'   'O2'  'PO9'  'PO10' };
channels.visualL = {'O1','PO7','PO3','P7','P5','P3','P1'}; % PO7
channels.visualR = {'O2','PO8','PO4','P8','P6','P4','P2'}; % PO8
channels.motionL = {'C3','C1','CP3','CP1','FC3','FC1','C5'}; % C3
channels.motionR = {'C4','C2','CP4','CP2','FC4','FC2','C6'};  % C4
channels.CDAL =           {'P5'         'P7'       'PO7'    'O1'      'PO9'   };
channels.CDAR =           {   'P6'       'P8'      'PO8'      'O2'       'PO10'};
 %% set power band
freqs.thetafreq= [3 7];
freqs.alphafreq= [8 12];
freqs.betafreq= [13 30];
end