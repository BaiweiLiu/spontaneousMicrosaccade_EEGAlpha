function [data_out]=eegFuture_groupAnalysis(cfg)

v2struct(cfg); % cfg = input_file, valueType, valueTrig, valueChannel, cond_trigger, write_dir, dim2Name, dim3Name,dim3
outfile = [write_dir filesep 'groupResults_TF'];
if ~exist(outfile,'dir') ; mkdir(outfile); end

%% Read the files
cd(input_file)
sublist=dir('*.mat');
sublist={sublist.name}; 
if strcmp(valueType, 'contrVSipi')
    for subjInd = 1:length(sublist)
        data_cvsi = [];
        load([input_file filesep sublist{subjInd}]);
        channel_left = match_str(data_tfr.label, valueChannel{1});
        channel_right = match_str(data_tfr.label, valueChannel{2});
        
        left = ismember(data_tfr.trialinfo(:,1), valueTrig{1});
        right = ismember(data_tfr.trialinfo(:,1), valueTrig{2});

        a = mean(mean(data_tfr.powspctrm(left,channel_right,:,:))); % contra-chR
        b = mean(mean(data_tfr.powspctrm(right,channel_right,:,:))); % ipsi-chR
        c = mean(mean(data_tfr.powspctrm(right,channel_left,:,:))); % contra-chL
        d = mean(mean(data_tfr.powspctrm(left,channel_left,:,:))); % ipsi-chL
        
        cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
        cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
        data_cvsi(1,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
        
        for cond_ind = 1:size(cond_trigger,2)
            condtrig = ismember(data_tfr.trialinfo(:,1), cond_trigger{cond_ind}); 
            
            a = mean(mean(data_tfr.powspctrm(left&condtrig,channel_right,:,:))); % contra-chR
            b = mean(mean(data_tfr.powspctrm(right&condtrig,channel_right,:,:))); % ipsi-chR
            c = mean(mean(data_tfr.powspctrm(right&condtrig,channel_left,:,:))); % contra-chL
            d = mean(mean(data_tfr.powspctrm(left&condtrig,channel_left,:,:))); % ipsi-chL
            
            cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
            cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
            data_cvsi(1+cond_ind,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
        end
        
        if comp
            for comp_Ind = 1:size(compareCond,2) 
                compare_part = compareCond{comp_Ind};
                comtra_data = data_cvsi(1+compare_part(1),:,:) - data_cvsi(1+compare_part(2),:,:);
                data_cvsi(1+size(cond_trigger,2)+comp_Ind,:,:) = comtra_data;
            end
        end
            
        GA_data(subjInd,:,:,:) = data_cvsi;
    end
elseif strcmp(valueType, 'aVSb-contrVSipi')
    
    for subjInd = 1:length(sublist)
        data_cvsi = [];
        load([input_file filesep sublist{subjInd}]);
        
        condA = ismember(data_tfr.trialinfo(:,1), valueTrig{1}); 
        condB = ismember(data_tfr.trialinfo(:,1), valueTrig{2});
    
        a = mean(mean(data_tfr.powspctrm(condA,[chRV chLV],:,:))); 
        b = mean(mean(data_tfr.powspctrm(condB,[chRV chLV],:,:))); 
    
    RvS = squeeze(((a-b) ./ (a+b)) * 100);
    dvis(1,:,:) = RvS ;
        channel_left = match_str(data_tfr.label, valueChannel{1});
        channel_right = match_str(data_tfr.label, valueChannel{2});
        
        left = ismember(data_tfr.trialinfo(:,1), valueTrig{1});
        right = ismember(data_tfr.trialinfo(:,1), valueTrig{2});

        a = mean(mean(data_tfr.powspctrm(left,channel_right,:,:))); % contra-chR
        b = mean(mean(data_tfr.powspctrm(right,channel_right,:,:))); % ipsi-chR
        c = mean(mean(data_tfr.powspctrm(right,channel_left,:,:))); % contra-chL
        d = mean(mean(data_tfr.powspctrm(left,channel_left,:,:))); % ipsi-chL
        
        cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
        cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
        data_cvsi(1,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
        
        for cond_ind = 1:size(cond_trigger,2)
            condtrig = ismember(data_tfr.trialinfo(:,1), cond_trigger{cond_ind}); 
            
            a = mean(mean(data_tfr.powspctrm(left&condtrig,channel_right,:,:))); % contra-chR
            b = mean(mean(data_tfr.powspctrm(right&condtrig,channel_right,:,:))); % ipsi-chR
            c = mean(mean(data_tfr.powspctrm(right&condtrig,channel_left,:,:))); % contra-chL
            d = mean(mean(data_tfr.powspctrm(left&condtrig,channel_left,:,:))); % ipsi-chL
            
            cvsi_chR = squeeze(((a-b) ./ (a+b)) * 100);
            cvsi_chL = squeeze(((c-d) ./ (c+d)) * 100);
            data_cvsi(1+cond_ind,:,:) = (cvsi_chR + cvsi_chL) ./ 2;
        end
        
        if comp
            for comp_Ind = 1:size(compareCond,2) 
                compare_part = compareCond{comp_Ind};
                comtra_data = data_cvsi(1+compare_part(1),:,:) - data_cvsi(1+compare_part(2),:,:);
                data_cvsi(1+size(cond_trigger,2)+comp_Ind,:,:) = comtra_data;
            end
        end
            
        GA_data(subjInd,:,:,:) = data_cvsi;
    end
    
end
GA_struct.subjNum = subjInd;
GA_struct.power = GA_data;
GA_struct.freq = data_tfr.freq;
GA_struct.time = data_tfr.time;
GA_struct.label = dim2Name;
GA_struct.dimName = ['subjID', 'cond', 'freq', 'time'];
data_out = GA_struct;
save([outfile filesep 'GA' fileName '.mat'], 'GA_struct');
end